/* VoTongy service worker
 * - Pre-caches the offline page + app icons
 * - Cache-first for immutable static assets (/_next/static, icons, fonts)
 * - Network-only for pages, APIs, auth and dashboards (never serve stale votes or private data)
 * - Offline fallback page for failed navigations
 */
const VERSION = "v1";
const STATIC_CACHE = `votongy-static-${VERSION}`;
const PRECACHE = ["/offline.html", "/icons/icon-192.png", "/icons/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key.startsWith("votongy-") && key !== STATIC_CACHE)
            .map((key) => caches.delete(key)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

const STATIC_PATTERN = /\.(?:woff2?|css|js|png|jpg|jpeg|svg|webp|ico)$/i;

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  const path = url.pathname;
  if (path.startsWith("/api/") || path.startsWith("/auth/")) return;

  // Page navigations: always network, fall back to the offline page.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request).catch(() => caches.match("/offline.html").then((res) => res || Response.error())),
    );
    return;
  }

  // Immutable static assets: cache-first.
  if (
    path.startsWith("/_next/static/") ||
    path.startsWith("/icons/") ||
    (STATIC_PATTERN.test(path) && !path.startsWith("/_next/image"))
  ) {
    event.respondWith(
      caches.open(STATIC_CACHE).then((cache) =>
        cache.match(request).then((cached) => {
          if (cached) return cached;
          return fetch(request).then((response) => {
            if (response.ok) cache.put(request, response.clone());
            return response;
          });
        }),
      ),
    );
  }
});
