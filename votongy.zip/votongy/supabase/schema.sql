-- =====================================================================
-- VoTongy — Supabase PostgreSQL Schema
-- Run once in: Supabase Dashboard -> SQL Editor -> New query -> Run
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. ENUMS
-- ---------------------------------------------------------------------
do $$ begin
  create type user_role as enum ('SUPER_ADMIN', 'ORGANIZER', 'NOMINEE');
exception when duplicate_object then null; end $$;

do $$ begin
  create type event_status as enum ('DRAFT', 'PENDING_APPROVAL', 'ACTIVE', 'PAUSED', 'ENDED', 'REJECTED');
exception when duplicate_object then null; end $$;

do $$ begin
  create type nominee_status as enum ('PENDING', 'APPROVED', 'REJECTED');
exception when duplicate_object then null; end $$;

do $$ begin
  create type tx_status as enum ('PENDING', 'SUCCESS', 'FAILED', 'ABANDONED', 'FLAGGED');
exception when duplicate_object then null; end $$;

do $$ begin
  create type tx_channel as enum ('WEB', 'PWA', 'USSD');
exception when duplicate_object then null; end $$;

-- ---------------------------------------------------------------------
-- 2. TABLES
-- ---------------------------------------------------------------------

-- 2.1 profiles (1:1 with auth.users)
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text not null,
  full_name     text,
  phone         text,
  role          user_role not null default 'ORGANIZER',
  is_approved   boolean not null default false,   -- organizers need Super Admin approval
  created_at    timestamptz not null default now()
);

-- 2.2 platform_settings (single-row global config, incl. emergency kill-switch)
create table if not exists public.platform_settings (
  id                     boolean primary key default true check (id),  -- enforces single row
  voting_paused          boolean not null default false,
  default_commission_pct numeric(5,2) not null default 10.00,
  updated_at             timestamptz not null default now()
);
insert into public.platform_settings (id) values (true) on conflict do nothing;

-- 2.3 events
create table if not exists public.events (
  id                        uuid primary key default gen_random_uuid(),
  organizer_id              uuid not null references public.profiles(id) on delete restrict,
  slug                      text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title                     text not null,
  description               text,
  banner_url                text,
  cost_per_vote             numeric(10,2) not null default 1.00 check (cost_per_vote > 0),
  currency                  text not null default 'GHS',
  commission_pct            numeric(5,2) not null default 10.00 check (commission_pct between 0 and 100),
  start_at                  timestamptz not null,
  end_at                    timestamptz not null,
  status                    event_status not null default 'DRAFT',
  show_live_votes           boolean not null default true,
  allow_public_nominations  boolean not null default false,
  nominee_counter           integer not null default 0,   -- drives N001, N002...
  created_at                timestamptz not null default now(),
  check (end_at > start_at)
);
create index if not exists idx_events_organizer on public.events(organizer_id);
create index if not exists idx_events_status on public.events(status);

-- 2.4 categories
create table if not exists public.categories (
  id          uuid primary key default gen_random_uuid(),
  event_id    uuid not null references public.events(id) on delete cascade,
  name        text not null,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  unique (event_id, name)
);
create index if not exists idx_categories_event on public.categories(event_id);

-- 2.5 nominees
create table if not exists public.nominees (
  id           uuid primary key default gen_random_uuid(),
  event_id     uuid not null references public.events(id) on delete cascade,
  category_id  uuid not null references public.categories(id) on delete cascade,
  user_id      uuid references public.profiles(id) on delete set null,  -- linked after magic-link invite
  email        text,
  name         text not null,
  code         text,                       -- auto-generated: N001
  photo_url    text,
  bio          text,
  total_votes  bigint not null default 0 check (total_votes >= 0),
  status       nominee_status not null default 'APPROVED',
  created_at   timestamptz not null default now(),
  unique (event_id, code)
);
create index if not exists idx_nominees_event on public.nominees(event_id);
create index if not exists idx_nominees_category on public.nominees(category_id);
create index if not exists idx_nominees_user on public.nominees(user_id);
create index if not exists idx_nominees_name_trgm on public.nominees (lower(name));

-- 2.6 nomination_applications (public nomination portal)
create table if not exists public.nomination_applications (
  id               uuid primary key default gen_random_uuid(),
  event_id         uuid not null references public.events(id) on delete cascade,
  category_id      uuid references public.categories(id) on delete set null,
  applicant_name   text not null,
  applicant_email  text,
  applicant_phone  text,
  photo_url        text,
  bio              text,
  status           nominee_status not null default 'PENDING',
  reviewed_by      uuid references public.profiles(id),
  reviewed_at      timestamptz,
  created_at       timestamptz not null default now()
);
create index if not exists idx_apps_event on public.nomination_applications(event_id, status);

-- 2.7 transactions
create table if not exists public.transactions (
  id                uuid primary key default gen_random_uuid(),
  reference         text not null unique,                 -- our Paystack reference
  event_id          uuid not null references public.events(id) on delete restrict,
  nominee_id        uuid not null references public.nominees(id) on delete restrict,
  voter_phone       text,
  voter_email       text,
  votes             integer not null check (votes > 0 and votes <= 100000),
  amount            numeric(12,2) not null check (amount > 0),   -- GHS
  currency          text not null default 'GHS',
  status            tx_status not null default 'PENDING',
  channel           tx_channel not null default 'WEB',
  paystack_payload  jsonb,
  failure_reason    text,
  paid_at           timestamptz,
  created_at        timestamptz not null default now()
);
create index if not exists idx_tx_event_status on public.transactions(event_id, status);
create index if not exists idx_tx_nominee on public.transactions(nominee_id, status);
create index if not exists idx_tx_phone on public.transactions(voter_phone);
create index if not exists idx_tx_created on public.transactions(created_at desc);

-- 2.8 audit_logs
create table if not exists public.audit_logs (
  id          bigint generated always as identity primary key,
  actor_id    uuid references public.profiles(id) on delete set null,
  action      text not null,
  entity      text,
  entity_id   text,
  metadata    jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists idx_audit_created on public.audit_logs(created_at desc);

-- ---------------------------------------------------------------------
-- 3. HELPER FUNCTIONS
-- ---------------------------------------------------------------------
create or replace function public.current_role_name()
returns user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_super_admin()
returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'SUPER_ADMIN' from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.owns_event(p_event_id uuid)
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.events e
    where e.id = p_event_id and e.organizer_id = auth.uid()
  )
$$;

-- ---------------------------------------------------------------------
-- 4. TRIGGERS
-- ---------------------------------------------------------------------

-- 4.1 Auto-create profile when an auth user is created.
-- Role is read from raw_app_meta_data (set only by service role / dashboard,
-- NOT editable by the user). Defaults to ORGANIZER (unapproved).
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_role user_role;
begin
  v_role := coalesce((new.raw_app_meta_data ->> 'role')::user_role, 'ORGANIZER');
  insert into public.profiles (id, email, full_name, role, is_approved)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data ->> 'full_name',
    v_role,
    v_role in ('SUPER_ADMIN', 'NOMINEE')
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 4.2 Block self-service role / approval escalation on profiles.
-- NOTE: intentionally NOT security definer. Inside a SECURITY DEFINER function current_user is the
-- function owner (postgres), which would make the backend-bypass check below true for everyone.
create or replace function public.guard_profile_update()
returns trigger
language plpgsql set search_path = public as $$
begin
  if current_user in ('postgres', 'supabase_admin', 'service_role') then
    return new;
  end if;
  if (new.role is distinct from old.role or new.is_approved is distinct from old.is_approved)
     and not public.is_super_admin() then
    raise exception 'Not allowed to change role or approval status';
  end if;
  return new;
end $$;

drop trigger if exists trg_guard_profile_update on public.profiles;
create trigger trg_guard_profile_update
  before update on public.profiles
  for each row execute function public.guard_profile_update();

-- 4.3 Auto-generate nominee short code (N001, N002, ...) per event.
create or replace function public.assign_nominee_code()
returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_next integer;
begin
  if new.code is null or new.code = '' then
    update public.events
       set nominee_counter = nominee_counter + 1
     where id = new.event_id
     returning nominee_counter into v_next;
    new.code := 'N' || lpad(v_next::text, 3, '0');
  end if;
  return new;
end $$;

drop trigger if exists trg_assign_nominee_code on public.nominees;
create trigger trg_assign_nominee_code
  before insert on public.nominees
  for each row execute function public.assign_nominee_code();

-- 4.4 Nobody except the backend (service role / SECURITY DEFINER RPC) may change vote totals.
create or replace function public.guard_nominee_votes()
returns trigger
language plpgsql as $$
begin
  if tg_op = 'INSERT' and new.total_votes <> 0
     and current_user not in ('postgres', 'supabase_admin', 'service_role') then
    raise exception 'total_votes must start at 0';
  end if;
  if tg_op = 'UPDATE' and new.total_votes is distinct from old.total_votes
     and current_user not in ('postgres', 'supabase_admin', 'service_role') then
    raise exception 'total_votes can only be changed by the payment processor';
  end if;
  return new;
end $$;

drop trigger if exists trg_guard_nominee_votes on public.nominees;
create trigger trg_guard_nominee_votes
  before insert or update on public.nominees
  for each row execute function public.guard_nominee_votes();

-- 4.5 Organizers cannot self-activate events; only Super Admin approves.
create or replace function public.guard_event_status()
returns trigger
language plpgsql set search_path = public as $$
begin
  if current_user in ('postgres', 'supabase_admin', 'service_role') or public.is_super_admin() then
    return new;
  end if;
  if tg_op = 'INSERT' and new.status not in ('DRAFT', 'PENDING_APPROVAL') then
    raise exception 'New events must be DRAFT or PENDING_APPROVAL';
  end if;
  if tg_op = 'INSERT' then
    -- Organizers cannot choose their own commission: force the platform default (10%).
    new.commission_pct := coalesce(
      (select default_commission_pct from public.platform_settings limit 1), 10.00);
  end if;
  if tg_op = 'UPDATE' and new.status is distinct from old.status then
    -- organizers may only submit for approval, or pause/resume/end their own live event
    if not (
      (old.status in ('DRAFT', 'REJECTED') and new.status = 'PENDING_APPROVAL') or
      (old.status = 'ACTIVE'    and new.status in ('PAUSED', 'ENDED')) or
      (old.status = 'PAUSED'    and new.status in ('ACTIVE', 'ENDED'))
    ) then
      raise exception 'Invalid status change';
    end if;
  end if;
  if tg_op = 'UPDATE' and new.commission_pct is distinct from old.commission_pct then
    raise exception 'Only Super Admin can change commission';
  end if;
  return new;
end $$;

drop trigger if exists trg_guard_event_status on public.events;
create trigger trg_guard_event_status
  before insert or update on public.events
  for each row execute function public.guard_event_status();

-- ---------------------------------------------------------------------
-- 5. ATOMIC VOTE PROCESSOR (called ONLY by the Paystack webhook, service role)
-- ---------------------------------------------------------------------
create or replace function public.process_successful_vote(
  p_reference        text,
  p_amount_pesewas   bigint,        -- Paystack "amount" field (GHS x 100)
  p_currency         text,
  p_payload          jsonb default null
)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_tx        public.transactions%rowtype;
  v_event     public.events%rowtype;
begin
  -- Lock the transaction row: concurrent duplicate webhooks serialize here.
  select * into v_tx
    from public.transactions
   where reference = p_reference
   for update;

  if not found then
    return jsonb_build_object('result', 'NOT_FOUND');
  end if;

  -- Idempotency: already processed -> do nothing.
  if v_tx.status = 'SUCCESS' then
    return jsonb_build_object('result', 'ALREADY_PROCESSED', 'transaction_id', v_tx.id);
  end if;

  -- Integrity: paid amount and currency must match what we expected.
  if p_amount_pesewas <> round(v_tx.amount * 100)::bigint or upper(p_currency) <> upper(v_tx.currency) then
    update public.transactions
       set status = 'FLAGGED',
           failure_reason = format('Amount/currency mismatch: expected %s %s, got %s %s',
                                   round(v_tx.amount * 100), v_tx.currency, p_amount_pesewas, p_currency),
           paystack_payload = p_payload
     where id = v_tx.id;
    insert into public.audit_logs(action, entity, entity_id, metadata)
    values ('TX_FLAGGED_MISMATCH', 'transaction', v_tx.id::text, p_payload);
    return jsonb_build_object('result', 'AMOUNT_MISMATCH', 'transaction_id', v_tx.id);
  end if;

  -- Lock the nominee row and credit votes atomically.
  perform 1 from public.nominees where id = v_tx.nominee_id for update;

  update public.nominees
     set total_votes = total_votes + v_tx.votes
   where id = v_tx.nominee_id;

  update public.transactions
     set status = 'SUCCESS',
         paid_at = now(),
         paystack_payload = p_payload,
         failure_reason = null
   where id = v_tx.id;

  insert into public.audit_logs(action, entity, entity_id, metadata)
  values ('VOTE_CREDITED', 'transaction', v_tx.id::text,
          jsonb_build_object('nominee_id', v_tx.nominee_id, 'votes', v_tx.votes));

  return jsonb_build_object('result', 'SUCCESS', 'transaction_id', v_tx.id, 'votes', v_tx.votes);
end $$;

revoke all on function public.process_successful_vote(text, bigint, text, jsonb) from public, anon, authenticated;
grant execute on function public.process_successful_vote(text, bigint, text, jsonb) to service_role;

-- ---------------------------------------------------------------------
-- 6. PUBLIC READ MODELS (safe for anonymous voters)
-- ---------------------------------------------------------------------

-- 6.1 Public events: only live/finished, never DRAFT/PENDING/REJECTED.
create or replace view public.public_events as
select e.id, e.slug, e.title, e.description, e.banner_url, e.cost_per_vote, e.currency,
       e.start_at, e.end_at, e.status, e.show_live_votes, e.allow_public_nominations,
       (e.status = 'ACTIVE' and now() between e.start_at and e.end_at
          and not (select voting_paused from public.platform_settings)) as is_voting_open
from public.events e
where e.status in ('ACTIVE', 'PAUSED', 'ENDED');

-- 6.2 Public nominees: vote totals hidden while the event hides live votes.
create or replace view public.public_nominees as
select n.id, n.event_id, n.category_id, n.name, n.code, n.photo_url, n.bio,
       case when e.show_live_votes or e.status = 'ENDED' then n.total_votes else null end as total_votes
from public.nominees n
join public.events e on e.id = n.event_id
where n.status = 'APPROVED' and e.status in ('ACTIVE', 'PAUSED', 'ENDED');

-- 6.3 Public categories
create or replace view public.public_categories as
select c.id, c.event_id, c.name, c.sort_order
from public.categories c
join public.events e on e.id = c.event_id
where e.status in ('ACTIVE', 'PAUSED', 'ENDED');

grant select on public.public_events, public.public_nominees, public.public_categories to anon, authenticated;

-- 6.4 Receipt lookup by reference (minimal, masked data; no table access needed)
create or replace function public.get_receipt(p_reference text)
returns table (
  reference text, status tx_status, votes integer, amount numeric, currency text,
  paid_at timestamptz, created_at timestamptz,
  event_title text, event_slug text, nominee_name text, nominee_code text,
  voter_phone_masked text
)
language sql stable security definer set search_path = public as $$
  select t.reference, t.status, t.votes, t.amount, t.currency, t.paid_at, t.created_at,
         e.title, e.slug, n.name, n.code,
         case when t.voter_phone is null then null
              else left(t.voter_phone, 4) || '****' || right(t.voter_phone, 2) end
  from public.transactions t
  join public.events e on e.id = t.event_id
  join public.nominees n on n.id = t.nominee_id
  where t.reference = p_reference
$$;
grant execute on function public.get_receipt(text) to anon, authenticated;

-- 6.5 Anonymized recent-vote feed for a nominee (dashboard)
create or replace function public.nominee_recent_votes(p_nominee_id uuid, p_limit int default 20)
returns table (votes integer, paid_at timestamptz, voter_masked text)
language sql stable security definer set search_path = public as $$
  select t.votes, t.paid_at,
         case when t.voter_phone is null then 'Anonymous'
              else left(t.voter_phone, 3) || '****' || right(t.voter_phone, 2) end
  from public.transactions t
  join public.nominees n on n.id = t.nominee_id
  where t.nominee_id = p_nominee_id
    and t.status = 'SUCCESS'
    and (n.user_id = auth.uid() or public.is_super_admin() or public.owns_event(t.event_id))
  order by t.paid_at desc
  limit least(p_limit, 100)
$$;
grant execute on function public.nominee_recent_votes(uuid, int) to authenticated;

-- ---------------------------------------------------------------------
-- 7. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------
alter table public.profiles                enable row level security;
alter table public.platform_settings       enable row level security;
alter table public.events                  enable row level security;
alter table public.categories              enable row level security;
alter table public.nominees                enable row level security;
alter table public.nomination_applications enable row level security;
alter table public.transactions            enable row level security;
alter table public.audit_logs              enable row level security;

-- profiles
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.is_super_admin());

drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin" on public.profiles
  for update to authenticated
  using (id = auth.uid() or public.is_super_admin())
  with check (id = auth.uid() or public.is_super_admin());

-- platform_settings: everyone may read the pause flag; only Super Admin writes
drop policy if exists "settings_read_all" on public.platform_settings;
create policy "settings_read_all" on public.platform_settings
  for select to anon, authenticated using (true);

drop policy if exists "settings_admin_update" on public.platform_settings;
create policy "settings_admin_update" on public.platform_settings
  for update to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- events (base table: organizer own + admin; public uses public_events view)
drop policy if exists "events_organizer_select" on public.events;
create policy "events_organizer_select" on public.events
  for select to authenticated
  using (organizer_id = auth.uid() or public.is_super_admin());

drop policy if exists "events_organizer_insert" on public.events;
create policy "events_organizer_insert" on public.events
  for insert to authenticated
  with check (
    organizer_id = auth.uid()
    and exists (select 1 from public.profiles p
                where p.id = auth.uid() and p.role = 'ORGANIZER' and p.is_approved)
  );

drop policy if exists "events_organizer_update" on public.events;
create policy "events_organizer_update" on public.events
  for update to authenticated
  using (organizer_id = auth.uid() or public.is_super_admin())
  with check (organizer_id = auth.uid() or public.is_super_admin());

drop policy if exists "events_admin_delete" on public.events;
create policy "events_admin_delete" on public.events
  for delete to authenticated using (public.is_super_admin());

-- categories
drop policy if exists "categories_manage" on public.categories;
create policy "categories_manage" on public.categories
  for all to authenticated
  using (public.owns_event(event_id) or public.is_super_admin())
  with check (public.owns_event(event_id) or public.is_super_admin());

-- nominees (base table: organizer, the nominee themself, admin)
drop policy if exists "nominees_select" on public.nominees;
create policy "nominees_select" on public.nominees
  for select to authenticated
  using (public.owns_event(event_id) or user_id = auth.uid() or public.is_super_admin());

drop policy if exists "nominees_organizer_write" on public.nominees;
create policy "nominees_organizer_write" on public.nominees
  for insert to authenticated
  with check (public.owns_event(event_id) or public.is_super_admin());

drop policy if exists "nominees_organizer_update" on public.nominees;
create policy "nominees_organizer_update" on public.nominees
  for update to authenticated
  using (public.owns_event(event_id) or public.is_super_admin())
  with check (public.owns_event(event_id) or public.is_super_admin());

drop policy if exists "nominees_organizer_delete" on public.nominees;
create policy "nominees_organizer_delete" on public.nominees
  for delete to authenticated
  using (public.owns_event(event_id) or public.is_super_admin());

-- nomination_applications
-- Public submissions go through the server (service role) after validation + rate limit.
drop policy if exists "apps_organizer_select" on public.nomination_applications;
create policy "apps_organizer_select" on public.nomination_applications
  for select to authenticated
  using (public.owns_event(event_id) or public.is_super_admin());

drop policy if exists "apps_organizer_update" on public.nomination_applications;
create policy "apps_organizer_update" on public.nomination_applications
  for update to authenticated
  using (public.owns_event(event_id) or public.is_super_admin())
  with check (public.owns_event(event_id) or public.is_super_admin());

-- transactions: read-only for organizer (own events) and admin. NO client writes at all.
drop policy if exists "tx_select" on public.transactions;
create policy "tx_select" on public.transactions
  for select to authenticated
  using (public.owns_event(event_id) or public.is_super_admin());

-- audit_logs: Super Admin read only
drop policy if exists "audit_admin_select" on public.audit_logs;
create policy "audit_admin_select" on public.audit_logs
  for select to authenticated using (public.is_super_admin());

-- ---------------------------------------------------------------------
-- 8. ANALYTICS HELPERS
-- ---------------------------------------------------------------------

-- Super Admin KPIs
create or replace function public.admin_kpis()
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v jsonb;
begin
  if not public.is_super_admin() then
    raise exception 'forbidden';
  end if;
  select jsonb_build_object(
    'gross_volume',    coalesce(sum(t.amount), 0),
    'platform_commission', coalesce(sum(t.amount * e.commission_pct / 100), 0),
    'total_votes',     coalesce(sum(t.votes), 0),
    'successful_tx',   count(*),
    'active_events',   (select count(*) from public.events where status = 'ACTIVE'),
    'pending_events',  (select count(*) from public.events where status = 'PENDING_APPROVAL'),
    'pending_organizers', (select count(*) from public.profiles where role = 'ORGANIZER' and not is_approved)
  ) into v
  from public.transactions t
  join public.events e on e.id = t.event_id
  where t.status = 'SUCCESS';
  return v;
end $$;
grant execute on function public.admin_kpis() to authenticated;

-- Organizer revenue per day for charts
create or replace function public.event_revenue_by_day(p_event_id uuid)
returns table (day date, revenue numeric, votes bigint)
language sql stable security definer set search_path = public as $$
  select (t.paid_at at time zone 'Africa/Accra')::date, sum(t.amount), sum(t.votes)
  from public.transactions t
  where t.event_id = p_event_id and t.status = 'SUCCESS'
    and (public.owns_event(p_event_id) or public.is_super_admin())
  group by 1 order by 1
$$;
grant execute on function public.event_revenue_by_day(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 9. STORAGE (photos & banners)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('votongy-media', 'votongy-media', true)
on conflict (id) do nothing;

drop policy if exists "media_public_read" on storage.objects;
create policy "media_public_read" on storage.objects
  for select to anon, authenticated using (bucket_id = 'votongy-media');

drop policy if exists "media_auth_upload" on storage.objects;
create policy "media_auth_upload" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'votongy-media' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "media_owner_modify" on storage.objects;
create policy "media_owner_modify" on storage.objects
  for update to authenticated
  using (bucket_id = 'votongy-media' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "media_owner_delete" on storage.objects;
create policy "media_owner_delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'votongy-media' and (storage.foldername(name))[1] = auth.uid()::text);

-- =====================================================================
-- END OF SCHEMA
-- =====================================================================
