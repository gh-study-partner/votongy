import { createClient } from "@/lib/supabase/server";
import { createPublicClient } from "@/lib/supabase/public";
import type { PublicEvent } from "@/types/database";

export interface NomineeEntry {
  nomineeId: string;
  name: string;
  code: string;
  photoUrl: string | null;
  bio: string | null;
  status: string;
  totalVotes: number;
  categoryId: string;
  categoryName: string;
  event: Pick<PublicEvent, "id" | "slug" | "title" | "status" | "end_at" | "start_at" | "show_live_votes" | "is_voting_open"> | null;
  /** Only available when the event shows live counts (or has ended). */
  rank: number | null;
  rankOf: number | null;
  sharePct: number | null;
  votesToLeader: number | null;
  countsHidden: boolean;
}

/** Loads every nominee profile linked to the signed-in nominee (RLS limits rows to user_id = auth.uid()). */
export async function getMyNomineeEntries(userId: string): Promise<NomineeEntry[]> {
  const supabase = await createClient();
  const { data: mine } = await supabase
    .from("nominees")
    .select("id, event_id, category_id, name, code, photo_url, bio, status, total_votes")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });

  if (!mine || mine.length === 0) return [];

  const pub = createPublicClient();
  const eventIds = [...new Set(mine.map((m) => m.event_id as string))];
  const catIds = [...new Set(mine.map((m) => m.category_id as string))];

  const [eventsRes, catsRes, rivalsRes] = await Promise.all([
    pub
      .from("public_events")
      .select("id, slug, title, status, end_at, start_at, show_live_votes, is_voting_open")
      .in("id", eventIds),
    pub.from("public_categories").select("id, name").in("id", catIds),
    pub.from("public_nominees").select("id, category_id, total_votes").in("category_id", catIds),
  ]);

  const events = new Map((eventsRes.data ?? []).map((e) => [e.id as string, e as NomineeEntry["event"]]));
  const cats = new Map((catsRes.data ?? []).map((c) => [c.id as string, c.name as string]));
  const rivals = (rivalsRes.data ?? []) as { id: string; category_id: string; total_votes: number | null }[];

  return mine.map((m) => {
    const group = rivals.filter((r) => r.category_id === m.category_id);
    const hidden = group.length === 0 || group.some((r) => r.total_votes === null);
    let rank: number | null = null;
    let share: number | null = null;
    let toLeader: number | null = null;

    if (!hidden) {
      const sorted = [...group].sort((a, b) => Number(b.total_votes) - Number(a.total_votes));
      const idx = sorted.findIndex((r) => r.id === m.id);
      const total = sorted.reduce((s, r) => s + Number(r.total_votes), 0);
      if (idx >= 0) {
        rank = idx + 1;
        share = total > 0 ? (Number(sorted[idx]!.total_votes) / total) * 100 : 0;
        toLeader = idx === 0 ? 0 : Number(sorted[0]!.total_votes) - Number(sorted[idx]!.total_votes);
      }
    }

    return {
      nomineeId: m.id as string,
      name: m.name as string,
      code: (m.code as string) ?? "",
      photoUrl: (m.photo_url as string | null) ?? null,
      bio: (m.bio as string | null) ?? null,
      status: m.status as string,
      totalVotes: Number(m.total_votes),
      categoryId: m.category_id as string,
      categoryName: cats.get(m.category_id as string) ?? "Category",
      event: events.get(m.event_id as string) ?? null,
      rank,
      rankOf: hidden ? null : group.length,
      sharePct: share,
      votesToLeader: toLeader,
      countsHidden: hidden,
    };
  });
}
