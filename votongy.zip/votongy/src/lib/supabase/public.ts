import { createClient } from "@supabase/supabase-js";

/**
 * Cookie-less anon client for public pages. Because it never touches cookies(),
 * pages using it can be statically generated and revalidated (ISR / edge cached).
 */
export function createPublicClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error("Supabase environment variables are not set");
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}
