import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Refreshes the Supabase session cookie on every matched request.
 * `state.response` always holds the latest response (with refreshed cookies).
 */
export async function updateSession(request: NextRequest) {
  const state = { response: NextResponse.next({ request }) };

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(list: { name: string; value: string; options?: any }[]) {
          list.forEach(({ name, value }) => request.cookies.set(name, value));
          state.response = NextResponse.next({ request });
          list.forEach(({ name, value, options }) =>
            state.response.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  return { supabase, user, state };
}
