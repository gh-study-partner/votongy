import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

export interface RateRule {
  name: string;
  limit: number;
  windowSec: number;
}

export const RULES = {
  voteIp: { name: "vote-ip", limit: 20, windowSec: 60 },
  votePhone: { name: "vote-phone", limit: 8, windowSec: 60 },
  nominate: { name: "nominate", limit: 5, windowSec: 600 },
  adminLookup: { name: "admin-lookup", limit: 60, windowSec: 60 },
  receipt: { name: "receipt", limit: 30, windowSec: 60 },
} satisfies Record<string, RateRule>;

export interface RateResult {
  success: boolean;
  remaining: number;
  /** epoch ms when the window resets */
  reset: number;
}

const hasRedis = Boolean(
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN,
);

let redis: Redis | null = null;
const limiters = new Map<string, Ratelimit>();
const memory = new Map<string, { count: number; reset: number }>();
let warned = false;

function memoryLimit(rule: RateRule, key: string): RateResult {
  const now = Date.now();
  const id = `${rule.name}:${key}`;
  const entry = memory.get(id);
  if (!entry || entry.reset <= now) {
    memory.set(id, { count: 1, reset: now + rule.windowSec * 1000 });
    if (memory.size > 5000) {
      for (const [k, v] of memory) if (v.reset <= now) memory.delete(k);
    }
    return { success: true, remaining: rule.limit - 1, reset: now + rule.windowSec * 1000 };
  }
  entry.count += 1;
  return {
    success: entry.count <= rule.limit,
    remaining: Math.max(0, rule.limit - entry.count),
    reset: entry.reset,
  };
}

/**
 * Sliding-window rate limit backed by Upstash Redis.
 * If the Upstash env vars are missing (local dev) or Redis errors, it falls back to a
 * per-instance in-memory limiter so the app keeps working.
 */
export async function rateLimit(rule: RateRule, key: string): Promise<RateResult> {
  if (hasRedis) {
    try {
      redis ??= Redis.fromEnv();
      let limiter = limiters.get(rule.name);
      if (!limiter) {
        limiter = new Ratelimit({
          redis,
          limiter: Ratelimit.slidingWindow(rule.limit, `${rule.windowSec} s`),
          prefix: `votongy:${rule.name}`,
          analytics: false,
        });
        limiters.set(rule.name, limiter);
      }
      const r = await limiter.limit(key);
      return { success: r.success, remaining: r.remaining, reset: r.reset };
    } catch (err) {
      console.error("[ratelimit] Redis error, using in-memory fallback:", err);
    }
  } else if (!warned && process.env.NODE_ENV === "production") {
    warned = true;
    console.warn(
      "[ratelimit] UPSTASH_REDIS_REST_URL / TOKEN not set. Using per-instance memory limiter. Set Upstash keys in production.",
    );
  }
  return memoryLimit(rule, key);
}

export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return req.headers.get("x-real-ip") ?? "unknown";
}

export function retryAfterSeconds(result: RateResult): number {
  return Math.max(1, Math.ceil((result.reset - Date.now()) / 1000));
}
