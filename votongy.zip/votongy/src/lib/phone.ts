// Ghana mobile number helpers.
// Valid mobile prefixes (after the leading 0): MTN 24/25/53/54/55/59, Telecel 20/50,
// AirtelTigo 26/27/56/57, plus 23 and 28/29 (other operators).
const VALID_PREFIXES = [
  "20", "23", "24", "25", "26", "27", "28", "29",
  "50", "53", "54", "55", "56", "57", "59",
];

/** Returns E.164 (+233XXXXXXXXX) or null if the number is not a valid Ghana mobile number. */
export function normalizeGhanaPhone(raw: string): string | null {
  let d = raw.replace(/[\s\-().]/g, "");
  if (d.startsWith("+")) d = d.slice(1);
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("233")) d = d.slice(3);
  else if (d.startsWith("0")) d = d.slice(1);
  if (!/^\d{9}$/.test(d)) return null;
  if (!VALID_PREFIXES.includes(d.slice(0, 2))) return null;
  return `+233${d}`;
}

export function maskPhone(e164: string | null | undefined): string {
  if (!e164) return "Anonymous";
  if (e164.length < 8) return "****";
  return `${e164.slice(0, 4)}****${e164.slice(-2)}`;
}

export type MomoNetwork = "MTN" | "Telecel" | "AirtelTigo";

export function detectNetwork(raw: string): MomoNetwork | null {
  const e164 = normalizeGhanaPhone(raw);
  if (!e164) return null;
  const p = e164.slice(4, 6);
  if (["24", "25", "53", "54", "55", "59"].includes(p)) return "MTN";
  if (["20", "50"].includes(p)) return "Telecel";
  if (["26", "27", "56", "57"].includes(p)) return "AirtelTigo";
  return null;
}

export function phoneDigits(e164: string): string {
  return e164.replace(/\D/g, "");
}
