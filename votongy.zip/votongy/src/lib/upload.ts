import { createClient } from "@/lib/supabase/client";
import { siteConfig } from "@/config/site";

/**
 * Downscales a photo in the browser before upload (saves mobile data and storage).
 * Returns the original file if it is already small or cannot be processed.
 */
export async function resizeImage(file: File, maxDim = 1200, quality = 0.85): Promise<File> {
  if (!file.type.startsWith("image/")) return file;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, maxDim / Math.max(bitmap.width, bitmap.height));
    if (scale === 1 && file.size < 700 * 1024) {
      bitmap.close();
      return file;
    }
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, "image/jpeg", quality),
    );
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch {
    return file;
  }
}

export function validateImage(file: File): string | null {
  if (!(siteConfig.media.allowedImageTypes as readonly string[]).includes(file.type)) {
    return "Use a JPG, PNG or WebP image.";
  }
  if (file.size > siteConfig.media.maxImageBytes * 3) {
    return "That image is too large. Choose one under 9 MB.";
  }
  return null;
}

/** Uploads to Supabase Storage under <userId>/<folder>/<uuid>.<ext> and returns the public URL. */
export async function uploadMedia(file: File, folder: string): Promise<string> {
  const problem = validateImage(file);
  if (problem) throw new Error(problem);

  const resized = await resizeImage(file);
  if (resized.size > siteConfig.media.maxImageBytes) {
    throw new Error("Image is still larger than 3 MB after compression. Try a smaller photo.");
  }

  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Your session expired. Please sign in again.");

  const ext = resized.type === "image/png" ? "png" : resized.type === "image/webp" ? "webp" : "jpg";
  const path = `${user.id}/${folder}/${crypto.randomUUID()}.${ext}`;

  const { error } = await supabase.storage.from(siteConfig.media.bucket).upload(path, resized, {
    contentType: resized.type,
    cacheControl: "31536000",
    upsert: false,
  });
  if (error) throw new Error(error.message);

  return supabase.storage.from(siteConfig.media.bucket).getPublicUrl(path).data.publicUrl;
}
