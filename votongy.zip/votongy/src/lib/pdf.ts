// Dependency-free, text-only PDF writer (A4, Helvetica). Enough for certified result sheets.

export interface PdfLine {
  text: string;
  size?: number;
  bold?: boolean;
  indent?: number;
  /** extra vertical space after the line, in points */
  gap?: number;
}

function sanitize(text: string): string {
  return text
    .replace(/₵/g, "GHS ")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, "-")
    .replace(/[^\x20-\x7E\xA0-\xFF]/g, "?");
}

function escapePdf(text: string): string {
  return text.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function wrap(text: string, maxChars: number): string[] {
  if (text.length <= maxChars) return [text];
  const words = text.split(" ");
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    if ((current + " " + word).trim().length > maxChars) {
      if (current) lines.push(current);
      current = word;
    } else {
      current = (current + " " + word).trim();
    }
  }
  if (current) lines.push(current);
  return lines;
}

export function buildSimplePdf(lines: PdfLine[]): Buffer {
  const pages: string[] = [];
  let ops: string[] = [];
  let y = 790;

  const newPage = () => {
    pages.push(ops.join("\n"));
    ops = [];
    y = 790;
  };

  for (const line of lines) {
    const size = line.size ?? 10;
    const lineHeight = size * 1.45;
    const indent = line.indent ?? 0;
    const maxChars = Math.max(10, Math.floor((495 - indent) / (size * 0.52)));
    const wrapped = line.text === "" ? [""] : wrap(sanitize(line.text), maxChars);
    for (const part of wrapped) {
      if (y - lineHeight < 50) newPage();
      if (part !== "") {
        ops.push(
          `BT /${line.bold ? "F2" : "F1"} ${size} Tf ${50 + indent} ${y.toFixed(2)} Td (${escapePdf(part)}) Tj ET`,
        );
      }
      y -= lineHeight;
    }
    y -= line.gap ?? 0;
  }
  newPage();

  const objects: string[] = [];
  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  const kids = pages.map((_, i) => `${5 + i * 2} 0 R`).join(" ");
  objects[2] = `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`;
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  objects[4] =
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
  pages.forEach((content, i) => {
    const pageObj = 5 + i * 2;
    objects[pageObj] =
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${pageObj + 1} 0 R >>`;
    objects[pageObj + 1] =
      `<< /Length ${Buffer.byteLength(content, "latin1")} >>\nstream\n${content}\nendstream`;
  });

  let out = "%PDF-1.4\n";
  const offsets: number[] = [];
  for (let i = 1; i < objects.length; i++) {
    offsets[i] = Buffer.byteLength(out, "latin1");
    out += `${i} 0 obj\n${objects[i]}\nendobj\n`;
  }
  const xrefOffset = Buffer.byteLength(out, "latin1");
  out += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for (let i = 1; i < objects.length; i++) {
    out += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  }
  out += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return Buffer.from(out, "latin1");
}
