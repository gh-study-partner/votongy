import type { UserRole } from "@/types/database";

export function roleHome(role: UserRole | string | null | undefined): string {
  switch (role) {
    case "SUPER_ADMIN":
      return "/admin";
    case "ORGANIZER":
      return "/organizer";
    case "NOMINEE":
      return "/nominee";
    default:
      return "/";
  }
}

/** Which role is allowed to see a protected path prefix. */
export function requiredRoleForPath(pathname: string): UserRole | null {
  if (pathname === "/admin" || pathname.startsWith("/admin/")) return "SUPER_ADMIN";
  if (pathname === "/organizer" || pathname.startsWith("/organizer/")) return "ORGANIZER";
  if (pathname === "/nominee" || pathname.startsWith("/nominee/")) return "NOMINEE";
  return null;
}
