import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { siteConfig } from "@/config/site";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatGHS(amount: number | string | null | undefined): string {
  const n = Number(amount ?? 0);
  return `${siteConfig.currencySymbol}${n.toLocaleString("en-GH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatNumber(n: number | string | null | undefined): string {
  return Number(n ?? 0).toLocaleString("en-GH");
}

const dateTimeFmt = new Intl.DateTimeFormat("en-GH", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Africa/Accra",
});
const dateFmt = new Intl.DateTimeFormat("en-GH", {
  dateStyle: "medium",
  timeZone: "Africa/Accra",
});

export function formatDateTime(value: string | Date | null | undefined): string {
  if (!value) return "-";
  return dateTimeFmt.format(new Date(value));
}

export function formatDate(value: string | Date | null | undefined): string {
  if (!value) return "-";
  return dateFmt.format(new Date(value));
}

export function timeAgo(value: string | Date | null | undefined): string {
  if (!value) return "";
  const diff = Math.max(0, Date.now() - new Date(value).getTime());
  const s = Math.floor(diff / 1000);
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

export function absoluteUrl(path: string): string {
  return `${siteConfig.url}${path.startsWith("/") ? path : `/${path}`}`;
}

export function eventVoteUrl(slug: string, nomineeCode?: string | null): string {
  const base = absoluteUrl(`/e/${slug}`);
  return nomineeCode ? `${base}?nominee=${encodeURIComponent(nomineeCode)}` : base;
}

/** Only allow same-site relative redirects. */
export function safeNext(next: string | null | undefined, fallback = "/"): string {
  if (!next) return fallback;
  if (!next.startsWith("/") || next.startsWith("//") || next.includes("\\")) return fallback;
  return next;
}

export type VotingState = "open" | "upcoming" | "ended" | "paused";

export function computeVotingState(event: {
  status: string;
  start_at: string;
  end_at: string;
  is_voting_open: boolean;
}): VotingState {
  const now = Date.now();
  if (event.status === "ENDED" || now > new Date(event.end_at).getTime()) return "ended";
  if (event.status === "PAUSED") return "paused";
  if (now < new Date(event.start_at).getTime()) return "upcoming";
  if (!event.is_voting_open) return "paused";
  return "open";
}

export function whatsappShareUrl(text: string): string {
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
}
