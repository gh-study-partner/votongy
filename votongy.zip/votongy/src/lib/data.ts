import { createPublicClient } from "@/lib/supabase/public";
import type { PublicCategory, PublicEvent, PublicNominee } from "@/types/database";

/** Public (anonymous) read helpers. They never throw: a missing/slow DB yields empty data. */

export async function getPublicEvents(limit = 30): Promise<PublicEvent[]> {
  try {
    const supabase = createPublicClient();
    const { data, error } = await supabase
      .from("public_events")
      .select("*")
      .order("end_at", { ascending: false })
      .limit(limit);
    if (error) {
      console.error("[data] getPublicEvents", error.message);
      return [];
    }
    return (data ?? []) as PublicEvent[];
  } catch (err) {
    console.error("[data] getPublicEvents", err);
    return [];
  }
}

export async function getEventBySlug(slug: string): Promise<PublicEvent | null> {
  try {
    const supabase = createPublicClient();
    const { data, error } = await supabase
      .from("public_events")
      .select("*")
      .eq("slug", slug)
      .maybeSingle();
    if (error) {
      console.error("[data] getEventBySlug", error.message);
      return null;
    }
    return (data as PublicEvent | null) ?? null;
  } catch (err) {
    console.error("[data] getEventBySlug", err);
    return null;
  }
}

export async function getEventCatalog(
  eventId: string,
): Promise<{ categories: PublicCategory[]; nominees: PublicNominee[] }> {
  try {
    const supabase = createPublicClient();
    const [cats, noms] = await Promise.all([
      supabase
        .from("public_categories")
        .select("*")
        .eq("event_id", eventId)
        .order("sort_order", { ascending: true }),
      supabase
        .from("public_nominees")
        .select("*")
        .eq("event_id", eventId)
        .order("name", { ascending: true })
        .limit(2000),
    ]);
    return {
      categories: (cats.data ?? []) as PublicCategory[],
      nominees: (noms.data ?? []) as PublicNominee[],
    };
  } catch (err) {
    console.error("[data] getEventCatalog", err);
    return { categories: [], nominees: [] };
  }
}
