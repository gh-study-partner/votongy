import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { roleHome } from "@/lib/roles";
import type { UserRole } from "@/types/database";

export interface SessionProfile {
  id: string;
  email: string;
  full_name: string | null;
  role: UserRole;
  is_approved: boolean;
}

/** Returns the signed-in user's profile, or null when signed out. */
export async function getSessionProfile(): Promise<SessionProfile | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("profiles")
    .select("id, email, full_name, role, is_approved")
    .eq("id", user.id)
    .maybeSingle();

  return (data as SessionProfile | null) ?? null;
}

/** Server-side guard used in layouts, pages and server actions (middleware is the first layer). */
export async function requireRole(roles: UserRole[]): Promise<SessionProfile> {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");
  if (!roles.includes(profile.role)) redirect(roleHome(profile.role));
  return profile;
}
