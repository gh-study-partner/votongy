import { z } from "zod";
import { normalizeGhanaPhone } from "./phone";
import { siteConfig } from "@/config/site";

export const phoneSchema = z
  .string()
  .trim()
  .min(1, "Enter your phone number")
  .transform((value, ctx) => {
    const normalized = normalizeGhanaPhone(value);
    if (!normalized) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Enter a valid Ghana mobile number" });
      return z.NEVER;
    }
    return normalized;
  });

const optionalEmail = z
  .union([z.string().trim().email("Enter a valid email").max(120), z.literal("")])
  .optional()
  .transform((v) => (v ? v : undefined));

export const initiateVoteSchema = z.object({
  eventId: z.string().uuid(),
  nomineeId: z.string().uuid(),
  votes: z.coerce
    .number()
    .int("Votes must be a whole number")
    .min(siteConfig.votes.min, `Minimum ${siteConfig.votes.min} vote`)
    .max(siteConfig.votes.max, `Maximum ${siteConfig.votes.max} votes per payment`),
  phone: phoneSchema,
  email: optionalEmail,
  channel: z.enum(["WEB", "PWA"]).default("WEB"),
});
export type InitiateVoteInput = z.infer<typeof initiateVoteSchema>;

export const nominationSchema = z.object({
  eventId: z.string().uuid(),
  categoryId: z.string().uuid("Choose a category"),
  name: z.string().trim().min(2, "Enter the nominee's full name").max(80),
  email: optionalEmail,
  phone: z
    .union([phoneSchema, z.literal("")])
    .optional()
    .transform((v) => (v ? v : undefined)),
  bio: z
    .string()
    .trim()
    .max(600, "Keep the bio under 600 characters")
    .optional()
    .transform((v) => (v ? v : undefined)),
});

export const slugSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(3, "URL slug must be at least 3 characters")
  .max(60)
  .regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Use lowercase letters, numbers and single dashes only");

export const eventInputSchema = z
  .object({
    title: z.string().trim().min(3, "Title is too short").max(120),
    slug: slugSchema,
    description: z.string().trim().max(2000).optional().default(""),
    bannerUrl: z.string().url().optional().or(z.literal("")).default(""),
    costPerVote: z.coerce.number().min(0.1, "Minimum GHS 0.10 per vote").max(1000),
    startAt: z.string().refine((v) => !Number.isNaN(Date.parse(v)), "Invalid start date"),
    endAt: z.string().refine((v) => !Number.isNaN(Date.parse(v)), "Invalid end date"),
    showLiveVotes: z.boolean(),
    allowPublicNominations: z.boolean(),
    categories: z
      .array(z.string().trim().min(2).max(80))
      .max(50)
      .default([])
      .transform((arr) => Array.from(new Set(arr))),
    submit: z.boolean().default(true),
  })
  .refine((v) => Date.parse(v.endAt) > Date.parse(v.startAt), {
    message: "End date must be after the start date",
    path: ["endAt"],
  });
export type EventInput = z.infer<typeof eventInputSchema>;

export const eventSettingsSchema = z
  .object({
    title: z.string().trim().min(3).max(120),
    description: z.string().trim().max(2000).default(""),
    bannerUrl: z.string().url().optional().or(z.literal("")).default(""),
    costPerVote: z.coerce.number().min(0.1).max(1000),
    startAt: z.string().refine((v) => !Number.isNaN(Date.parse(v))),
    endAt: z.string().refine((v) => !Number.isNaN(Date.parse(v))),
    showLiveVotes: z.boolean(),
    allowPublicNominations: z.boolean(),
  })
  .refine((v) => Date.parse(v.endAt) > Date.parse(v.startAt), {
    message: "End date must be after the start date",
    path: ["endAt"],
  });

export const categoryNameSchema = z.string().trim().min(2, "Name is too short").max(80);

export const nomineeInputSchema = z.object({
  eventId: z.string().uuid(),
  categoryId: z.string().uuid("Choose a category"),
  name: z.string().trim().min(2, "Enter the nominee's name").max(80),
  email: optionalEmail,
  bio: z.string().trim().max(600).optional().transform((v) => (v ? v : undefined)),
  photoUrl: z.string().url().optional().or(z.literal("")).transform((v) => (v ? v : undefined)),
});

export const loginSchema = z.object({
  email: z.string().trim().email("Enter a valid email"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const registerSchema = loginSchema.extend({
  fullName: z.string().trim().min(2, "Enter your full name").max(80),
});

export function firstError(error: z.ZodError): string {
  return error.issues[0]?.message ?? "Invalid input";
}
