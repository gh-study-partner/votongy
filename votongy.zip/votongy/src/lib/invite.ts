import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { siteConfig } from "@/config/site";

export interface InviteResult {
  linked: boolean;
  emailSent: boolean;
  message?: string;
}

/**
 * Invites a nominee by email (magic link) and links their auth profile to the nominee row.
 * - New email  -> Supabase sends an invite email; the profile is promoted to NOMINEE.
 * - Existing NOMINEE profile -> just link (they can sign in with a magic link).
 * - Existing organizer/admin email -> not linked (protects privileged accounts).
 */
export async function inviteNominee(params: {
  nomineeId: string;
  email: string;
  name: string;
}): Promise<InviteResult> {
  const admin = createAdminClient();
  const email = params.email.trim().toLowerCase();

  const { data: existing } = await admin
    .from("profiles")
    .select("id, role")
    .ilike("email", email)
    .maybeSingle();

  let userId: string;
  let emailSent = false;

  if (existing) {
    if (existing.role !== "NOMINEE") {
      return {
        linked: false,
        emailSent: false,
        message: "That email belongs to an organizer or admin account, so no nominee login was created.",
      };
    }
    userId = existing.id as string;
  } else {
    const { data, error } = await admin.auth.admin.inviteUserByEmail(email, {
      redirectTo: `${siteConfig.url}/auth/callback?next=/nominee`,
      data: { full_name: params.name },
    });
    if (error || !data?.user) {
      return {
        linked: false,
        emailSent: false,
        message: error?.message ?? "Could not send the invite email.",
      };
    }
    userId = data.user.id;
    emailSent = true;

    // app_metadata is not user-editable, so the role is safe to trust.
    await admin.auth.admin.updateUserById(userId, { app_metadata: { role: "NOMINEE" } });
    // The profile row is created by a DB trigger as ORGANIZER; promote it (service role bypasses the guard).
    await admin
      .from("profiles")
      .update({ role: "NOMINEE", is_approved: true, full_name: params.name })
      .eq("id", userId);
  }

  await admin.from("nominees").update({ user_id: userId }).eq("id", params.nomineeId);
  return { linked: true, emailSent };
}
