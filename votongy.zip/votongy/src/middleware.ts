import { NextResponse, type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";
import { requiredRoleForPath, roleHome } from "@/lib/roles";
import { safeNext } from "@/lib/utils";

/**
 * Role-based access control, layer 1 (layer 2 = requireRole() in layouts, layer 3 = Postgres RLS).
 *   /admin/*      -> SUPER_ADMIN
 *   /organizer/*  -> ORGANIZER
 *   /nominee/*    -> NOMINEE
 *   /login        -> bounce signed-in users to their dashboard
 */
export async function middleware(request: NextRequest) {
  const { supabase, user, state } = await updateSession(request);
  const { pathname } = request.nextUrl;

  const redirect = (path: string, params?: Record<string, string>) => {
    const url = request.nextUrl.clone();
    url.pathname = path;
    url.search = "";
    if (params) for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
    const res = NextResponse.redirect(url);
    // carry over any refreshed auth cookies
    state.response.cookies.getAll().forEach((cookie) => res.cookies.set(cookie));
    return res;
  };

  const requiredRole = requiredRoleForPath(pathname);

  if (!user) {
    if (requiredRole) return redirect("/login", { next: pathname });
    return state.response;
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .maybeSingle();

  const role = (profile?.role as string | undefined) ?? null;

  if (pathname === "/login") {
    if (!role) return state.response; // let them see the login page (e.g. broken profile)
    const next = safeNext(request.nextUrl.searchParams.get("next"), roleHome(role));
    const nextRole = requiredRoleForPath(next);
    const target = nextRole && nextRole !== role ? roleHome(role) : next;
    return redirect(target);
  }

  if (requiredRole && role !== requiredRole) {
    if (!role) return redirect("/login", { error: "no-profile" });
    return redirect(roleHome(role));
  }

  return state.response;
}

export const config = {
  matcher: ["/admin/:path*", "/organizer/:path*", "/nominee/:path*", "/login"],
};
