export const siteConfig = {
  name: "VoTongy",
  tagline: "Vote. Nominate. Celebrate.",
  description:
    "Ghana's fastest event e-voting and nomination platform. Vote with MTN MoMo, Telecel Cash, AirtelTigo Money or card, secured by Paystack.",
  url: (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, ""),
  supportEmail: process.env.NEXT_PUBLIC_SUPPORT_EMAIL ?? "support@votongy.com",
  supportWhatsapp: process.env.NEXT_PUBLIC_SUPPORT_WHATSAPP ?? "",
  legalName: "VoTongy",
  address: "Accra, Ghana",
  legalUpdated: "November 22, 2026",
  currency: "GHS",
  currencySymbol: "GH₵",
  defaultCommissionPct: 10,
  fallbackEmailDomain: "voters.votongy.app",
  theme: {
    primary: "#F59E0B",
    success: "#10B981",
    background: "#09090B",
    card: "#18181B",
    border: "#27272A",
  },
  votes: {
    bundles: [5, 20, 50, 100] as const,
    defaultBundle: 20,
    min: 1,
    max: 10000,
  },
  media: {
    bucket: "votongy-media",
    maxImageBytes: 3 * 1024 * 1024,
    allowedImageTypes: ["image/jpeg", "image/png", "image/webp"] as const,
  },
} as const;

export type SiteConfig = typeof siteConfig;
