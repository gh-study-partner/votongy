import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Lock } from "lucide-react";
import { PublicShell } from "@/components/layout/PublicShell";
import { NominationForm } from "@/components/nominate/NominationForm";
import { getEventBySlug, getEventCatalog } from "@/lib/data";

export const revalidate = 30;

type Params = { eventSlug: string };

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { eventSlug } = await params;
  const event = await getEventBySlug(eventSlug);
  return { title: event ? `Nominate - ${event.title}` : "Nominate" };
}

export default async function NominatePage({ params }: { params: Promise<Params> }) {
  const { eventSlug } = await params;
  const event = await getEventBySlug(eventSlug);
  if (!event) notFound();

  const { categories } = await getEventCatalog(event.id);
  const closed = !event.allow_public_nominations || event.status === "ENDED" || new Date(event.end_at).getTime() < Date.now();

  return (
    <PublicShell>
      <div className="container max-w-xl py-8 sm:py-12">
        <Link href={`/e/${event.slug}`} className="mb-5 inline-flex items-center gap-1.5 text-sm text-zinc-400 hover:text-white">
          <ArrowLeft className="h-4 w-4" /> Back to {event.title}
        </Link>
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">Nomination portal</p>
        <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight">Nominate for {event.title}</h1>
        <p className="mb-8 mt-2 text-sm text-zinc-400">
          Know someone who deserves recognition? Submit their details below. The organizer reviews every nomination before it goes live.
        </p>

        {closed ? (
          <div className="flex flex-col items-center gap-3 rounded-2xl border border-zinc-800 bg-zinc-900 px-6 py-14 text-center">
            <Lock className="h-8 w-8 text-zinc-500" />
            <h2 className="font-display text-lg font-semibold">Nominations are closed</h2>
            <p className="max-w-sm text-sm text-zinc-400">This event is not accepting public nominations right now.</p>
          </div>
        ) : categories.length === 0 ? (
          <p className="rounded-2xl border border-zinc-800 bg-zinc-900 px-6 py-12 text-center text-zinc-400">
            The organizer hasn&apos;t set up categories yet. Please check back soon.
          </p>
        ) : (
          <div className="rounded-3xl border border-zinc-800 bg-zinc-900 p-5 sm:p-7">
            <NominationForm eventId={event.id} eventSlug={event.slug} categories={categories} />
          </div>
        )}
      </div>
    </PublicShell>
  );
}
