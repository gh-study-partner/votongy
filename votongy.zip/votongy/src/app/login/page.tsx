import type { Metadata } from "next";
import Link from "next/link";
import { VoTongyLogo } from "@/components/brand/VoTongyLogo";
import { LoginForm } from "@/components/auth/LoginForm";
import { safeNext } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Log in",
  description: "Sign in to VoTongy as an organizer, nominee or administrator.",
  robots: { index: false },
};

const ERRORS: Record<string, string> = {
  auth: "That sign-in link is invalid or has expired. Request a new one below.",
  "no-profile": "We couldn't find a profile for your account. Contact support.",
  forbidden: "You don't have access to that area.",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string }>;
}) {
  const sp = await searchParams;
  const next = sp.next ? safeNext(sp.next, "") : "";

  return (
    <div className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden px-4 py-10">
      <div className="bg-grid pointer-events-none absolute inset-x-0 top-0 h-[420px]" aria-hidden />
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/20 blur-[100px]"
        aria-hidden
      />

      <div className="relative z-10 w-full max-w-md">
        <Link href="/" className="mb-8 flex justify-center" aria-label="VoTongy home">
          <VoTongyLogo size={40} />
        </Link>

        <div className="rounded-3xl border border-zinc-800 bg-zinc-900/90 p-6 shadow-2xl shadow-black/50 backdrop-blur sm:p-8">
          <h1 className="font-display text-2xl font-bold tracking-tight">Welcome back</h1>
          <p className="mb-6 mt-1 text-sm text-zinc-400">
            Organizers, nominees and admins sign in here. Voters don&apos;t need an account.
          </p>
          <LoginForm next={next || undefined} initialError={sp.error ? ERRORS[sp.error] ?? undefined : undefined} />
        </div>

        <p className="mt-6 text-center text-sm text-zinc-500">
          Just here to vote?{" "}
          <Link href="/" className="font-semibold text-primary hover:underline">
            Browse events
          </Link>
        </p>
      </div>
    </div>
  );
}
