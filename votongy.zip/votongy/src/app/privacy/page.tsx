import type { Metadata } from "next";
import { LegalPage, LegalSection } from "@/components/layout/LegalPage";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How VoTongy collects, uses and protects your personal data.",
};

export default function PrivacyPage() {
  const n = siteConfig.name;
  return (
    <LegalPage
      title="Privacy Policy"
      intro={`${n} respects your privacy. This policy explains what personal data we collect, why, who we share it with and what your rights are under the Data Protection Act, 2012 (Act 843) of Ghana.`}
    >
      <LegalSection n={1} title="Who we are">
        <p>
          {n}, {siteConfig.address}, is the data controller for personal data processed on the Platform. Contact:{" "}
          <a className="text-primary hover:underline" href={`mailto:${siteConfig.supportEmail}`}>
            {siteConfig.supportEmail}
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection n={2} title="What we collect">
        <ul>
          <li><strong>Voters:</strong> mobile phone number, optional email address, the nominee and event you voted for, number of votes, amount, payment reference, payment status, time, and the channel used (web or installed app). We also process your IP address for security and rate limiting.</li>
          <li><strong>Organizers and nominees:</strong> name, email address, role, account activity, uploaded photos, bios and event details.</li>
          <li><strong>Public nominators:</strong> the name, optional contact details, bio and photo you submit about a nominee.</li>
          <li><strong>Technical data:</strong> device and browser type and basic usage logs needed to keep the Platform secure and working. Our service worker caches static files on your device so the app loads faster.</li>
        </ul>
        <p>
          We <strong>do not</strong> collect or store your Mobile Money PIN, card number, CVV or bank credentials. Those are entered only on Paystack&apos;s secure payment pages.
        </p>
      </LegalSection>

      <LegalSection n={3} title="Why we use your data">
        <ul>
          <li>To process your payment, credit your votes and give you a receipt (performance of a contract).</li>
          <li>To detect and prevent fraud, manipulation and abuse, and to investigate payment problems (legitimate interests and legal obligations).</li>
          <li>To run the accounts and dashboards of organizers and nominees and to send sign-in and invitation emails.</li>
          <li>To produce results, reports and certified exports for event organizers.</li>
          <li>To comply with the law and respond to lawful requests from authorities.</li>
        </ul>
      </LegalSection>

      <LegalSection n={4} title="What is public and what is private">
        <ul>
          <li>Nominee names, photos, bios, codes and (where the organizer allows) vote totals are public.</li>
          <li>Voter identity is <strong>not</strong> public. Receipts and nominee &ldquo;recent votes&rdquo; feeds show only a partly hidden phone number (for example +233****67).</li>
          <li>Organizers see transaction records for their own events. Platform administrators can search transactions to resolve payment issues.</li>
        </ul>
      </LegalSection>

      <LegalSection n={5} title="Who we share data with">
        <ul>
          <li><strong>Paystack</strong>, our payment processor, receives the details needed to complete your payment.</li>
          <li><strong>Supabase</strong> hosts our database, authentication and file storage; <strong>Vercel</strong> hosts the application; <strong>Upstash</strong> provides rate limiting (IP address and phone-number keys, kept briefly).</li>
          <li>Event organizers, as described above, and authorities or professional advisers where the law requires or to protect legal rights.</li>
        </ul>
        <p>We do not sell your personal data. Some of our providers process data outside Ghana; we use providers that apply appropriate safeguards.</p>
      </LegalSection>

      <LegalSection n={6} title="How long we keep it">
        <p>
          We keep transaction records for as long as needed for accounting, dispute resolution, fraud prevention and legal obligations
          (generally at least six years), and account and event data while the account is active. We delete or anonymise data we no longer need.
        </p>
      </LegalSection>

      <LegalSection n={7} title="Security">
        <p>
          We use encrypted connections, row-level database security, server-side payment verification, signed webhooks and rate limiting. No
          system is perfectly secure; if a breach affecting your data occurs, we will notify you and the Data Protection Commission as the law requires.
        </p>
      </LegalSection>

      <LegalSection n={8} title="Your rights">
        <p>Under Act 843 you may ask us to:</p>
        <ul>
          <li>tell you what personal data we hold about you and give you a copy;</li>
          <li>correct inaccurate or incomplete data;</li>
          <li>delete data we no longer have a lawful reason to keep, or restrict or object to certain processing.</li>
        </ul>
        <p>
          Email {siteConfig.supportEmail} with your request and the phone number or email involved. We may need to verify your identity first.
          You may also complain to the Data Protection Commission of Ghana.
        </p>
      </LegalSection>

      <LegalSection n={9} title="Children">
        <p>The Platform is not directed at children under 18. If you believe a child has bought votes without parental consent, contact us and we will review the data.</p>
      </LegalSection>

      <LegalSection n={10} title="Cookies and local storage">
        <p>
          We use essential cookies to keep organizers, nominees and admins signed in. We store small items in your browser (for example your last-used
          phone number, to speed up checkout, and whether you dismissed the app-install banner). Clearing your browser data removes them.
        </p>
      </LegalSection>

      <LegalSection n={11} title="Changes">
        <p>We may update this policy and will show the new date at the top of this page.</p>
      </LegalSection>
    </LegalPage>
  );
}
