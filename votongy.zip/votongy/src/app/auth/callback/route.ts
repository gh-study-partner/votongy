import { NextResponse, type NextRequest } from "next/server";
import type { EmailOtpType } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import { safeNext } from "@/lib/utils";

export const dynamic = "force-dynamic";

/**
 * Handles both Supabase email flows:
 *   - PKCE:      /auth/callback?code=...
 *   - Token hash (invites, magic links with custom templates):
 *                /auth/callback?token_hash=...&type=invite|magiclink|signup|recovery|email
 */
export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const tokenHash = searchParams.get("token_hash");
  const type = searchParams.get("type") as EmailOtpType | null;
  const next = safeNext(searchParams.get("next"), "/login");

  const supabase = await createClient();
  let failed = true;

  if (code) {
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    failed = Boolean(error);
  } else if (tokenHash && type) {
    const { error } = await supabase.auth.verifyOtp({ type, token_hash: tokenHash });
    failed = Boolean(error);
  }

  if (failed) return NextResponse.redirect(`${origin}/login?error=auth`);
  return NextResponse.redirect(`${origin}${next}`);
}
