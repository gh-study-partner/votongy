import type { Metadata } from "next";
import { LegalPage, LegalSection } from "@/components/layout/LegalPage";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: "The rules for using VoTongy to vote, nominate and organize events in Ghana.",
};

export default function TermsPage() {
  const n = siteConfig.name;
  return (
    <LegalPage
      title="Terms & Conditions"
      intro={`These Terms govern your use of ${n} (the "Platform"), operated from ${siteConfig.address}. By voting, nominating, creating an account or otherwise using the Platform you agree to these Terms. If you do not agree, please do not use the Platform.`}
    >
      <LegalSection n={1} title="What VoTongy does">
        <p>
          {n} is a technology platform that lets independent event organizers run paid voting and nomination campaigns, and lets the public vote for
          nominees. {n} is not the organizer of any event listed on it. Each organizer is solely responsible for the content, rules, eligibility
          criteria and outcome of their event.
        </p>
      </LegalSection>

      <LegalSection n={2} title="Eligibility and accounts">
        <ul>
          <li>You must be at least 18 years old, or have the consent of a parent or guardian, to purchase votes.</li>
          <li>Voters do not need an account. Organizers and nominees sign in with the email address used for their account or invitation.</li>
          <li>Organizer accounts must be approved by {n} before events can be published. We may refuse, suspend or remove any account at our discretion.</li>
          <li>You are responsible for keeping your login credentials secure and for all activity under your account.</li>
        </ul>
      </LegalSection>

      <LegalSection n={3} title="Buying votes and payments">
        <ul>
          <li>Each event sets its own price per vote, shown in Ghana Cedis (GHS) before you pay. The total is calculated by our servers and cannot be altered by the user.</li>
          <li>Payments are processed by <strong>Paystack</strong> using Mobile Money (MTN MoMo, Telecel Cash, AirtelTigo Money) or card. We do not see or store your PIN, card number or Mobile Money credentials.</li>
          <li>Network charges, mobile operator fees or card issuer fees, where they apply, are set by those providers.</li>
          <li>Votes are credited to the nominee <strong>only after Paystack confirms your payment</strong> to our servers. We never rely on your browser or app to tell us a payment succeeded.</li>
          <li>Your receipt reference is your proof of payment. Keep it until the event results are announced.</li>
        </ul>
      </LegalSection>

      <LegalSection n={4} title="All votes are final and non-refundable">
        <p>
          Once a payment is confirmed and votes are credited, <strong>the transaction is final. Votes cannot be cancelled, transferred, changed to
          another nominee, or refunded</strong>, including where you voted for the wrong nominee, changed your mind, or the nominee is later
          disqualified, except as stated in our{" "}
          <a href="/refund-policy" className="font-semibold text-primary hover:underline">
            Refund Policy
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection n={5} title="Network delays and pending payments">
        <ul>
          <li>Mobile networks and payment systems can be slow. A confirmation may take several minutes to arrive.</li>
          <li><strong>If you were debited but your votes do not show, do not pay again.</strong> Open your receipt page or use the &ldquo;Verify vote receipt&rdquo; tool on the home page. Our system re-checks pending payments with Paystack automatically.</li>
          <li>{n} is not liable for delays, failures or interruptions caused by mobile network operators, Paystack, internet providers, your device or events beyond our reasonable control.</li>
          <li>Votes paid for before the event closes will be counted if Paystack confirms the payment as successful, even if confirmation arrives shortly after the closing time. Payments initiated after the closing time are not accepted.</li>
        </ul>
      </LegalSection>

      <LegalSection n={6} title="Fair play and anti-fraud rules">
        <p>You must not, and must not help anyone to:</p>
        <ul>
          <li>use stolen, unauthorised or fraudulent payment methods, or make payments you intend to dispute or charge back;</li>
          <li>use bots, scripts, automated tools, multiple accounts or any technique to manipulate vote counts or bypass rate limits;</li>
          <li>attempt to access, probe, overload or interfere with the Platform, its databases, webhooks or payment flows;</li>
          <li>submit false, defamatory, infringing or unlawful nominations or content; or</li>
          <li>impersonate another person or organisation.</li>
        </ul>
        <p>
          We use automated checks and manual review. Where we reasonably suspect fraud or manipulation, we may flag, withhold or remove votes,
          suspend voting, <strong>disqualify nominees</strong> who benefit from it, suspend or terminate accounts, report the matter to the
          relevant authorities including the Ghana Police Service and the payment provider, and recover any losses from the responsible party.
        </p>
      </LegalSection>

      <LegalSection n={7} title="Emergency pause and event changes">
        <p>
          {n} may pause voting on any event or across the whole Platform at any time to investigate fraud, protect the integrity of results,
          comply with the law, or address technical or security issues. Organizers may pause, resume or end their own events within the limits the Platform allows.
          Event dates and rules can change; the information shown on the event page at the time you pay applies.
        </p>
      </LegalSection>

      <LegalSection n={8} title="Organizers">
        <ul>
          <li>Organizers must have the right to run their event, and the rights and consent needed for every nominee, photo and description they upload.</li>
          <li>Organizers are responsible for prizes, adjudication, announcements and compliance with applicable laws, licences and taxes.</li>
          <li>{n} charges a platform commission on successful vote revenue, shown in the organizer dashboard (the default is {siteConfig.defaultCommissionPct}%). Revenue settlement terms are agreed with {n} separately.</li>
          <li>Certified results exports reflect the vote data held by {n} at the time of export.</li>
        </ul>
      </LegalSection>

      <LegalSection n={9} title="Nominees and nominations">
        <p>
          Public nominations are suggestions only and are reviewed by the organizer, who may accept or reject them without giving reasons. By being
          nominated or invited, nominees agree that their name, photo and bio may be displayed publicly on the Platform for the event.
        </p>
      </LegalSection>

      <LegalSection n={10} title="Intellectual property">
        <p>
          The VoTongy name, logo, software and design belong to {n}. Organizers and nominees keep ownership of the content they upload and grant {n} a
          non-exclusive licence to host and display it for the purposes of the event.
        </p>
      </LegalSection>

      <LegalSection n={11} title="Disclaimers and limitation of liability">
        <ul>
          <li>The Platform is provided &ldquo;as is&rdquo;. We work hard to keep it accurate and available but do not promise uninterrupted or error-free service.</li>
          <li>We do not guarantee that any nominee will win, and we are not responsible for decisions, judging or prizes of an event organizer.</li>
          <li>To the fullest extent permitted by Ghanaian law, our total liability to you for any claim relating to the Platform is limited to the amount you paid for the votes that the claim concerns. Nothing in these Terms excludes liability that cannot lawfully be excluded.</li>
        </ul>
      </LegalSection>

      <LegalSection n={12} title="Privacy">
        <p>
          We handle personal data in line with the Data Protection Act, 2012 (Act 843) as described in our{" "}
          <a href="/privacy" className="font-semibold text-primary hover:underline">
            Privacy Policy
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection n={13} title="Suspension and termination">
        <p>
          We may suspend or end your access at any time if you breach these Terms or if we must do so by law. Sections that by their nature should
          survive termination (including payment finality, fair play, intellectual property and liability) will continue to apply.
        </p>
      </LegalSection>

      <LegalSection n={14} title="Changes to these Terms">
        <p>
          We may update these Terms from time to time. The latest version is always on this page with its &ldquo;last updated&rdquo; date. Continued
          use of the Platform after a change means you accept the updated Terms.
        </p>
      </LegalSection>

      <LegalSection n={15} title="Governing law and disputes">
        <p>
          These Terms are governed by the laws of the Republic of Ghana, including the Electronic Transactions Act, 2008 (Act 772). Please contact
          us first so we can try to resolve any dispute informally. If we cannot, the courts of Ghana have jurisdiction, subject to any mandatory
          consumer protections that apply to you.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
