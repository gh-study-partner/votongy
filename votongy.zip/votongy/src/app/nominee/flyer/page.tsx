import Link from "next/link";
import { PageHeader } from "@/components/dashboard/DashboardShell";
import { FlyerCanvas, type FlyerEntry } from "@/components/dashboard/FlyerCanvas";
import { Button } from "@/components/ui/button";
import { requireRole } from "@/lib/auth";
import { getMyNomineeEntries } from "@/lib/nominee-data";
import { eventVoteUrl } from "@/lib/utils";

export const metadata = { title: "Promo flyer" };

export default async function FlyerPage() {
  const profile = await requireRole(["NOMINEE"]);
  const entries = await getMyNomineeEntries(profile.id);

  const flyers: FlyerEntry[] = entries
    .filter((e) => e.event && e.code)
    .map((e) => {
      const url = eventVoteUrl(e.event!.slug, e.code);
      return {
        id: e.nomineeId,
        name: e.name,
        code: e.code,
        category: e.categoryName,
        eventTitle: e.event!.title,
        photoUrl: e.photoUrl,
        voteUrl: url,
        displayUrl: url.replace(/^https?:\/\//, ""),
      };
    });

  return (
    <>
      <PageHeader title="Promo flyer generator" description="Download a ready-to-post graphic with your photo, code and voting link." />
      {flyers.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-zinc-800 px-6 py-16 text-center">
          <p className="font-display text-lg font-semibold">Your flyer will be ready once your event is live</p>
          <p className="mx-auto mt-1 max-w-md text-sm text-zinc-400">
            We need an approved, live event to create your voting link. Check back after the organizer publishes it.
          </p>
          <Button asChild variant="outline" className="mt-5">
            <Link href="/nominee">Back to my rank</Link>
          </Button>
        </div>
      ) : (
        <FlyerCanvas entries={flyers} />
      )}
    </>
  );
}
