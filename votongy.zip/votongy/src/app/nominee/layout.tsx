import type { Metadata } from "next";
import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { requireRole } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: { default: "My nomination", template: "%s | VoTongy" }, robots: { index: false } };

export default async function NomineeLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireRole(["NOMINEE"]);
  return (
    <DashboardShell
      roleLabel="Nominee"
      userName={profile.full_name ?? "Nominee"}
      email={profile.email}
      items={[
        { href: "/nominee", label: "My rank", icon: "trophy", exact: true },
        { href: "/nominee/flyer", label: "Promo flyer", icon: "flyer" },
      ]}
    >
      {children}
    </DashboardShell>
  );
}
