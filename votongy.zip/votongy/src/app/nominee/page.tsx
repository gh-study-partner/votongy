import Link from "next/link";
import { Crown, EyeOff, ImageIcon, Share2, TrendingUp } from "lucide-react";
import { PageHeader } from "@/components/dashboard/DashboardShell";
import { CopyButton } from "@/components/dashboard/CopyButton";
import { Avatar } from "@/components/voting/Avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getMyNomineeEntries } from "@/lib/nominee-data";
import { eventVoteUrl, formatNumber, timeAgo, whatsappShareUrl } from "@/lib/utils";
import type { RecentVote } from "@/types/database";

export const metadata = { title: "My rank" };

function ordinal(n: number) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
}

export default async function NomineeDashboardPage() {
  const profile = await requireRole(["NOMINEE"]);
  const entries = await getMyNomineeEntries(profile.id);
  const supabase = await createClient();

  const feeds = await Promise.all(
    entries.map(async (e) => {
      const { data } = await supabase.rpc("nominee_recent_votes", { p_nominee_id: e.nomineeId, p_limit: 12 });
      return (data ?? []) as RecentVote[];
    }),
  );

  if (entries.length === 0) {
    return (
      <>
        <PageHeader title="Welcome to VoTongy" />
        <div className="rounded-3xl border border-dashed border-zinc-800 px-6 py-16 text-center">
          <p className="font-display text-lg font-semibold">No nominations linked to this login yet</p>
          <p className="mx-auto mt-1 max-w-md text-sm text-zinc-400">
            Ask your event organizer to add you using the email address you signed in with. Your rank, voting link and promo flyer will appear here.
          </p>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader title={`Hi, ${profile.full_name?.split(" ")[0] ?? "nominee"}`} description="Track your votes and rally your supporters." />

      <div className="space-y-10">
        {entries.map((e, i) => {
          const voteUrl = e.event ? eventVoteUrl(e.event.slug, e.code) : null;
          const shareText = voteUrl ? `Vote for ${e.name} (${e.code}) in ${e.event?.title} on VoTongy: ${voteUrl}` : "";
          const feed = feeds[i] ?? [];
          const leading = e.rank === 1 && e.totalVotes > 0;

          return (
            <section key={e.nomineeId} className="space-y-4">
              {/* Hero rank card */}
              <div className="relative overflow-hidden rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 p-6 sm:p-8">
                <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-primary/15 blur-[80px]" aria-hidden />
                <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
                  <div className="h-28 w-28 shrink-0 overflow-hidden rounded-3xl border border-zinc-700 bg-zinc-800 sm:h-32 sm:w-32">
                    <Avatar src={e.photoUrl} name={e.name} rounded="rounded-3xl" className="text-3xl" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="default">{e.code}</Badge>
                      <Badge variant="muted">{e.categoryName}</Badge>
                      {e.status !== "APPROVED" && <Badge variant="warning">Not on ballot</Badge>}
                    </div>
                    <h2 className="mt-2 truncate font-display text-2xl font-extrabold tracking-tight sm:text-3xl">{e.name}</h2>
                    <p className="text-sm text-zinc-400">{e.event?.title ?? "Event not live yet"}</p>

                    <div className="mt-5 grid grid-cols-3 gap-3">
                      <div className="rounded-2xl bg-zinc-950/80 p-3.5">
                        <p className="text-xs text-zinc-500">Rank</p>
                        {e.rank ? (
                          <p className="mt-1 flex items-center gap-1.5 font-display text-2xl font-extrabold">
                            {leading && <Crown className="h-5 w-5 text-primary" />}
                            #{e.rank}
                            <span className="text-xs font-medium text-zinc-500">of {e.rankOf}</span>
                          </p>
                        ) : (
                          <p className="mt-1 flex items-center gap-1 text-sm text-zinc-500"><EyeOff className="h-4 w-4" /> Hidden</p>
                        )}
                      </div>
                      <div className="rounded-2xl bg-zinc-950/80 p-3.5">
                        <p className="text-xs text-zinc-500">Total votes</p>
                        <p className="mt-1 font-display text-2xl font-extrabold tabular-nums text-primary">{formatNumber(e.totalVotes)}</p>
                      </div>
                      <div className="rounded-2xl bg-zinc-950/80 p-3.5">
                        <p className="text-xs text-zinc-500">Vote share</p>
                        {e.sharePct !== null ? (
                          <p className="mt-1 font-display text-2xl font-extrabold tabular-nums">{e.sharePct.toFixed(1)}%</p>
                        ) : (
                          <p className="mt-1 flex items-center gap-1 text-sm text-zinc-500"><EyeOff className="h-4 w-4" /> Hidden</p>
                        )}
                      </div>
                    </div>

                    {e.rank && e.rank > 1 && e.votesToLeader !== null && (
                      <p className="mt-4 flex items-center gap-2 text-sm text-zinc-300">
                        <TrendingUp className="h-4 w-4 text-emerald-400" />
                        You&apos;re {ordinal(e.rank)} in {e.categoryName}, {formatNumber(e.votesToLeader)} votes behind the leader. Share your link!
                      </p>
                    )}
                    {leading && <p className="mt-4 text-sm font-semibold text-primary">You&apos;re leading your category. Keep the momentum going!</p>}
                    {e.countsHidden && <p className="mt-4 text-xs text-zinc-500">The organizer hides rankings until voting ends. Your own vote total is always visible to you.</p>}
                  </div>
                </div>
              </div>

              {/* Share tools */}
              {voteUrl ? (
                <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
                  <h3 className="font-display text-base font-bold">Your direct voting link</h3>
                  <p className="mt-0.5 text-sm text-zinc-400">Opens straight to you with the vote checkout ready. Perfect for WhatsApp status and Instagram bio.</p>
                  <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
                    <code className="min-w-0 flex-1 truncate rounded-xl bg-zinc-950 px-3 py-2.5 text-xs text-zinc-300">{voteUrl}</code>
                    <div className="flex flex-wrap gap-2">
                      <CopyButton value={voteUrl} label="Copy link" variant="default" size="default" />
                      <Button asChild variant="success">
                        <a href={whatsappShareUrl(shareText)} target="_blank" rel="noopener noreferrer">
                          <Share2 className="h-4 w-4" /> WhatsApp
                        </a>
                      </Button>
                      <Button asChild variant="outline">
                        <Link href="/nominee/flyer">
                          <ImageIcon className="h-4 w-4" /> Make flyer
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5 text-sm text-zinc-400">Your voting link will appear once the event is approved and live.</p>
              )}

              {/* Anonymized feed */}
              <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
                <h3 className="font-display text-base font-bold">Recent votes</h3>
                <p className="mb-3 mt-0.5 text-sm text-zinc-400">Voter numbers are partly hidden to protect privacy.</p>
                {feed.length === 0 ? (
                  <p className="py-6 text-center text-sm text-zinc-500">No votes yet. Share your link to get the first one!</p>
                ) : (
                  <ul className="divide-y divide-zinc-800">
                    {feed.map((v, idx) => (
                      <li key={`${v.paid_at}-${idx}`} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                        <span className="font-mono text-xs text-zinc-400">{v.voter_masked}</span>
                        <span className="font-semibold text-primary">+{formatNumber(v.votes)} vote{v.votes === 1 ? "" : "s"}</span>
                        <span className="text-xs text-zinc-500">{timeAgo(v.paid_at)}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </section>
          );
        })}
      </div>
    </>
  );
}
