import type { Metadata } from "next";
import Link from "next/link";
import { Smartphone, ShieldCheck, Zap } from "lucide-react";
import { PublicShell } from "@/components/layout/PublicShell";
import { InstallAppPrompt } from "@/components/pwa/InstallAppPrompt";
import { GlobalSearch } from "@/components/search/GlobalSearch";
import { ReceiptLookup } from "@/components/receipt/ReceiptLookup";
import { EventCard } from "@/components/voting/EventCard";
import { Button } from "@/components/ui/button";
import { getPublicEvents } from "@/lib/data";
import { computeVotingState } from "@/lib/utils";
import { siteConfig } from "@/config/site";

// ISR: the event list is served instantly from the edge cache and refreshed every 30s.
export const revalidate = 30;

export const metadata: Metadata = {
  title: `${siteConfig.name} - Vote with Mobile Money`,
  description: siteConfig.description,
};

export default async function HomePage() {
  const events = await getPublicEvents(30);

  const order = { open: 0, upcoming: 1, paused: 2, ended: 3 } as const;
  const sorted = [...events].sort((a, b) => {
    const sa = order[computeVotingState(a)];
    const sb = order[computeVotingState(b)];
    return sa !== sb ? sa - sb : new Date(b.end_at).getTime() - new Date(a.end_at).getTime();
  });

  const searchEvents = events.map((e) => ({ id: e.id, slug: e.slug, title: e.title }));

  return (
    <PublicShell>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="bg-grid pointer-events-none absolute inset-x-0 top-0 h-[480px]" aria-hidden />
        <div
          className="pointer-events-none absolute left-1/2 top-[-120px] h-80 w-[560px] -translate-x-1/2 rounded-full bg-primary/20 blur-[110px]"
          aria-hidden
        />
        <div className="container relative z-10 flex flex-col items-center py-14 text-center sm:py-20">
          <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/80 px-3.5 py-1.5 text-xs font-semibold text-zinc-300 backdrop-blur">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            MTN MoMo · Telecel Cash · AirtelTigo Money · Cards
          </span>
          <h1 className="max-w-3xl font-display text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
            Your vote. <span className="text-gradient-gold">Your favourite.</span> Instantly counted.
          </h1>
          <p className="mt-5 max-w-xl text-base text-zinc-400 sm:text-lg">
            Ghana&apos;s fastest e-voting platform for awards, pageants and school and campus polls. No account needed.
            Pick a nominee, approve on your phone, done.
          </p>

          <div className="mt-8 w-full">
            <GlobalSearch events={searchEvents} />
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Button asChild size="lg">
              <Link href="#events">Browse live events</Link>
            </Button>
            <InstallAppPrompt variant="button" size="lg" label="Install VoTongy App" />
          </div>

          <ul className="mt-10 grid w-full max-w-3xl gap-3 text-left sm:grid-cols-3">
            {[
              { icon: Zap, title: "Instant counting", text: "Votes land the moment your payment is confirmed." },
              { icon: ShieldCheck, title: "Fraud-proof", text: "Every payment is verified server-side with Paystack." },
              { icon: Smartphone, title: "Built for phones", text: "Open a WhatsApp link and vote in under a minute." },
            ].map(({ icon: Icon, title, text }) => (
              <li key={title} className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 backdrop-blur">
                <Icon className="mb-2 h-5 w-5 text-primary" />
                <p className="text-sm font-semibold">{title}</p>
                <p className="mt-0.5 text-sm text-zinc-400">{text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Events bento grid */}
      <section id="events" className="container scroll-mt-20 py-12">
        <div className="mb-6 flex items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">Events</h2>
            <p className="mt-1 text-sm text-zinc-400">Tap an event to see nominees and vote.</p>
          </div>
        </div>

        {sorted.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-zinc-800 bg-zinc-900/40 px-6 py-16 text-center">
            <p className="font-display text-lg font-semibold">No events are live yet</p>
            <p className="mx-auto mt-1 max-w-sm text-sm text-zinc-400">
              Organizing an event? Create an organizer account and launch your voting page in minutes.
            </p>
            <Button asChild className="mt-5">
              <Link href="/login">Become an organizer</Link>
            </Button>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {sorted.map((event, i) => (
              <EventCard key={event.id} event={event} featured={i === 0 && sorted.length > 2} />
            ))}
          </div>
        )}
      </section>

      {/* Receipt verification */}
      <section id="verify" className="container scroll-mt-20 pb-16">
        <div className="rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-900 to-zinc-950 p-6 sm:p-10">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">Verify your vote receipt</h2>
            <p className="mb-6 mt-2 text-sm text-zinc-400">
              Paid but not sure it counted? Enter the reference from your receipt or Paystack SMS to check the status instantly.
            </p>
            <ReceiptLookup />
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
