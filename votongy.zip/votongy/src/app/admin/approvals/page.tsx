import { CheckCircle2, ShieldAlert } from "lucide-react";
import { PageHeader } from "@/components/dashboard/DashboardShell";
import { SubmitButton } from "@/components/dashboard/SubmitButton";
import { StatusBadge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { createClient } from "@/lib/supabase/server";
import { formatDate, formatDateTime, formatGHS } from "@/lib/utils";
import { reviewEvent, reviewOrganizer, setEventStatus } from "../actions";

export const metadata = { title: "Approvals" };

interface PendingEvent {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  cost_per_vote: number;
  commission_pct: number;
  start_at: string;
  end_at: string;
  created_at: string;
  profiles: { full_name: string | null; email: string } | null;
}

interface OrganizerRow {
  id: string;
  full_name: string | null;
  email: string;
  is_approved: boolean;
  created_at: string;
}

interface LiveEvent {
  id: string;
  title: string;
  status: string;
}

export default async function ApprovalsPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string }>;
}) {
  const sp = await searchParams;
  const supabase = await createClient();

  const [eventsRes, orgsRes, liveRes] = await Promise.all([
    supabase
      .from("events")
      .select("id, title, slug, description, cost_per_vote, commission_pct, start_at, end_at, created_at, profiles:organizer_id(full_name, email)")
      .eq("status", "PENDING_APPROVAL")
      .order("created_at", { ascending: true }),
    supabase.from("profiles").select("id, full_name, email, is_approved, created_at").eq("role", "ORGANIZER").order("created_at", { ascending: false }).limit(100),
    supabase.from("events").select("id, title, status").in("status", ["ACTIVE", "PAUSED"]).order("created_at", { ascending: false }).limit(50),
  ]);

  const events = (eventsRes.data ?? []) as unknown as PendingEvent[];
  const organizers = (orgsRes.data ?? []) as OrganizerRow[];
  const pendingOrgs = organizers.filter((o) => !o.is_approved);
  const approvedOrgs = organizers.filter((o) => o.is_approved);
  const live = (liveRes.data ?? []) as LiveEvent[];

  return (
    <>
      <PageHeader title="Approvals" description="Review organizer accounts and events before they go live." />

      {sp.ok && (
        <p role="status" className="mb-5 flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-300">
          <CheckCircle2 className="h-4 w-4" /> {sp.ok}
        </p>
      )}
      {sp.error && (
        <p role="alert" className="mb-5 flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
          <ShieldAlert className="h-4 w-4" /> {sp.error}
        </p>
      )}

      <div className="space-y-10">
        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Events awaiting approval ({events.length})</h2>
          {events.length === 0 ? (
            <p className="rounded-2xl border border-dashed border-zinc-800 px-4 py-8 text-center text-sm text-zinc-500">No events waiting.</p>
          ) : (
            <div className="space-y-3">
              {events.map((e) => (
                <article key={e.id} className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="font-display text-base font-bold">{e.title}</h3>
                      <p className="text-xs text-zinc-500">/e/{e.slug}</p>
                      <p className="mt-1 text-sm text-zinc-400">
                        By {e.profiles?.full_name ?? "Unknown"} ({e.profiles?.email ?? "-"}) · submitted {formatDate(e.created_at)}
                      </p>
                    </div>
                    <StatusBadge status="PENDING_APPROVAL" />
                  </div>
                  {e.description && <p className="mt-3 line-clamp-3 text-sm text-zinc-300">{e.description}</p>}
                  <dl className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm text-zinc-400">
                    <div><dt className="inline">Price: </dt><dd className="inline font-semibold text-zinc-200">{formatGHS(e.cost_per_vote)}/vote</dd></div>
                    <div><dt className="inline">Window: </dt><dd className="inline font-semibold text-zinc-200">{formatDateTime(e.start_at)} to {formatDateTime(e.end_at)}</dd></div>
                  </dl>

                  <div className="mt-4 flex flex-wrap items-end gap-3 border-t border-zinc-800 pt-4">
                    <form action={reviewEvent} className="flex flex-wrap items-end gap-3">
                      <input type="hidden" name="id" value={e.id} />
                      <input type="hidden" name="decision" value="approve" />
                      <label className="text-xs font-medium text-zinc-400">
                        Platform commission %
                        <Input name="commission" type="number" min={0} max={100} step="0.5" defaultValue={e.commission_pct} className="mt-1 h-10 w-28" />
                      </label>
                      <SubmitButton variant="success">Approve &amp; go live</SubmitButton>
                    </form>
                    <form action={reviewEvent}>
                      <input type="hidden" name="id" value={e.id} />
                      <input type="hidden" name="decision" value="reject" />
                      <SubmitButton variant="destructive">Reject</SubmitButton>
                    </form>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Organizers awaiting approval ({pendingOrgs.length})</h2>
          {pendingOrgs.length === 0 ? (
            <p className="rounded-2xl border border-dashed border-zinc-800 px-4 py-8 text-center text-sm text-zinc-500">No organizers waiting.</p>
          ) : (
            <ul className="space-y-2">
              {pendingOrgs.map((o) => (
                <li key={o.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-zinc-800 bg-zinc-900 p-4">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{o.full_name ?? "(no name)"}</p>
                    <p className="truncate text-sm text-zinc-400">{o.email} · joined {formatDate(o.created_at)}</p>
                  </div>
                  <form action={reviewOrganizer}>
                    <input type="hidden" name="id" value={o.id} />
                    <input type="hidden" name="decision" value="approve" />
                    <SubmitButton variant="success" size="sm">Approve organizer</SubmitButton>
                  </form>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Approved organizers ({approvedOrgs.length})</h2>
          {approvedOrgs.length === 0 ? (
            <p className="text-sm text-zinc-500">None yet.</p>
          ) : (
            <ul className="divide-y divide-zinc-800 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900">
              {approvedOrgs.map((o) => (
                <li key={o.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{o.full_name ?? "(no name)"}</p>
                    <p className="truncate text-xs text-zinc-500">{o.email}</p>
                  </div>
                  <form action={reviewOrganizer}>
                    <input type="hidden" name="id" value={o.id} />
                    <input type="hidden" name="decision" value="revoke" />
                    <SubmitButton variant="ghost" size="sm">Revoke access</SubmitButton>
                  </form>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Moderate live events</h2>
          {live.length === 0 ? (
            <p className="text-sm text-zinc-500">No live events.</p>
          ) : (
            <ul className="divide-y divide-zinc-800 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900">
              {live.map((e) => (
                <li key={e.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <p className="text-sm font-semibold">{e.title}</p>
                    <StatusBadge status={e.status} />
                  </div>
                  <div className="flex gap-2">
                    <form action={setEventStatus}>
                      <input type="hidden" name="id" value={e.id} />
                      <input type="hidden" name="status" value={e.status === "ACTIVE" ? "PAUSED" : "ACTIVE"} />
                      <SubmitButton variant="outline" size="sm">{e.status === "ACTIVE" ? "Pause event" : "Resume event"}</SubmitButton>
                    </form>
                    <form action={setEventStatus}>
                      <input type="hidden" name="id" value={e.id} />
                      <input type="hidden" name="status" value="ENDED" />
                      <SubmitButton variant="ghost" size="sm">End</SubmitButton>
                    </form>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </>
  );
}
