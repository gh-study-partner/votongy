"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireRole } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { logAudit } from "@/lib/audit";

function back(message: string, kind: "error" | "ok" = "ok"): never {
  redirect(`/admin/approvals?${kind}=${encodeURIComponent(message)}`);
}

/** Approve or reject an organizer account. Service role is used so the profile guard trigger is satisfied. */
export async function reviewOrganizer(formData: FormData): Promise<void> {
  const admin = await requireRole(["SUPER_ADMIN"]);
  const parsed = z
    .object({ id: z.string().uuid(), decision: z.enum(["approve", "revoke"]) })
    .safeParse({ id: formData.get("id"), decision: formData.get("decision") });
  if (!parsed.success) back("Invalid request.", "error");

  const svc = createAdminClient();
  const { error } = await svc
    .from("profiles")
    .update({ is_approved: parsed.data!.decision === "approve" })
    .eq("id", parsed.data!.id)
    .eq("role", "ORGANIZER");
  if (error) back(error.message, "error");

  await logAudit({
    actorId: admin.id,
    action: parsed.data!.decision === "approve" ? "ORGANIZER_APPROVED" : "ORGANIZER_REVOKED",
    entity: "profile",
    entityId: parsed.data!.id,
  });
  revalidatePath("/admin", "layout");
  back(parsed.data!.decision === "approve" ? "Organizer approved." : "Organizer access revoked.");
}

/** Approve (ACTIVE) or reject an event, optionally setting this event's commission. */
export async function reviewEvent(formData: FormData): Promise<void> {
  const admin = await requireRole(["SUPER_ADMIN"]);
  const parsed = z
    .object({
      id: z.string().uuid(),
      decision: z.enum(["approve", "reject"]),
      commission: z.coerce.number().min(0).max(100).optional(),
    })
    .safeParse({
      id: formData.get("id"),
      decision: formData.get("decision"),
      commission: formData.get("commission") || undefined,
    });
  if (!parsed.success) back("Invalid request.", "error");

  const svc = createAdminClient();
  const patch: Record<string, unknown> = {
    status: parsed.data!.decision === "approve" ? "ACTIVE" : "REJECTED",
  };
  if (parsed.data!.decision === "approve" && parsed.data!.commission !== undefined) {
    patch.commission_pct = parsed.data!.commission;
  }
  const { error } = await svc.from("events").update(patch).eq("id", parsed.data!.id).eq("status", "PENDING_APPROVAL");
  if (error) back(error.message, "error");

  await logAudit({
    actorId: admin.id,
    action: parsed.data!.decision === "approve" ? "EVENT_APPROVED" : "EVENT_REJECTED",
    entity: "event",
    entityId: parsed.data!.id,
    metadata: patch,
  });
  revalidatePath("/admin", "layout");
  revalidatePath("/");
  back(parsed.data!.decision === "approve" ? "Event approved and now live." : "Event rejected.");
}

/** Force-pause or resume a single event (platform moderation). */
export async function setEventStatus(formData: FormData): Promise<void> {
  const admin = await requireRole(["SUPER_ADMIN"]);
  const parsed = z
    .object({ id: z.string().uuid(), status: z.enum(["ACTIVE", "PAUSED", "ENDED"]) })
    .safeParse({ id: formData.get("id"), status: formData.get("status") });
  if (!parsed.success) back("Invalid request.", "error");

  const svc = createAdminClient();
  const { error } = await svc.from("events").update({ status: parsed.data!.status }).eq("id", parsed.data!.id);
  if (error) back(error.message, "error");

  await logAudit({
    actorId: admin.id,
    action: `EVENT_${parsed.data!.status}`,
    entity: "event",
    entityId: parsed.data!.id,
  });
  revalidatePath("/admin", "layout");
  revalidatePath("/");
  back(`Event set to ${parsed.data!.status}.`);
}
