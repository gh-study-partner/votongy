import type { Metadata } from "next";
import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: { default: "Super Admin", template: "%s | VoTongy Admin" }, robots: { index: false } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireRole(["SUPER_ADMIN"]);
  const supabase = await createClient();
  const [{ count: pendingEvents }, { count: pendingOrganizers }] = await Promise.all([
    supabase.from("events").select("id", { count: "exact", head: true }).eq("status", "PENDING_APPROVAL"),
    supabase.from("profiles").select("id", { count: "exact", head: true }).eq("role", "ORGANIZER").eq("is_approved", false),
  ]);

  return (
    <DashboardShell
      roleLabel="Super Admin"
      userName={profile.full_name ?? "Platform Owner"}
      email={profile.email}
      items={[
        { href: "/admin", label: "Overview", icon: "gauge", exact: true },
        { href: "/admin/approvals", label: "Approvals", icon: "approvals", badge: (pendingEvents ?? 0) + (pendingOrganizers ?? 0) },
        { href: "/admin/transactions", label: "Transactions", icon: "transactions" },
      ]}
    >
      {children}
    </DashboardShell>
  );
}
