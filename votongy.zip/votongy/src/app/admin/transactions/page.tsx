import { PageHeader } from "@/components/dashboard/DashboardShell";
import { TxLookup } from "@/components/dashboard/TxLookup";

export const metadata = { title: "Transactions" };

export default function AdminTransactionsPage() {
  return (
    <>
      <PageHeader
        title="Transaction & webhook support"
        description="Reconcile Mobile Money issues. Search by Paystack reference, voter phone number or email."
      />
      <TxLookup />
    </>
  );
}
