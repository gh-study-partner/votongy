import Link from "next/link";
import { Banknote, CalendarCheck2, Coins, Vote } from "lucide-react";
import { PageHeader } from "@/components/dashboard/DashboardShell";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { PauseSwitch } from "@/components/dashboard/PauseSwitch";
import { DataTable } from "@/components/dashboard/DataTable";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime, formatGHS, formatNumber } from "@/lib/utils";
import type { AdminKpis } from "@/types/database";

export const metadata = { title: "Overview" };

interface AuditRow {
  id: number;
  action: string;
  entity: string | null;
  entity_id: string | null;
  created_at: string;
}

export default async function AdminOverviewPage() {
  const supabase = await createClient();

  const [kpiRes, settingsRes, auditRes, eventsRes] = await Promise.all([
    supabase.rpc("admin_kpis"),
    supabase.from("platform_settings").select("voting_paused").eq("id", true).maybeSingle(),
    supabase.from("audit_logs").select("id, action, entity, entity_id, created_at").order("created_at", { ascending: false }).limit(12),
    supabase.from("events").select("id, title, slug, status, end_at").in("status", ["ACTIVE", "PAUSED"]).order("end_at", { ascending: true }).limit(8),
  ]);

  const kpis = (kpiRes.data as AdminKpis | null) ?? {
    gross_volume: 0,
    platform_commission: 0,
    total_votes: 0,
    successful_tx: 0,
    active_events: 0,
    pending_events: 0,
    pending_organizers: 0,
  };
  const pending = kpis.pending_events + kpis.pending_organizers;
  const audit = (auditRes.data ?? []) as AuditRow[];
  const live = (eventsRes.data ?? []) as { id: string; title: string; slug: string; status: string; end_at: string }[];

  return (
    <>
      <PageHeader title="Platform overview" description="Live numbers across every event on VoTongy." />

      <div className="space-y-6">
        <PauseSwitch initialPaused={Boolean(settingsRes.data?.voting_paused)} />

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <KpiCard label="Gross volume" value={formatGHS(kpis.gross_volume)} hint={`${formatNumber(kpis.successful_tx)} successful payments`} icon={<Banknote className="h-4 w-4" />} tone="gold" />
          <KpiCard label="Platform commission" value={formatGHS(kpis.platform_commission)} hint="Based on each event's commission %" icon={<Coins className="h-4 w-4" />} tone="green" />
          <KpiCard label="Total votes" value={formatNumber(kpis.total_votes)} icon={<Vote className="h-4 w-4" />} />
          <KpiCard label="Active events" value={formatNumber(kpis.active_events)} hint={pending > 0 ? `${pending} awaiting approval` : "Nothing waiting"} icon={<CalendarCheck2 className="h-4 w-4" />} />
        </div>

        {pending > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4">
            <p className="text-sm text-amber-200">
              <strong>{kpis.pending_events}</strong> event(s) and <strong>{kpis.pending_organizers}</strong> organizer(s) are waiting for your approval.
            </p>
            <Button asChild size="sm">
              <Link href="/admin/approvals">Review now</Link>
            </Button>
          </div>
        )}

        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Live &amp; paused events</h2>
          <DataTable
            rows={live}
            rowKey={(r) => r.id}
            empty="No events are live."
            columns={[
              { header: "Event", cell: (r) => <Link href={`/e/${r.slug}`} className="font-semibold hover:text-primary">{r.title}</Link> },
              { header: "Status", cell: (r) => <StatusBadge status={r.status} /> },
              { header: "Ends", cell: (r) => <span className="text-zinc-400">{formatDateTime(r.end_at)}</span> },
            ]}
          />
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Recent admin &amp; system activity</h2>
          <DataTable
            rows={audit}
            rowKey={(r) => String(r.id)}
            empty="No activity yet."
            columns={[
              { header: "Action", cell: (r) => <span className="font-mono text-xs">{r.action}</span> },
              { header: "Entity", cell: (r) => <span className="text-zinc-400">{r.entity ?? "-"}</span> },
              { header: "When", align: "right", cell: (r) => <span className="text-zinc-400">{formatDateTime(r.created_at)}</span> },
            ]}
          />
        </section>
      </div>
    </>
  );
}
