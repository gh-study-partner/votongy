import type { Metadata } from "next";
import Link from "next/link";
import { ChevronDown } from "lucide-react";
import { PublicShell } from "@/components/layout/PublicShell";
import { InstallAppPrompt } from "@/components/pwa/InstallAppPrompt";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "FAQ",
  description: "Answers about voting, payments, receipts and installing the VoTongy app on Android and iPhone.",
};

interface Faq {
  q: string;
  a: React.ReactNode;
}

const GROUPS: { title: string; items: Faq[] }[] = [
  {
    title: "Voting & payments",
    items: [
      {
        q: "How do I vote?",
        a: "Open the event, find your nominee (search by name or code like N042), tap Vote, choose a bundle (5, 20, 50 or 100 votes) or type your own number, enter your Mobile Money number and approve the payment prompt on your phone. No account is needed.",
      },
      {
        q: "Which payment methods work?",
        a: "MTN MoMo, Telecel Cash and AirtelTigo Money, plus Visa and Mastercard cards. All payments are processed securely by Paystack in Ghana Cedis (GHS).",
      },
      {
        q: "I paid but my votes don't show. What now?",
        a: (
          <>
            Don&apos;t pay again. Mobile networks can be slow. Open your receipt page (or paste your reference into &ldquo;Verify your vote receipt&rdquo; on the{" "}
            <Link href="/#verify" className="font-semibold text-primary hover:underline">
              home page
            </Link>
            ). It re-checks with Paystack automatically. If it still isn&apos;t confirmed after 30 minutes, email {siteConfig.supportEmail} with your reference.
          </>
        ),
      },
      {
        q: "Where do I find my receipt reference?",
        a: "It starts with VTG- and is shown on the receipt page you land on after paying. Paystack also includes it in your confirmation message or email. Voting from the same phone number? Support can find it with your number.",
      },
      {
        q: "Can I get a refund or move my votes?",
        a: (
          <>
            All votes are final and non-refundable once credited. Duplicate charges and genuine failed-but-debited payments are reviewed. See the{" "}
            <Link href="/refund-policy" className="font-semibold text-primary hover:underline">
              Refund Policy
            </Link>
            .
          </>
        ),
      },
      {
        q: "Is there a limit on how many votes I can buy?",
        a: `Each payment can be up to ${siteConfig.votes.max.toLocaleString("en-GH")} votes. You can pay again for more. We apply rate limits to protect events from bots.`,
      },
      {
        q: "Can I see who is winning?",
        a: "If the organizer enabled live votes, yes: see the Live results page of the event. Otherwise results are shown when voting ends.",
      },
    ],
  },
  {
    title: "Nominations & organizers",
    items: [
      {
        q: "How do I nominate someone?",
        a: "If the organizer allows public nominations, an event page shows a Nominate someone button. Submit the person's name, category and a photo. The organizer reviews each nomination before it appears.",
      },
      {
        q: "I run an event. How do I get started?",
        a: "Create an organizer account from the login page. After a VoTongy admin approves your account, use the 3-step wizard to set your cost per vote, dates, categories and options, then submit the event for approval.",
      },
      {
        q: "I was added as a nominee. How do I log in?",
        a: "Check your email for the invitation from VoTongy and tap the link. Later, go to Log in, choose Magic link and use the same email address. You'll see your rank, vote link and promo flyer.",
      },
    ],
  },
];

export default function FaqPage() {
  return (
    <PublicShell>
      <div className="container max-w-3xl py-10 sm:py-14">
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">Help centre</p>
        <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Frequently asked questions</h1>

        {/* Install guides */}
        <section id="install" className="mt-8 scroll-mt-20 rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-900 to-zinc-950 p-5 sm:p-7">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-xl font-bold">Install the VoTongy app</h2>
              <p className="mt-1 text-sm text-zinc-400">No app store needed. It installs from your browser in seconds and opens full screen.</p>
            </div>
            <InstallAppPrompt variant="button" size="default" label="Install now" />
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl bg-zinc-950 p-4">
              <h3 className="mb-2 font-semibold">Android (Chrome)</h3>
              <ol className="list-decimal space-y-1.5 pl-5 text-sm text-zinc-300">
                <li>Open VoTongy in <strong>Chrome</strong>.</li>
                <li>Tap <strong>Install App</strong> at the top (or the banner at the bottom).</li>
                <li>Confirm with <strong>Install</strong>.</li>
                <li>No prompt? Tap Chrome&apos;s <strong>&#8942; menu</strong>, then <strong>Install app</strong> / <strong>Add to Home screen</strong>.</li>
              </ol>
            </div>
            <div className="rounded-2xl bg-zinc-950 p-4">
              <h3 className="mb-2 font-semibold">iPhone &amp; iPad (Safari)</h3>
              <ol className="list-decimal space-y-1.5 pl-5 text-sm text-zinc-300">
                <li>Open VoTongy in <strong>Safari</strong> (not inside WhatsApp or Instagram).</li>
                <li>Tap the <strong>Share</strong> button (square with an arrow).</li>
                <li>Scroll and tap <strong>Add to Home Screen</strong>.</li>
                <li>Tap <strong>Add</strong>. The VoTongy icon appears on your home screen.</li>
              </ol>
            </div>
          </div>
          <p className="mt-4 text-xs text-zinc-500">
            Opened a link from WhatsApp or Instagram? Tap the menu and choose &ldquo;Open in browser&rdquo; first, then install.
          </p>
        </section>

        {GROUPS.map((group) => (
          <section key={group.title} className="mt-10">
            <h2 className="mb-4 font-display text-xl font-bold">{group.title}</h2>
            <div className="divide-y divide-zinc-800 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900">
              {group.items.map((item) => (
                <details key={item.q} className="group">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-5 py-4 text-left font-semibold marker:hidden hover:bg-zinc-800/50 [&::-webkit-details-marker]:hidden">
                    {item.q}
                    <ChevronDown className="h-4 w-4 shrink-0 text-zinc-500 transition-transform group-open:rotate-180" />
                  </summary>
                  <div className="px-5 pb-5 text-[15px] leading-relaxed text-zinc-300">{item.a}</div>
                </details>
              ))}
            </div>
          </section>
        ))}

        <p className="mt-10 rounded-xl border border-zinc-800 bg-zinc-900 p-4 text-sm text-zinc-400">
          Still stuck? Email{" "}
          <a href={`mailto:${siteConfig.supportEmail}`} className="font-semibold text-primary hover:underline">
            {siteConfig.supportEmail}
          </a>
          {siteConfig.supportWhatsapp && (
            <>
              {" "}
              or WhatsApp{" "}
              <a
                href={`https://wa.me/${siteConfig.supportWhatsapp}`}
                className="font-semibold text-primary hover:underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                +{siteConfig.supportWhatsapp}
              </a>
            </>
          )}
          .
        </p>
      </div>
    </PublicShell>
  );
}
