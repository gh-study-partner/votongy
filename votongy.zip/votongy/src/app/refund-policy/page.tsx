import type { Metadata } from "next";
import { LegalPage, LegalSection } from "@/components/layout/LegalPage";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Refund Policy",
  description: "When VoTongy votes can and cannot be refunded.",
};

export default function RefundPolicyPage() {
  const n = siteConfig.name;
  return (
    <LegalPage
      title="Refund Policy"
      intro="Votes are digital goods that are counted immediately. Please read this policy before you pay."
    >
      <LegalSection n={1} title="Votes are final">
        <p>
          Once your payment is confirmed and your votes are credited to a nominee, <strong>they are final and non-refundable</strong>. We cannot
          move votes to another nominee, reduce them or reverse the payment because you changed your mind, voted for the wrong nominee, made a
          mistake with the quantity, or because the nominee lost or was disqualified.
        </p>
      </LegalSection>

      <LegalSection n={2} title="When you may be refunded">
        <p>We will review a refund request, and refund where it is justified, in these cases only:</p>
        <ul>
          <li><strong>Duplicate charge:</strong> you were charged more than once for the same intended payment.</li>
          <li><strong>Debited but not counted:</strong> you were debited, the payment is confirmed as failed, flagged or unmatched on our side, and the votes were not credited after we have checked with Paystack.</li>
          <li><strong>Event cancelled:</strong> the organizer or {n} cancels the event before voting closes, and the event terms provide for refunds.</li>
          <li><strong>Payment amount mismatch:</strong> the amount debited differs from the amount shown at checkout because of a system error.</li>
        </ul>
      </LegalSection>

      <LegalSection n={3} title="Not refundable">
        <ul>
          <li>Votes that were successfully credited.</li>
          <li>Payments made with another person&apos;s phone or card, or payments later reversed or charged back by you without contacting us first.</li>
          <li>Votes removed after we find fraud or manipulation by the voter.</li>
          <li>Losses caused by entering the wrong Mobile Money number, mobile network problems or operator fees outside our control.</li>
        </ul>
      </LegalSection>

      <LegalSection n={4} title="Check before you ask">
        <p>
          Many &ldquo;missing votes&rdquo; are just slow confirmations. Open your receipt (or use &ldquo;Verify vote receipt&rdquo; on the home page) and wait a few
          minutes. Pending payments are re-checked with Paystack automatically, and if the payment succeeded the votes will appear. <strong>Please don&apos;t pay again while a payment is pending.</strong>
        </p>
      </LegalSection>

      <LegalSection n={5} title="How to request a refund">
        <ul>
          <li>Email {siteConfig.supportEmail} within <strong>7 days</strong> of the payment.</li>
          <li>Include your receipt reference (starts with VTG-), the Mobile Money number or card used, the amount and a screenshot of the debit message if you have one.</li>
          <li>We will investigate with Paystack and reply, normally within 5 business days.</li>
        </ul>
      </LegalSection>

      <LegalSection n={6} title="How refunds are paid">
        <p>
          Approved refunds are returned to the original payment method through Paystack. Mobile Money refunds are usually quick; card refunds can
          take 5 to 10 business days depending on your bank. Processing fees charged by payment providers may be non-recoverable where the law allows.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
