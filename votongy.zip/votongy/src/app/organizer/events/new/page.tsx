import { PageHeader } from "@/components/dashboard/DashboardShell";
import { EventWizard } from "@/components/organizer/EventWizard";
import { requireRole } from "@/lib/auth";

export const metadata = { title: "New event" };

export default async function NewEventPage() {
  const profile = await requireRole(["ORGANIZER"]);
  return (
    <>
      <PageHeader title="Create an event" description="Three quick steps. An admin reviews it before it goes live." />
      <EventWizard canPublish={profile.is_approved} />
    </>
  );
}
