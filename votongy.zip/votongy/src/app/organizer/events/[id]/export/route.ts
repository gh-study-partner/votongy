import { NextResponse } from "next/server";
import { z } from "zod";
import { getSessionProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { buildSimplePdf, type PdfLine } from "@/lib/pdf";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function csvCell(value: unknown): string {
  let s = String(value ?? "");
  // Neutralise spreadsheet formula injection from user-supplied names
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

interface Row {
  category: string;
  rank: number;
  code: string;
  name: string;
  votes: number;
  share: number;
}

/** Certified results export (CSV or PDF). Organizer must own the event (also enforced by RLS). */
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) return new NextResponse("Not found", { status: 404 });

  const profile = await getSessionProfile();
  if (!profile || (profile.role !== "ORGANIZER" && profile.role !== "SUPER_ADMIN")) {
    return new NextResponse("Forbidden", { status: 403 });
  }

  const format = new URL(request.url).searchParams.get("format") === "pdf" ? "pdf" : "csv";
  const supabase = await createClient();

  const { data: event } = await supabase
    .from("events")
    .select("id, title, slug, status, cost_per_vote, commission_pct, start_at, end_at, organizer_id")
    .eq("id", id)
    .maybeSingle();
  if (!event || (profile.role === "ORGANIZER" && event.organizer_id !== profile.id)) {
    return new NextResponse("Not found", { status: 404 });
  }

  const [catRes, nomRes, txRes] = await Promise.all([
    supabase.from("categories").select("id, name, sort_order").eq("event_id", id).order("sort_order"),
    supabase.from("nominees").select("id, name, code, total_votes, category_id, status").eq("event_id", id).eq("status", "APPROVED"),
    supabase.from("transactions").select("amount, votes").eq("event_id", id).eq("status", "SUCCESS").limit(100000),
  ]);

  const categories = (catRes.data ?? []) as { id: string; name: string }[];
  const nominees = (nomRes.data ?? []) as { id: string; name: string; code: string; total_votes: number; category_id: string }[];
  const txs = (txRes.data ?? []) as { amount: number; votes: number }[];

  const rows: Row[] = [];
  for (const c of categories) {
    const list = nominees.filter((n) => n.category_id === c.id).sort((a, b) => Number(b.total_votes) - Number(a.total_votes) || a.name.localeCompare(b.name));
    const total = list.reduce((s, n) => s + Number(n.total_votes), 0);
    list.forEach((n, i) =>
      rows.push({
        category: c.name,
        rank: i + 1,
        code: n.code,
        name: n.name,
        votes: Number(n.total_votes),
        share: total > 0 ? (Number(n.total_votes) / total) * 100 : 0,
      }),
    );
  }

  const gross = txs.reduce((s, t) => s + Number(t.amount), 0);
  const votesSold = txs.reduce((s, t) => s + Number(t.votes), 0);
  const commission = gross * (Number(event.commission_pct) / 100);
  const generated = new Date().toLocaleString("en-GH", { timeZone: "Africa/Accra", dateStyle: "long", timeStyle: "short" });
  const fileBase = `${event.slug}-results`;

  if (format === "csv") {
    const lines = [
      ["Event", event.title].map(csvCell).join(","),
      ["Generated (Africa/Accra)", generated].map(csvCell).join(","),
      ["Status", event.status].map(csvCell).join(","),
      ["Votes sold", votesSold].map(csvCell).join(","),
      ["Gross revenue (GHS)", gross.toFixed(2)].map(csvCell).join(","),
      ["Platform commission (GHS)", commission.toFixed(2)].map(csvCell).join(","),
      ["Net to organizer (GHS)", (gross - commission).toFixed(2)].map(csvCell).join(","),
      "",
      "Category,Rank,Code,Nominee,Votes,Share %",
      ...rows.map((r) => [r.category, r.rank, r.code, r.name, r.votes, r.share.toFixed(2)].map(csvCell).join(",")),
    ];
    return new NextResponse("﻿" + lines.join("\r\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${fileBase}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  }

  const pdfLines: PdfLine[] = [
    { text: "VoTongy - Certified Results", size: 18, bold: true, gap: 4 },
    { text: String(event.title), size: 14, bold: true, gap: 2 },
    { text: `Generated: ${generated}   |   Status: ${event.status}`, size: 9, gap: 2 },
    { text: `Votes sold: ${votesSold.toLocaleString("en-GH")}   |   Gross: GHS ${gross.toFixed(2)}   |   Commission (${Number(event.commission_pct)}%): GHS ${commission.toFixed(2)}   |   Net: GHS ${(gross - commission).toFixed(2)}`, size: 9, gap: 12 },
  ];
  for (const c of categories) {
    const list = rows.filter((r) => r.category === c.name);
    pdfLines.push({ text: c.name, size: 12, bold: true, gap: 2 });
    if (list.length === 0) pdfLines.push({ text: "No nominees", size: 10, indent: 8, gap: 6 });
    list.forEach((r, i) => {
      pdfLines.push({
        text: `${String(r.rank).padStart(2, " ")}.  ${r.name} (${r.code})  -  ${r.votes.toLocaleString("en-GH")} votes  (${r.share.toFixed(1)}%)`,
        size: 10,
        indent: 8,
        bold: r.rank === 1 && r.votes > 0,
        gap: i === list.length - 1 ? 8 : 0,
      });
    });
  }
  pdfLines.push({ text: "", gap: 10 });
  pdfLines.push({ text: "This document was generated from VoTongy's verified vote records. Votes are credited only after server-side payment confirmation by Paystack.", size: 8 });

  return new NextResponse(new Uint8Array(buildSimplePdf(pdfLines)), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileBase}.pdf"`,
      "Cache-Control": "no-store",
    },
  });
}
