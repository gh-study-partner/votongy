import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Banknote, ExternalLink, FileDown, FileSpreadsheet, Vote } from "lucide-react";
import { PageHeader } from "@/components/dashboard/DashboardShell";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { RevenueChart, VotesBarChart } from "@/components/dashboard/Charts";
import { DataTable } from "@/components/dashboard/DataTable";
import { CopyButton } from "@/components/dashboard/CopyButton";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatusControls } from "@/components/organizer/StatusControls";
import { EventSettingsForm } from "@/components/organizer/EventSettingsForm";
import { CategoryManager } from "@/components/organizer/CategoryManager";
import { NomineeManager, type ManagedNominee } from "@/components/organizer/NomineeManager";
import { ApplicationsList, type PendingApplication } from "@/components/organizer/ApplicationsList";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { eventVoteUrl, formatDateTime, formatGHS, formatNumber } from "@/lib/utils";
import type { EventRow, RevenueDay } from "@/types/database";

export const metadata = { title: "Manage event" };

interface Tx {
  id: string;
  reference: string;
  votes: number;
  amount: number;
  status: string;
  voter_phone: string | null;
  paid_at: string | null;
  created_at: string;
  nominees: { name: string; code: string } | null;
}

function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-zinc-800 bg-zinc-900/50 p-5 sm:p-6">
      <h2 className="font-display text-lg font-bold">{title}</h2>
      {description && <p className="mb-4 mt-0.5 text-sm text-zinc-400">{description}</p>}
      <div className={description ? "" : "mt-4"}>{children}</div>
    </section>
  );
}

export default async function ManageEventPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const profile = await requireRole(["ORGANIZER"]);
  const supabase = await createClient();

  // RLS guarantees organizers only ever see their own events.
  const { data: eventData } = await supabase.from("events").select("*").eq("id", id).eq("organizer_id", profile.id).maybeSingle();
  if (!eventData) notFound();
  const event = eventData as EventRow;

  const [catRes, nomRes, appRes, txRes, revRes] = await Promise.all([
    supabase.from("categories").select("id, name, sort_order").eq("event_id", id).order("sort_order"),
    supabase.from("nominees").select("id, name, code, email, photo_url, total_votes, status, category_id, user_id").eq("event_id", id).order("code"),
    supabase
      .from("nomination_applications")
      .select("id, applicant_name, applicant_email, applicant_phone, bio, photo_url, created_at, categories:category_id(name)")
      .eq("event_id", id)
      .eq("status", "PENDING")
      .order("created_at"),
    supabase
      .from("transactions")
      .select("id, reference, votes, amount, status, voter_phone, paid_at, created_at, nominees(name, code)")
      .eq("event_id", id)
      .order("created_at", { ascending: false })
      .limit(40),
    supabase.rpc("event_revenue_by_day", { p_event_id: id }),
  ]);

  const categories = (catRes.data ?? []) as { id: string; name: string }[];
  const nomineesRaw = (nomRes.data ?? []) as (Omit<ManagedNominee, "linked"> & { user_id: string | null })[];
  const nominees: ManagedNominee[] = nomineesRaw.map(({ user_id, ...n }) => ({ ...n, total_votes: Number(n.total_votes), linked: Boolean(user_id) }));
  const applications: PendingApplication[] = ((appRes.data ?? []) as unknown as (Omit<PendingApplication, "category"> & { categories: { name: string } | null })[]).map((a) => ({
    ...a,
    category: a.categories?.name ?? null,
  }));
  const txs = (txRes.data ?? []) as unknown as Tx[];
  const revenue = ((revRes.data ?? []) as RevenueDay[]).map((r) => ({ day: String(r.day).slice(5), revenue: Number(r.revenue), votes: Number(r.votes) }));

  const gross = revenue.reduce((s, r) => s + r.revenue, 0);
  const totalVotes = nominees.reduce((s, n) => s + n.total_votes, 0);
  const net = gross * (1 - Number(event.commission_pct) / 100);
  const topNominees = [...nominees].sort((a, b) => b.total_votes - a.total_votes).slice(0, 8).map((n) => ({ name: n.name, votes: n.total_votes }));
  const nomineeCountByCat = new Map<string, number>();
  nominees.forEach((n) => nomineeCountByCat.set(n.category_id, (nomineeCountByCat.get(n.category_id) ?? 0) + 1));

  const voteUrl = eventVoteUrl(event.slug);

  return (
    <>
      <Link href="/organizer" className="mb-4 inline-flex items-center gap-1.5 text-sm text-zinc-400 hover:text-white">
        <ArrowLeft className="h-4 w-4" /> All events
      </Link>
      <PageHeader
        title={event.title}
        description={`/e/${event.slug} · ${formatDateTime(event.start_at)} to ${formatDateTime(event.end_at)}`}
        action={<StatusBadge status={event.status} />}
      />

      <div className="space-y-6">
        <Section title="Status & sharing">
          <div className="space-y-4">
            <StatusControls eventId={event.id} status={event.status} />
            {["ACTIVE", "PAUSED", "ENDED"].includes(event.status) && (
              <div className="flex flex-wrap items-center gap-2 rounded-xl bg-zinc-950 p-3">
                <code className="min-w-0 flex-1 truncate text-xs text-zinc-300">{voteUrl}</code>
                <CopyButton value={voteUrl} label="Copy voting link" />
                <Button asChild variant="outline" size="sm">
                  <Link href={`/e/${event.slug}`} target="_blank">
                    <ExternalLink className="h-4 w-4" /> Open
                  </Link>
                </Button>
              </div>
            )}
            {event.allow_public_nominations && ["ACTIVE", "PAUSED"].includes(event.status) && (
              <div className="flex flex-wrap items-center gap-2 rounded-xl bg-zinc-950 p-3">
                <code className="min-w-0 flex-1 truncate text-xs text-zinc-300">{voteUrl.replace("/e/", "/nominate/")}</code>
                <CopyButton value={voteUrl.replace("/e/", "/nominate/")} label="Copy nomination link" />
              </div>
            )}
          </div>
        </Section>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <KpiCard label="Gross revenue" value={formatGHS(gross)} icon={<Banknote className="h-4 w-4" />} tone="gold" />
          <KpiCard label="Your share" value={formatGHS(net)} hint={`After ${Number(event.commission_pct)}% platform commission`} icon={<Banknote className="h-4 w-4" />} tone="green" />
          <KpiCard label="Total votes" value={formatNumber(totalVotes)} icon={<Vote className="h-4 w-4" />} />
          <KpiCard label="Nominees" value={formatNumber(nominees.length)} hint={`${categories.length} categories`} />
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
            <h2 className="mb-4 font-display text-base font-bold">Revenue by day (GHS)</h2>
            <RevenueChart data={revenue} />
          </section>
          <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
            <h2 className="mb-4 font-display text-base font-bold">Top nominees by votes</h2>
            <VotesBarChart data={topNominees} />
          </section>
        </div>

        <Section title="Certified results" description="Download an official results sheet with rankings, vote totals and revenue as of now.">
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline">
              <a href={`/organizer/events/${event.id}/export?format=csv`}>
                <FileSpreadsheet className="h-4 w-4" /> Download CSV
              </a>
            </Button>
            <Button asChild variant="outline">
              <a href={`/organizer/events/${event.id}/export?format=pdf`}>
                <FileDown className="h-4 w-4" /> Download PDF
              </a>
            </Button>
          </div>
        </Section>

        <Section title="Categories">
          <CategoryManager
            eventId={event.id}
            categories={categories.map((c) => ({ id: c.id, name: c.name, nominees: nomineeCountByCat.get(c.id) ?? 0 }))}
          />
        </Section>

        <Section title="Nominees" description="Auto-generated codes (N001, N002...) are used for search and direct voting links.">
          <NomineeManager eventId={event.id} eventSlug={event.slug} categories={categories} nominees={nominees} />
        </Section>

        {event.allow_public_nominations && (
          <Section title={`Public nominations (${applications.length} pending)`} description="Approve to add the person to your ballot with a new code.">
            <ApplicationsList eventId={event.id} applications={applications} />
          </Section>
        )}

        <Section title="Recent payments">
          <DataTable
            rows={txs}
            rowKey={(t) => t.id}
            empty="No payments yet."
            columns={[
              { header: "Nominee", cell: (t) => <span className="font-semibold">{t.nominees?.name ?? "-"} <span className="text-xs font-normal text-primary">{t.nominees?.code}</span></span> },
              { header: "Votes", cell: (t) => formatNumber(t.votes) },
              { header: "Amount", cell: (t) => formatGHS(t.amount) },
              { header: "Status", cell: (t) => <StatusBadge status={t.status} /> },
              { header: "When", align: "right", cell: (t) => <span className="text-zinc-400">{formatDateTime(t.paid_at ?? t.created_at)}</span> },
            ]}
          />
        </Section>

        <Section title="Event settings">
          <EventSettingsForm
            eventId={event.id}
            initial={{
              title: event.title,
              description: event.description,
              banner_url: event.banner_url,
              cost_per_vote: Number(event.cost_per_vote),
              start_at: event.start_at,
              end_at: event.end_at,
              show_live_votes: event.show_live_votes,
              allow_public_nominations: event.allow_public_nominations,
            }}
          />
        </Section>
      </div>
    </>
  );
}
