import Link from "next/link";
import { Banknote, CalendarDays, Plus, Vote } from "lucide-react";
import { PageHeader } from "@/components/dashboard/DashboardShell";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { RevenueChart } from "@/components/dashboard/Charts";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { formatDate, formatGHS, formatNumber } from "@/lib/utils";

export const metadata = { title: "Overview" };

interface EventRow {
  id: string;
  title: string;
  slug: string;
  status: string;
  end_at: string;
  commission_pct: number;
}
interface TxRow {
  event_id: string;
  amount: number;
  votes: number;
  paid_at: string | null;
}

export default async function OrganizerOverviewPage() {
  const profile = await requireRole(["ORGANIZER"]);
  const supabase = await createClient();

  const [eventsRes, txRes] = await Promise.all([
    supabase.from("events").select("id, title, slug, status, end_at, commission_pct").eq("organizer_id", profile.id).order("created_at", { ascending: false }),
    supabase.from("transactions").select("event_id, amount, votes, paid_at").eq("status", "SUCCESS").order("paid_at", { ascending: false }).limit(5000),
  ]);

  const events = (eventsRes.data ?? []) as EventRow[];
  const txs = (txRes.data ?? []) as TxRow[];
  const commissionByEvent = new Map(events.map((e) => [e.id, Number(e.commission_pct)]));

  let gross = 0;
  let votes = 0;
  let net = 0;
  const perEvent = new Map<string, { gross: number; votes: number }>();
  const perDay = new Map<string, { revenue: number; votes: number }>();

  for (const t of txs) {
    const amount = Number(t.amount);
    const pct = commissionByEvent.get(t.event_id) ?? 10;
    gross += amount;
    votes += t.votes;
    net += amount * (1 - pct / 100);
    const e = perEvent.get(t.event_id) ?? { gross: 0, votes: 0 };
    e.gross += amount;
    e.votes += t.votes;
    perEvent.set(t.event_id, e);
    if (t.paid_at) {
      const day = new Date(t.paid_at).toLocaleDateString("en-CA", { timeZone: "Africa/Accra" });
      const d = perDay.get(day) ?? { revenue: 0, votes: 0 };
      d.revenue += amount;
      d.votes += t.votes;
      perDay.set(day, d);
    }
  }

  const chart = [...perDay.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([day, v]) => ({ day: day.slice(5), revenue: Math.round(v.revenue * 100) / 100, votes: v.votes }));

  return (
    <>
      <PageHeader
        title={`Hello, ${profile.full_name?.split(" ")[0] ?? "organizer"}`}
        description="Your events, revenue and votes at a glance."
        action={
          <Button asChild>
            <Link href="/organizer/events/new">
              <Plus className="h-4 w-4" /> New event
            </Link>
          </Button>
        }
      />

      <div className="space-y-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <KpiCard label="Gross revenue" value={formatGHS(gross)} icon={<Banknote className="h-4 w-4" />} tone="gold" />
          <KpiCard label="Your share" value={formatGHS(net)} hint="After platform commission" icon={<Banknote className="h-4 w-4" />} tone="green" />
          <KpiCard label="Votes sold" value={formatNumber(votes)} icon={<Vote className="h-4 w-4" />} />
          <KpiCard label="Events" value={formatNumber(events.length)} icon={<CalendarDays className="h-4 w-4" />} />
        </div>

        <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <h2 className="mb-4 font-display text-base font-bold">Revenue over time (GHS)</h2>
          <RevenueChart data={chart} />
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg font-bold">Your events</h2>
          {events.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-zinc-800 px-4 py-14 text-center">
              <p className="font-display text-lg font-semibold">Create your first event</p>
              <p className="mx-auto mt-1 max-w-sm text-sm text-zinc-400">Set your price per vote, add categories and nominees, and share your voting link.</p>
              <Button asChild className="mt-5">
                <Link href="/organizer/events/new">Launch event wizard</Link>
              </Button>
            </div>
          ) : (
            <ul className="grid gap-3 sm:grid-cols-2">
              {events.map((e) => {
                const s = perEvent.get(e.id);
                return (
                  <li key={e.id}>
                    <Link href={`/organizer/events/${e.id}`} className="block rounded-2xl border border-zinc-800 bg-zinc-900 p-5 transition-colors hover:border-zinc-600">
                      <div className="flex items-start justify-between gap-3">
                        <h3 className="font-display text-base font-bold leading-snug">{e.title}</h3>
                        <StatusBadge status={e.status} />
                      </div>
                      <p className="mt-1 text-xs text-zinc-500">Ends {formatDate(e.end_at)}</p>
                      <div className="mt-4 flex gap-6 text-sm">
                        <div><p className="text-xs text-zinc-500">Revenue</p><p className="font-semibold">{formatGHS(s?.gross ?? 0)}</p></div>
                        <div><p className="text-xs text-zinc-500">Votes</p><p className="font-semibold">{formatNumber(s?.votes ?? 0)}</p></div>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </>
  );
}
