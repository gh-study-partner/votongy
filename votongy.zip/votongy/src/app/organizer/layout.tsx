import type { Metadata } from "next";
import { Clock3 } from "lucide-react";
import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { requireRole } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: { default: "Organizer", template: "%s | VoTongy Organizer" }, robots: { index: false } };

export default async function OrganizerLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireRole(["ORGANIZER"]);

  return (
    <DashboardShell
      roleLabel="Organizer"
      userName={profile.full_name ?? "Organizer"}
      email={profile.email}
      items={[
        { href: "/organizer", label: "Overview", icon: "dashboard", exact: true },
        { href: "/organizer/events/new", label: "New event", icon: "new" },
      ]}
    >
      {!profile.is_approved && (
        <div className="mb-6 flex items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
          <Clock3 className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            <strong>Your account is awaiting approval.</strong> A VoTongy admin will approve it shortly. Until then you can look around, but you can&apos;t create or publish events.
          </p>
        </div>
      )}
      {children}
    </DashboardShell>
  );
}
