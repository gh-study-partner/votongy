"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { inviteNominee } from "@/lib/invite";
import { logAudit } from "@/lib/audit";
import {
  categoryNameSchema,
  eventInputSchema,
  eventSettingsSchema,
  firstError,
  nomineeInputSchema,
} from "@/lib/validation";

export interface ActionResult {
  ok: boolean;
  error?: string;
  message?: string;
  id?: string;
}

const fail = (error: string): ActionResult => ({ ok: false, error });

function friendly(err: { code?: string; message: string }): string {
  if (err.code === "23505") return "That value is already in use (event URL or category name).";
  if (err.code === "42501" || /row-level security/i.test(err.message)) return "You don't have permission to do that.";
  return err.message;
}

// ---------------------------------------------------------------- events

export async function createEvent(input: unknown): Promise<ActionResult> {
  const profile = await requireRole(["ORGANIZER"]);
  if (!profile.is_approved) {
    return fail("Your organizer account is awaiting approval. You can create events once a VoTongy admin approves you.");
  }
  const parsed = eventInputSchema.safeParse(input);
  if (!parsed.success) return fail(firstError(parsed.error));
  const v = parsed.data;

  const supabase = await createClient();
  const { data: event, error } = await supabase
    .from("events")
    .insert({
      organizer_id: profile.id,
      slug: v.slug,
      title: v.title,
      description: v.description || null,
      banner_url: v.bannerUrl || null,
      cost_per_vote: v.costPerVote,
      start_at: new Date(v.startAt).toISOString(),
      end_at: new Date(v.endAt).toISOString(),
      show_live_votes: v.showLiveVotes,
      allow_public_nominations: v.allowPublicNominations,
      status: v.submit ? "PENDING_APPROVAL" : "DRAFT",
    })
    .select("id")
    .single();
  if (error || !event) return fail(error ? friendly(error) : "Could not create the event.");

  if (v.categories.length > 0) {
    const { error: catError } = await supabase.from("categories").insert(
      v.categories.map((name, i) => ({ event_id: event.id, name, sort_order: i })),
    );
    if (catError) return { ok: true, id: event.id as string, message: `Event created, but categories failed: ${friendly(catError)}` };
  }

  await logAudit({ actorId: profile.id, action: "EVENT_CREATED", entity: "event", entityId: event.id as string });
  revalidatePath("/organizer", "layout");
  return { ok: true, id: event.id as string };
}

export async function updateEventSettings(eventId: string, input: unknown): Promise<ActionResult> {
  await requireRole(["ORGANIZER"]);
  const id = z.string().uuid().safeParse(eventId);
  if (!id.success) return fail("Invalid event.");
  const parsed = eventSettingsSchema.safeParse(input);
  if (!parsed.success) return fail(firstError(parsed.error));
  const v = parsed.data;

  const supabase = await createClient();
  const { error } = await supabase
    .from("events")
    .update({
      title: v.title,
      description: v.description || null,
      banner_url: v.bannerUrl || null,
      cost_per_vote: v.costPerVote,
      start_at: new Date(v.startAt).toISOString(),
      end_at: new Date(v.endAt).toISOString(),
      show_live_votes: v.showLiveVotes,
      allow_public_nominations: v.allowPublicNominations,
    })
    .eq("id", id.data);
  if (error) return fail(friendly(error));

  revalidatePath(`/organizer/events/${id.data}`);
  revalidatePath("/");
  return { ok: true, message: "Settings saved." };
}

/** Organizer-allowed status changes (enforced again by the DB trigger). */
export async function changeEventStatus(
  eventId: string,
  status: "PENDING_APPROVAL" | "ACTIVE" | "PAUSED" | "ENDED",
): Promise<ActionResult> {
  const profile = await requireRole(["ORGANIZER"]);
  const id = z.string().uuid().safeParse(eventId);
  if (!id.success) return fail("Invalid event.");
  if (status === "PENDING_APPROVAL" && !profile.is_approved) return fail("Your organizer account must be approved first.");

  const supabase = await createClient();
  const { data, error } = await supabase.from("events").update({ status }).eq("id", id.data).select("status").maybeSingle();
  if (error) return fail(friendly(error));
  if (!data) return fail("Event not found.");

  await logAudit({ actorId: profile.id, action: `EVENT_STATUS_${status}`, entity: "event", entityId: id.data });
  revalidatePath(`/organizer/events/${id.data}`);
  revalidatePath("/organizer");
  revalidatePath("/");
  return { ok: true, message: status === "PENDING_APPROVAL" ? "Submitted for approval." : `Event is now ${status.toLowerCase()}.` };
}

// ------------------------------------------------------------ categories

export async function addCategory(eventId: string, name: string): Promise<ActionResult> {
  await requireRole(["ORGANIZER"]);
  const id = z.string().uuid().safeParse(eventId);
  const nm = categoryNameSchema.safeParse(name);
  if (!id.success) return fail("Invalid event.");
  if (!nm.success) return fail(firstError(nm.error));

  const supabase = await createClient();
  const { count } = await supabase.from("categories").select("id", { count: "exact", head: true }).eq("event_id", id.data);
  const { error } = await supabase.from("categories").insert({ event_id: id.data, name: nm.data, sort_order: count ?? 0 });
  if (error) return fail(friendly(error));
  revalidatePath(`/organizer/events/${id.data}`);
  return { ok: true };
}

export async function deleteCategory(eventId: string, categoryId: string): Promise<ActionResult> {
  await requireRole(["ORGANIZER"]);
  const e = z.string().uuid().safeParse(eventId);
  const c = z.string().uuid().safeParse(categoryId);
  if (!e.success || !c.success) return fail("Invalid request.");

  const supabase = await createClient();
  const { count } = await supabase
    .from("nominees")
    .select("id", { count: "exact", head: true })
    .eq("category_id", c.data)
    .gt("total_votes", 0);
  if ((count ?? 0) > 0) return fail("This category has nominees with votes and can't be deleted.");

  const { error } = await supabase.from("categories").delete().eq("id", c.data).eq("event_id", e.data);
  if (error) return fail(friendly(error));
  revalidatePath(`/organizer/events/${e.data}`);
  return { ok: true };
}

// -------------------------------------------------------------- nominees

export async function addNominee(input: unknown): Promise<ActionResult> {
  const profile = await requireRole(["ORGANIZER"]);
  const parsed = nomineeInputSchema.safeParse(input);
  if (!parsed.success) return fail(firstError(parsed.error));
  const v = parsed.data;

  const supabase = await createClient();
  const { data: nominee, error } = await supabase
    .from("nominees")
    .insert({
      event_id: v.eventId,
      category_id: v.categoryId,
      name: v.name,
      email: v.email ?? null,
      bio: v.bio ?? null,
      photo_url: v.photoUrl ?? null,
      status: "APPROVED",
    })
    .select("id, code")
    .single();
  if (error || !nominee) return fail(error ? friendly(error) : "Could not add the nominee.");

  let note = `Added as ${nominee.code}.`;
  if (v.email) {
    const invite = await inviteNominee({ nomineeId: nominee.id as string, email: v.email, name: v.name });
    note += invite.linked
      ? invite.emailSent
        ? " Invitation email sent."
        : " Linked to their existing login."
      : ` ${invite.message ?? "Invitation was not sent."}`;
  }

  await logAudit({ actorId: profile.id, action: "NOMINEE_ADDED", entity: "nominee", entityId: nominee.id as string });
  revalidatePath(`/organizer/events/${v.eventId}`);
  return { ok: true, id: nominee.id as string, message: note };
}

export async function setNomineeStatus(
  eventId: string,
  nomineeId: string,
  status: "APPROVED" | "REJECTED",
): Promise<ActionResult> {
  await requireRole(["ORGANIZER"]);
  const e = z.string().uuid().safeParse(eventId);
  const n = z.string().uuid().safeParse(nomineeId);
  if (!e.success || !n.success) return fail("Invalid request.");

  const supabase = await createClient();
  const { error } = await supabase.from("nominees").update({ status }).eq("id", n.data).eq("event_id", e.data);
  if (error) return fail(friendly(error));
  revalidatePath(`/organizer/events/${e.data}`);
  return { ok: true };
}

export async function deleteNominee(eventId: string, nomineeId: string): Promise<ActionResult> {
  await requireRole(["ORGANIZER"]);
  const e = z.string().uuid().safeParse(eventId);
  const n = z.string().uuid().safeParse(nomineeId);
  if (!e.success || !n.success) return fail("Invalid request.");

  const supabase = await createClient();
  const { error } = await supabase.from("nominees").delete().eq("id", n.data).eq("event_id", e.data);
  if (error) {
    return fail(error.code === "23503" ? "This nominee has payments and can't be deleted. Reject them instead." : friendly(error));
  }
  revalidatePath(`/organizer/events/${e.data}`);
  return { ok: true };
}

export async function resendInvite(eventId: string, nomineeId: string): Promise<ActionResult> {
  await requireRole(["ORGANIZER"]);
  const e = z.string().uuid().safeParse(eventId);
  const n = z.string().uuid().safeParse(nomineeId);
  if (!e.success || !n.success) return fail("Invalid request.");

  const supabase = await createClient();
  const { data: nominee } = await supabase.from("nominees").select("id, name, email").eq("id", n.data).eq("event_id", e.data).maybeSingle();
  if (!nominee?.email) return fail("This nominee has no email address.");

  const result = await inviteNominee({ nomineeId: nominee.id as string, email: nominee.email as string, name: nominee.name as string });
  revalidatePath(`/organizer/events/${e.data}`);
  return result.linked ? { ok: true, message: result.emailSent ? "Invitation sent." : "Linked to their existing login. They can sign in with a magic link." } : fail(result.message ?? "Could not send.");
}

// ---------------------------------------------------------- applications

export async function reviewApplication(
  eventId: string,
  applicationId: string,
  decision: "approve" | "reject",
): Promise<ActionResult> {
  const profile = await requireRole(["ORGANIZER"]);
  const e = z.string().uuid().safeParse(eventId);
  const a = z.string().uuid().safeParse(applicationId);
  if (!e.success || !a.success) return fail("Invalid request.");

  const supabase = await createClient();
  const { data: app } = await supabase
    .from("nomination_applications")
    .select("*")
    .eq("id", a.data)
    .eq("event_id", e.data)
    .eq("status", "PENDING")
    .maybeSingle();
  if (!app) return fail("Application not found or already reviewed.");

  let note = "Nomination rejected.";
  if (decision === "approve") {
    if (!app.category_id) return fail("This application has no category. Reject it or ask the applicant to resubmit.");
    const { data: nominee, error } = await supabase
      .from("nominees")
      .insert({
        event_id: e.data,
        category_id: app.category_id,
        name: app.applicant_name,
        email: app.applicant_email,
        bio: app.bio,
        photo_url: app.photo_url,
        status: "APPROVED",
      })
      .select("id, code")
      .single();
    if (error || !nominee) return fail(error ? friendly(error) : "Could not approve.");
    note = `Approved as ${nominee.code}.`;
    // Invitations are deliberate: use "Invite" on the nominee row if you want them to get a login.
  }

  const { error: updErr } = await supabase
    .from("nomination_applications")
    .update({
      status: decision === "approve" ? "APPROVED" : "REJECTED",
      reviewed_by: profile.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", a.data);
  if (updErr) return fail(friendly(updErr));

  revalidatePath(`/organizer/events/${e.data}`);
  return { ok: true, message: note };
}
