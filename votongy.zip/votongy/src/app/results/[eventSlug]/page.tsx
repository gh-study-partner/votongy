import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { PublicShell } from "@/components/layout/PublicShell";
import { LeaderboardBars } from "@/components/voting/LeaderboardBars";
import { Button } from "@/components/ui/button";
import { getEventBySlug, getEventCatalog } from "@/lib/data";
import { computeVotingState, formatDateTime } from "@/lib/utils";

export const revalidate = 10;

type Params = { eventSlug: string };

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { eventSlug } = await params;
  const event = await getEventBySlug(eventSlug);
  return { title: event ? `${event.title} - Live results` : "Results" };
}

export default async function ResultsPage({ params }: { params: Promise<Params> }) {
  const { eventSlug } = await params;
  const event = await getEventBySlug(eventSlug);
  if (!event) notFound();

  const { categories, nominees } = await getEventCatalog(event.id);
  const state = computeVotingState(event);

  return (
    <PublicShell>
      <div className="container max-w-4xl py-8 sm:py-12">
        <Link href={`/e/${event.slug}`} className="mb-5 inline-flex items-center gap-1.5 text-sm text-zinc-400 hover:text-white">
          <ArrowLeft className="h-4 w-4" /> Back to {event.title}
        </Link>

        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-primary">
              {state === "ended" ? "Final results" : "Live telemetry"}
            </p>
            <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">{event.title}</h1>
            <p className="mt-1 text-sm text-zinc-400">
              {state === "ended" ? `Voting closed ${formatDateTime(event.end_at)}` : `Voting closes ${formatDateTime(event.end_at)}`}
            </p>
          </div>
          {state === "open" && (
            <Button asChild>
              <Link href={`/e/${event.slug}`}>Cast your vote</Link>
            </Button>
          )}
        </div>

        <LeaderboardBars eventId={event.id} eventStatus={event.status} categories={categories} nominees={nominees} />
      </div>
    </PublicShell>
  );
}
