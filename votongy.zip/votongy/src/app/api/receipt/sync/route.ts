import { NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { verifyTransaction } from "@/lib/paystack";
import { clientIp, rateLimit, RULES, retryAfterSeconds } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const bodySchema = z.object({
  reference: z.string().trim().min(8).max(64).regex(/^[A-Za-z0-9_-]+$/),
});

/**
 * Safety net for a slow or missed webhook. The receipt page calls this while a payment is PENDING.
 * It does NOT trust the browser: it asks Paystack's API server-to-server whether the charge
 * succeeded, then uses the exact same atomic, idempotent RPC as the webhook.
 */
export async function POST(request: Request) {
  const body = bodySchema.safeParse(await request.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "Invalid reference" }, { status: 400 });
  const { reference } = body.data;

  const limit = await rateLimit(RULES.receipt, clientIp(request));
  if (!limit.success) {
    return NextResponse.json(
      { error: "Too many requests" },
      { status: 429, headers: { "Retry-After": String(retryAfterSeconds(limit)) } },
    );
  }

  const admin = createAdminClient();
  const { data: tx } = await admin
    .from("transactions")
    .select("id, status")
    .eq("reference", reference)
    .maybeSingle();
  if (!tx) return NextResponse.json({ status: "NOT_FOUND" }, { status: 404 });
  if (tx.status !== "PENDING") return NextResponse.json({ status: tx.status });

  try {
    const remote = await verifyTransaction(reference);

    if (remote.status === "success") {
      const { data, error } = await admin.rpc("process_successful_vote", {
        p_reference: reference,
        p_amount_pesewas: Number(remote.amount),
        p_currency: remote.currency,
        p_payload: { source: "verify-api", data: remote } as unknown as Record<string, unknown>,
      });
      if (error) throw error;
      const result = (data as { result?: string } | null)?.result;
      return NextResponse.json({ status: result === "SUCCESS" || result === "ALREADY_PROCESSED" ? "SUCCESS" : "FLAGGED" });
    }

    if (remote.status === "failed" || remote.status === "abandoned") {
      await admin
        .from("transactions")
        .update({
          status: remote.status === "failed" ? "FAILED" : "ABANDONED",
          failure_reason: remote.gateway_response ?? remote.status,
        })
        .eq("id", tx.id)
        .eq("status", "PENDING");
      return NextResponse.json({ status: remote.status === "failed" ? "FAILED" : "ABANDONED" });
    }

    return NextResponse.json({ status: "PENDING" });
  } catch (err) {
    console.error("[receipt/sync]", err);
    return NextResponse.json({ status: "PENDING" });
  }
}
