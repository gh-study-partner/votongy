import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { initializeTransaction } from "@/lib/paystack";
import { clientIp, rateLimit, RULES, retryAfterSeconds } from "@/lib/ratelimit";
import { firstError, initiateVoteSchema } from "@/lib/validation";
import { phoneDigits } from "@/lib/phone";
import { siteConfig } from "@/config/site";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function fail(message: string, status: number, headers?: Record<string, string>) {
  return NextResponse.json({ error: message }, { status, headers });
}

function newReference() {
  return `VTG-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(5).toString("hex").toUpperCase()}`;
}

export async function POST(request: Request) {
  // 1. Parse + validate (the amount is NEVER taken from the client)
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return fail("Invalid request.", 400);
  }
  const parsed = initiateVoteSchema.safeParse(body);
  if (!parsed.success) return fail(firstError(parsed.error), 400);
  const input = parsed.data;

  // 2. Rate limit by IP and by phone (Upstash, in-memory fallback in dev)
  const ip = clientIp(request);
  const [ipLimit, phoneLimit] = await Promise.all([
    rateLimit(RULES.voteIp, ip),
    rateLimit(RULES.votePhone, input.phone),
  ]);
  const blocked = !ipLimit.success ? ipLimit : !phoneLimit.success ? phoneLimit : null;
  if (blocked) {
    const retry = retryAfterSeconds(blocked);
    return fail(`Too many attempts. Please wait ${retry}s and try again.`, 429, {
      "Retry-After": String(retry),
    });
  }

  const admin = createAdminClient();

  // 3. Global kill-switch
  const { data: settings } = await admin
    .from("platform_settings")
    .select("voting_paused")
    .eq("id", true)
    .maybeSingle();
  if (settings?.voting_paused) {
    return fail("Voting is temporarily paused across VoTongy. Please try again shortly.", 503);
  }

  // 4. Event + nominee checks
  const { data: event } = await admin
    .from("events")
    .select("id, slug, title, status, cost_per_vote, currency, start_at, end_at")
    .eq("id", input.eventId)
    .maybeSingle();
  if (!event || !["ACTIVE"].includes(event.status as string)) {
    return fail("Voting is not open for this event.", 409);
  }
  const now = Date.now();
  if (now < new Date(event.start_at as string).getTime()) return fail("Voting has not started yet.", 409);
  if (now > new Date(event.end_at as string).getTime()) return fail("Voting for this event has ended.", 409);

  const { data: nominee } = await admin
    .from("nominees")
    .select("id, name, code, status, event_id")
    .eq("id", input.nomineeId)
    .maybeSingle();
  if (!nominee || nominee.event_id !== event.id || nominee.status !== "APPROVED") {
    return fail("That nominee is not available for voting.", 404);
  }

  // 5. Server-side pricing (integer pesewas, no float drift)
  const unitPesewas = Math.round(Number(event.cost_per_vote) * 100);
  const amountPesewas = unitPesewas * input.votes;
  if (!Number.isSafeInteger(amountPesewas) || amountPesewas <= 0) return fail("Invalid amount.", 400);
  const amount = amountPesewas / 100;

  // 6. Create the PENDING transaction
  const reference = newReference();
  const channel = input.channel === "PWA" ? "PWA" : "WEB";
  const { data: tx, error: txError } = await admin
    .from("transactions")
    .insert({
      reference,
      event_id: event.id,
      nominee_id: nominee.id,
      voter_phone: input.phone,
      voter_email: input.email ?? null,
      votes: input.votes,
      amount,
      currency: "GHS",
      status: "PENDING",
      channel,
    })
    .select("id")
    .single();
  if (txError || !tx) {
    console.error("[vote/initiate] insert failed", txError);
    return fail("We couldn't start your payment. Please try again.", 500);
  }

  // 7. Initialize Paystack (GHS, Mobile Money + Card)
  try {
    const payerEmail = input.email ?? `${phoneDigits(input.phone)}@${siteConfig.fallbackEmailDomain}`;
    const init = await initializeTransaction({
      email: payerEmail,
      amountPesewas,
      reference,
      callbackUrl: `${siteConfig.url}/receipt/${reference}`,
      metadata: {
        platform: "votongy",
        event_id: event.id,
        event_slug: event.slug,
        nominee_id: nominee.id,
        nominee_code: nominee.code,
        votes: input.votes,
        voter_phone: input.phone,
        custom_fields: [
          { display_name: "Event", variable_name: "event", value: event.title },
          { display_name: "Nominee", variable_name: "nominee", value: `${nominee.name} (${nominee.code})` },
          { display_name: "Votes", variable_name: "votes", value: String(input.votes) },
        ],
      },
    });
    return NextResponse.json({
      reference,
      authorizationUrl: init.authorization_url,
      amount,
      votes: input.votes,
    });
  } catch (err) {
    console.error("[vote/initiate] paystack init failed", err);
    await admin
      .from("transactions")
      .update({ status: "FAILED", failure_reason: "Paystack initialization failed" })
      .eq("id", tx.id);
    return fail("The payment provider is unavailable right now. You have not been charged. Please try again.", 502);
  }
}
