import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getSessionProfile } from "@/lib/auth";
import { clientIp, rateLimit, RULES, retryAfterSeconds } from "@/lib/ratelimit";
import { normalizeGhanaPhone } from "@/lib/phone";
import { verifyTransaction } from "@/lib/paystack";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const COLUMNS =
  "id, reference, voter_phone, voter_email, votes, amount, currency, status, channel, failure_reason, paid_at, created_at, events(title, slug), nominees(name, code)";

/** Super Admin support lookup: search by Paystack reference, phone number or voter email. */
export async function GET(request: Request) {
  const profile = await getSessionProfile();
  if (profile?.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const limit = await rateLimit(RULES.adminLookup, profile.id);
  if (!limit.success) {
    return NextResponse.json(
      { error: "Too many lookups" },
      { status: 429, headers: { "Retry-After": String(retryAfterSeconds(limit)) } },
    );
  }

  const q = (new URL(request.url).searchParams.get("q") ?? "").trim();
  if (q.length < 3) return NextResponse.json({ error: "Enter at least 3 characters." }, { status: 400 });

  const admin = createAdminClient();
  let query = admin.from("transactions").select(COLUMNS).order("created_at", { ascending: false }).limit(50);

  const phone = normalizeGhanaPhone(q);
  if (phone) {
    query = query.eq("voter_phone", phone);
  } else if (q.includes("@")) {
    query = query.ilike("voter_email", q);
  } else {
    // Escape LIKE wildcards in the user's text
    const safe = q.replace(/[%_\\]/g, (c) => `\\${c}`);
    query = query.ilike("reference", `%${safe}%`);
  }

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await logAudit({
    actorId: profile.id,
    action: "TX_LOOKUP",
    entity: "transactions",
    metadata: { q, results: data?.length ?? 0 },
  });

  return NextResponse.json({ results: data ?? [] });
}

/**
 * Reconcile a stuck PENDING/FAILED/ABANDONED payment against Paystack and, if it really succeeded,
 * credit the votes through the same atomic RPC (idempotent, so it cannot double-credit).
 */
export async function POST(request: Request) {
  const profile = await getSessionProfile();
  if (profile?.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  void clientIp;
  const body = (await request.json().catch(() => null)) as { reference?: string } | null;
  const reference = body?.reference?.trim();
  if (!reference) return NextResponse.json({ error: "Reference required" }, { status: 400 });

  const admin = createAdminClient();
  const { data: tx } = await admin.from("transactions").select("id, status").eq("reference", reference).maybeSingle();
  if (!tx) return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
  if (tx.status === "SUCCESS") return NextResponse.json({ status: "SUCCESS", message: "Already credited." });

  try {
    const remote = await verifyTransaction(reference);
    if (remote.status !== "success") {
      return NextResponse.json({
        status: tx.status,
        message: `Paystack reports this payment as "${remote.status}". No votes credited.`,
      });
    }
    const { data, error } = await admin.rpc("process_successful_vote", {
      p_reference: reference,
      p_amount_pesewas: Number(remote.amount),
      p_currency: remote.currency,
      p_payload: { source: "admin-reconcile", data: remote } as unknown as Record<string, unknown>,
    });
    if (error) throw error;
    const result = (data as { result?: string } | null)?.result ?? "UNKNOWN";
    await logAudit({
      actorId: profile.id,
      action: "TX_RECONCILED",
      entity: "transaction",
      entityId: tx.id as string,
      metadata: { reference, result },
    });
    return NextResponse.json({
      status: result === "SUCCESS" || result === "ALREADY_PROCESSED" ? "SUCCESS" : "FLAGGED",
      message:
        result === "AMOUNT_MISMATCH"
          ? "Paystack's amount does not match the expected amount. Transaction flagged, no votes credited."
          : "Votes credited from Paystack's confirmed payment.",
    });
  } catch (err) {
    console.error("[admin/tx-lookup reconcile]", err);
    return NextResponse.json({ error: "Could not reach Paystack. Try again." }, { status: 502 });
  }
}
