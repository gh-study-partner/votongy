import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getSessionProfile } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const bodySchema = z.object({ paused: z.boolean() });

/** Super Admin only: emergency kill-switch for ALL voting. */
export async function GET() {
  const profile = await getSessionProfile();
  if (profile?.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const supabase = await createClient();
  const { data } = await supabase.from("platform_settings").select("voting_paused").eq("id", true).maybeSingle();
  return NextResponse.json({ paused: Boolean(data?.voting_paused) });
}

export async function POST(request: Request) {
  const profile = await getSessionProfile();
  if (profile?.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = bodySchema.safeParse(await request.json().catch(() => null));
  if (!body.success) return NextResponse.json({ error: "Invalid request" }, { status: 400 });

  const admin = createAdminClient();
  const { error } = await admin
    .from("platform_settings")
    .update({ voting_paused: body.data.paused, updated_at: new Date().toISOString() })
    .eq("id", true);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await logAudit({
    actorId: profile.id,
    action: body.data.paused ? "VOTING_PAUSED_GLOBAL" : "VOTING_RESUMED_GLOBAL",
    entity: "platform_settings",
    entityId: "1",
  });

  return NextResponse.json({ paused: body.data.paused });
}
