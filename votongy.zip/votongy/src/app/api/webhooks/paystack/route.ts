import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { verifyPaystackSignature } from "@/lib/paystack";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface PaystackWebhookEvent {
  event: string;
  data?: {
    reference?: string;
    status?: string;
    amount?: number;
    currency?: string;
    gateway_response?: string;
  };
}

/**
 * Paystack webhook. This is the ONLY place (besides the server-to-server verify in
 * /api/receipt/sync) where votes can be credited. The browser callback is never trusted.
 *
 * 1. Verify x-paystack-signature (HMAC SHA512 over the RAW body, constant-time compare)
 * 2. On charge.success -> atomic RPC process_successful_vote (FOR UPDATE lock, idempotent,
 *    amount/currency integrity check)
 * 3. Always answer 200 for handled/ignorable events so Paystack stops retrying;
 *    answer 500 only on infrastructure errors so Paystack retries.
 */
export async function POST(request: Request) {
  const rawBody = await request.text();
  const signature = request.headers.get("x-paystack-signature");

  let valid = false;
  try {
    valid = verifyPaystackSignature(rawBody, signature);
  } catch (err) {
    console.error("[paystack-webhook] misconfigured", err);
    return NextResponse.json({ error: "Server misconfigured" }, { status: 500 });
  }
  if (!valid) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  let payload: PaystackWebhookEvent;
  try {
    payload = JSON.parse(rawBody) as PaystackWebhookEvent;
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const reference = payload.data?.reference;
  if (!reference) return NextResponse.json({ received: true });

  const admin = createAdminClient();

  if (payload.event === "charge.success") {
    const { data, error } = await admin.rpc("process_successful_vote", {
      p_reference: reference,
      p_amount_pesewas: Number(payload.data?.amount ?? 0),
      p_currency: payload.data?.currency ?? "",
      p_payload: payload as unknown as Record<string, unknown>,
    });
    if (error) {
      console.error("[paystack-webhook] rpc error", error);
      return NextResponse.json({ error: "Processing failed" }, { status: 500 });
    }
    return NextResponse.json({ received: true, result: (data as { result?: string } | null)?.result });
  }

  if (payload.event === "charge.failed" || payload.event === "charge.abandoned") {
    // Never downgrade a SUCCESS transaction.
    await admin
      .from("transactions")
      .update({
        status: payload.event === "charge.failed" ? "FAILED" : "ABANDONED",
        failure_reason: payload.data?.gateway_response ?? payload.event,
      })
      .eq("reference", reference)
      .eq("status", "PENDING");
  }

  return NextResponse.json({ received: true });
}

export function GET() {
  return NextResponse.json({ ok: true, service: "votongy-paystack-webhook" });
}
