import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { clientIp, rateLimit, RULES, retryAfterSeconds } from "@/lib/ratelimit";
import { firstError, nominationSchema } from "@/lib/validation";
import { siteConfig } from "@/config/site";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** Public nomination submission. Multipart form so a photo can be attached. Always lands as PENDING. */
export async function POST(request: Request) {
  const limit = await rateLimit(RULES.nominate, clientIp(request));
  if (!limit.success) {
    return NextResponse.json(
      { error: "Too many submissions. Please try again later." },
      { status: 429, headers: { "Retry-After": String(retryAfterSeconds(limit)) } },
    );
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Invalid form." }, { status: 400 });
  }

  // Honeypot: real people never fill this hidden field.
  if (String(form.get("website") ?? "").trim() !== "") {
    return NextResponse.json({ ok: true });
  }

  const parsed = nominationSchema.safeParse({
    eventId: form.get("eventId"),
    categoryId: form.get("categoryId"),
    name: form.get("name"),
    email: form.get("email") ?? "",
    phone: form.get("phone") ?? "",
    bio: form.get("bio") ?? "",
  });
  if (!parsed.success) return NextResponse.json({ error: firstError(parsed.error) }, { status: 400 });
  const input = parsed.data;

  const admin = createAdminClient();

  const { data: event } = await admin
    .from("events")
    .select("id, status, allow_public_nominations, end_at")
    .eq("id", input.eventId)
    .maybeSingle();
  if (
    !event ||
    !event.allow_public_nominations ||
    !["ACTIVE", "PAUSED", "PENDING_APPROVAL", "DRAFT"].includes(event.status as string) ||
    Date.now() > new Date(event.end_at as string).getTime()
  ) {
    return NextResponse.json({ error: "Nominations are closed for this event." }, { status: 409 });
  }

  const { data: category } = await admin
    .from("categories")
    .select("id")
    .eq("id", input.categoryId)
    .eq("event_id", event.id)
    .maybeSingle();
  if (!category) return NextResponse.json({ error: "Choose a valid category." }, { status: 400 });

  // Optional photo (validated by type and size, stored under a server-controlled path)
  let photoUrl: string | null = null;
  const photo = form.get("photo");
  if (photo instanceof File && photo.size > 0) {
    if (!(siteConfig.media.allowedImageTypes as readonly string[]).includes(photo.type)) {
      return NextResponse.json({ error: "Photo must be a JPG, PNG or WebP image." }, { status: 400 });
    }
    if (photo.size > siteConfig.media.maxImageBytes) {
      return NextResponse.json({ error: "Photo must be under 3 MB." }, { status: 400 });
    }
    const ext = photo.type === "image/png" ? "png" : photo.type === "image/webp" ? "webp" : "jpg";
    const path = `nominations/${event.id}/${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await admin.storage
      .from(siteConfig.media.bucket)
      .upload(path, Buffer.from(await photo.arrayBuffer()), { contentType: photo.type, upsert: false });
    if (upErr) {
      console.error("[nominate] upload failed", upErr);
      return NextResponse.json({ error: "Photo upload failed. Try a smaller image." }, { status: 500 });
    }
    photoUrl = admin.storage.from(siteConfig.media.bucket).getPublicUrl(path).data.publicUrl;
  }

  const { error } = await admin.from("nomination_applications").insert({
    event_id: event.id,
    category_id: input.categoryId,
    applicant_name: input.name,
    applicant_email: input.email ?? null,
    applicant_phone: input.phone ?? null,
    photo_url: photoUrl,
    bio: input.bio ?? null,
    status: "PENDING",
  });
  if (error) {
    console.error("[nominate] insert failed", error);
    return NextResponse.json({ error: "Could not save your nomination. Please try again." }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
