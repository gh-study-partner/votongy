import Link from "next/link";
import { PublicShell } from "@/components/layout/PublicShell";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <PublicShell>
      <div className="container flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
        <p className="font-display text-6xl font-extrabold text-gradient-gold">404</p>
        <h1 className="font-display text-2xl font-bold">We couldn&apos;t find that page</h1>
        <p className="max-w-sm text-zinc-400">
          The event or link you opened may have ended, moved or been typed incorrectly.
        </p>
        <Button asChild>
          <Link href="/">Back to events</Link>
        </Button>
      </div>
    </PublicShell>
  );
}
