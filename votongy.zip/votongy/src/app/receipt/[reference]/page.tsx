import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2, Clock3, ShieldAlert, XCircle } from "lucide-react";
import { PublicShell } from "@/components/layout/PublicShell";
import { PendingPoller, ReceiptActions } from "@/components/receipt/ReceiptActions";
import { ReceiptLookup } from "@/components/receipt/ReceiptLookup";
import { VoTongyLogo } from "@/components/brand/VoTongyLogo";
import { Button } from "@/components/ui/button";
import { createPublicClient } from "@/lib/supabase/public";
import { formatDateTime, formatGHS, formatNumber } from "@/lib/utils";
import { siteConfig } from "@/config/site";
import type { Receipt } from "@/types/database";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Vote receipt", robots: { index: false, follow: false } };

async function loadReceipt(reference: string): Promise<Receipt | null> {
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(reference)) return null;
  try {
    const supabase = createPublicClient();
    const { data, error } = await supabase.rpc("get_receipt", { p_reference: reference });
    if (error) {
      console.error("[receipt] rpc", error.message);
      return null;
    }
    const row = Array.isArray(data) ? data[0] : data;
    return (row as Receipt | undefined) ?? null;
  } catch (err) {
    console.error("[receipt]", err);
    return null;
  }
}

const STATUS = {
  SUCCESS: {
    icon: CheckCircle2,
    tone: "text-emerald-400",
    ring: "border-emerald-500/30 bg-emerald-500/5",
    title: "Vote confirmed",
    text: "Your payment was received and your votes have been counted.",
  },
  PENDING: {
    icon: Clock3,
    tone: "text-amber-400",
    ring: "border-amber-500/30 bg-amber-500/5",
    title: "Confirming your payment...",
    text: "Approve the prompt on your phone if you haven't yet. This page updates automatically. Do not pay again.",
  },
  FAILED: {
    icon: XCircle,
    tone: "text-red-400",
    ring: "border-red-500/30 bg-red-500/5",
    title: "Payment failed",
    text: "The payment did not go through and no votes were added. If you were debited, contact support with this reference.",
  },
  ABANDONED: {
    icon: XCircle,
    tone: "text-zinc-400",
    ring: "border-zinc-700 bg-zinc-900",
    title: "Payment not completed",
    text: "The payment was cancelled or timed out. You were not charged. You can try again.",
  },
  FLAGGED: {
    icon: ShieldAlert,
    tone: "text-red-400",
    ring: "border-red-500/30 bg-red-500/5",
    title: "Under review",
    text: "We detected an issue with this payment and our team is reviewing it. Contact support with this reference.",
  },
} as const;

export default async function ReceiptPage({ params }: { params: Promise<{ reference: string }> }) {
  const { reference: raw } = await params;
  const reference = decodeURIComponent(raw);
  const receipt = await loadReceipt(reference);

  if (!receipt) {
    return (
      <PublicShell>
        <div className="container max-w-xl py-16 text-center">
          <h1 className="font-display text-2xl font-bold">Receipt not found</h1>
          <p className="mb-6 mt-2 text-sm text-zinc-400">
            We couldn&apos;t find <span className="font-mono text-zinc-200">{reference.slice(0, 40)}</span>. Check the reference and try again.
          </p>
          <ReceiptLookup />
        </div>
      </PublicShell>
    );
  }

  const s = STATUS[receipt.status] ?? STATUS.PENDING;
  const Icon = s.icon;
  const rows: [string, string][] = [
    ["Event", receipt.event_title],
    ["Nominee", `${receipt.nominee_name} (${receipt.nominee_code})`],
    ["Votes", formatNumber(receipt.votes)],
    ["Amount paid", formatGHS(receipt.amount)],
    ["Date", formatDateTime(receipt.paid_at ?? receipt.created_at)],
    ["Voter", receipt.voter_phone_masked ?? "-"],
  ];

  return (
    <PublicShell>
      <div className="container max-w-lg py-8 sm:py-12">
        <div className={`mb-5 flex flex-col items-center gap-2 rounded-3xl border p-6 text-center ${s.ring}`}>
          <Icon className={`h-12 w-12 ${s.tone}`} />
          <h1 className="font-display text-2xl font-bold">{s.title}</h1>
          <p className="max-w-sm text-sm text-zinc-300">{s.text}</p>
        </div>

        <div className="overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-900">
          <div className="flex items-center justify-between border-b border-dashed border-zinc-700 p-5">
            <VoTongyLogo size={28} />
            <span className="text-xs font-semibold uppercase tracking-widest text-zinc-500">Official receipt</span>
          </div>
          <dl className="divide-y divide-zinc-800 px-5">
            {rows.map(([k, v]) => (
              <div key={k} className="flex items-start justify-between gap-4 py-3">
                <dt className="text-sm text-zinc-400">{k}</dt>
                <dd className="text-right text-sm font-semibold">{v}</dd>
              </div>
            ))}
            <div className="py-3">
              <dt className="text-sm text-zinc-400">Reference</dt>
              <dd className="mt-1 break-all rounded-lg bg-zinc-950 px-3 py-2 font-mono text-xs text-zinc-200">{receipt.reference}</dd>
            </div>
          </dl>
          <p className="border-t border-dashed border-zinc-700 p-4 text-center text-xs text-zinc-500">
            Payments secured by Paystack. All votes are final and non-refundable. Support: {siteConfig.supportEmail}
          </p>
        </div>

        <div className="mt-5 space-y-3">
          {receipt.status === "PENDING" && <PendingPoller reference={receipt.reference} />}
          {receipt.status === "SUCCESS" && (
            <ReceiptActions
              eventSlug={receipt.event_slug}
              nomineeCode={receipt.nominee_code}
              nomineeName={receipt.nominee_name}
              eventTitle={receipt.event_title}
              votes={receipt.votes}
              reference={receipt.reference}
            />
          )}
          {(receipt.status === "FAILED" || receipt.status === "ABANDONED") && (
            <Button asChild size="lg" className="w-full">
              <Link href={`/e/${receipt.event_slug}?nominee=${encodeURIComponent(receipt.nominee_code)}`}>Try again</Link>
            </Button>
          )}
        </div>
      </div>
    </PublicShell>
  );
}
