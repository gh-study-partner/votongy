import { Suspense } from "react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { BarChart3, CalendarClock, Megaphone, PauseCircle, UserPlus } from "lucide-react";
import { PublicShell } from "@/components/layout/PublicShell";
import { EventVoting } from "@/components/voting/EventVoting";
import { Countdown } from "@/components/voting/Countdown";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getEventBySlug, getEventCatalog } from "@/lib/data";
import { computeVotingState, formatDateTime, formatGHS } from "@/lib/utils";

// ISR: instant loads from the edge cache, refreshed every 15s. Live counts also poll client-side.
export const revalidate = 15;

type Params = { eventSlug: string };

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const { eventSlug } = await params;
  const event = await getEventBySlug(eventSlug);
  if (!event) return { title: "Event not found" };
  const description = event.description?.slice(0, 160) || `Vote for your favourite nominee in ${event.title} on VoTongy.`;
  return {
    title: event.title,
    description,
    openGraph: {
      title: `${event.title} - Vote on VoTongy`,
      description,
      images: event.banner_url ? [{ url: event.banner_url }] : undefined,
    },
  };
}

export default async function EventPage({ params }: { params: Promise<Params> }) {
  const { eventSlug } = await params;
  const event = await getEventBySlug(eventSlug);
  if (!event) notFound();

  const { categories, nominees } = await getEventCatalog(event.id);
  const state = computeVotingState(event);

  return (
    <PublicShell>
      {/* Banner */}
      <section className="relative overflow-hidden border-b border-zinc-800">
        {event.banner_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={event.banner_url} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
        ) : (
          <div className="bg-grid absolute inset-0" aria-hidden />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/40 via-zinc-950/70 to-zinc-950" />
        <div className="container relative z-10 py-10 sm:py-14">
          <div className="flex flex-wrap items-center gap-2">
            {state === "open" && (
              <Badge variant="success">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-emerald-400" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                Voting live
              </Badge>
            )}
            {state === "upcoming" && <Badge variant="warning">Starts soon</Badge>}
            {state === "paused" && <Badge variant="warning">Voting paused</Badge>}
            {state === "ended" && <Badge variant="muted">Voting ended</Badge>}
            <Badge variant="default">{formatGHS(event.cost_per_vote)} per vote</Badge>
          </div>

          <h1 className="mt-4 max-w-3xl font-display text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">
            {event.title}
          </h1>
          {event.description && <p className="mt-3 max-w-2xl text-zinc-300">{event.description}</p>}

          <div className="mt-6 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            {state === "open" && <Countdown target={event.end_at} label="Voting closes in" />}
            {state === "upcoming" && <Countdown target={event.start_at} label="Voting opens in" />}
            {(state === "ended" || state === "paused") && (
              <p className="flex items-center gap-2 text-sm text-zinc-300">
                {state === "paused" ? <PauseCircle className="h-4 w-4 text-amber-400" /> : <CalendarClock className="h-4 w-4" />}
                {state === "paused"
                  ? "Voting is temporarily paused. Please check back shortly."
                  : `Closed ${formatDateTime(event.end_at)}`}
              </p>
            )}

            <div className="flex flex-wrap gap-2">
              <Button asChild variant="outline" size="sm">
                <Link href={`/results/${event.slug}`}>
                  <BarChart3 className="h-4 w-4" /> Live results
                </Link>
              </Button>
              {event.allow_public_nominations && state !== "ended" && (
                <Button asChild variant="outline" size="sm">
                  <Link href={`/nominate/${event.slug}`}>
                    <UserPlus className="h-4 w-4" /> Nominate someone
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        {state === "upcoming" && (
          <p className="mt-5 flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-300">
            <Megaphone className="h-4 w-4 shrink-0" />
            Voting opens {formatDateTime(event.start_at)}. Browse the nominees in the meantime.
          </p>
        )}
        <Suspense fallback={null}>
          <EventVoting event={event} categories={categories} nominees={nominees} votingState={state} />
        </Suspense>
      </div>
    </PublicShell>
  );
}
