"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { CalendarDays, Loader2, Search, User } from "lucide-react";
import { Avatar } from "@/components/voting/Avatar";
import { createClient } from "@/lib/supabase/client";
import type { PublicNominee } from "@/types/database";

export interface SearchEvent {
  id: string;
  slug: string;
  title: string;
}

/** Live search across events (client-side, from server-provided list) and nominees (Supabase, debounced). */
export function GlobalSearch({ events }: { events: SearchEvent[] }) {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [nominees, setNominees] = useState<PublicNominee[]>([]);
  const [focused, setFocused] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const seq = useRef(0);

  const term = q.trim();
  const eventById = new Map(events.map((e) => [e.id, e]));
  const matchedEvents = term.length >= 2
    ? events.filter((e) => e.title.toLowerCase().includes(term.toLowerCase())).slice(0, 4)
    : [];

  useEffect(() => {
    if (term.length < 2) {
      setNominees([]);
      setLoading(false);
      return;
    }
    const mySeq = ++seq.current;
    setLoading(true);
    const timer = window.setTimeout(async () => {
      const supabase = createClient();
      // Strip characters that have meaning inside PostgREST filter strings
      const safe = term.replace(/[%,()*\\]/g, " ").trim();
      const { data } = await supabase
        .from("public_nominees")
        .select("id, event_id, category_id, name, code, photo_url, bio, total_votes")
        .or(`name.ilike.%${safe}%,code.ilike.${safe}%`)
        .limit(8);
      if (mySeq !== seq.current) return;
      setNominees((data ?? []) as PublicNominee[]);
      setLoading(false);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [term]);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setFocused(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const showPanel = focused && term.length >= 2;
  const empty = !loading && matchedEvents.length === 0 && nominees.length === 0;

  return (
    <div ref={wrapRef} className="relative mx-auto w-full max-w-xl">
      <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-zinc-500" />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        onFocus={() => setFocused(true)}
        placeholder="Search nominee name, code (N042) or event"
        aria-label="Search nominees and events"
        className="h-14 w-full rounded-2xl border border-zinc-700 bg-zinc-900/90 pl-12 pr-12 text-base text-white shadow-xl shadow-black/30 backdrop-blur placeholder:text-zinc-500 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
      />
      {loading && <Loader2 className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 animate-spin text-zinc-500" />}

      {showPanel && (
        <div className="absolute inset-x-0 top-full z-30 mt-2 max-h-[60vh] overflow-y-auto rounded-2xl border border-zinc-800 bg-zinc-900 p-2 text-left shadow-2xl shadow-black/60">
          {matchedEvents.length > 0 && (
            <div className="mb-1">
              <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-500">Events</p>
              {matchedEvents.map((e) => (
                <Link
                  key={e.id}
                  href={`/e/${e.slug}`}
                  className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-zinc-800"
                >
                  <CalendarDays className="h-4 w-4 text-primary" />
                  <span className="truncate text-sm font-medium">{e.title}</span>
                </Link>
              ))}
            </div>
          )}
          {nominees.length > 0 && (
            <div>
              <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-500">Nominees</p>
              {nominees.map((n) => {
                const ev = eventById.get(n.event_id);
                if (!ev) return null;
                return (
                  <Link
                    key={n.id}
                    href={`/e/${ev.slug}?nominee=${encodeURIComponent(n.code)}`}
                    className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-zinc-800"
                  >
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-zinc-800">
                      <Avatar src={n.photo_url} name={n.name} rounded="rounded-full" className="text-sm" />
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">
                        {n.name} <span className="text-xs font-normal text-primary">{n.code}</span>
                      </p>
                      <p className="truncate text-xs text-zinc-500">{ev.title}</p>
                    </div>
                    <User className="ml-auto h-4 w-4 shrink-0 text-zinc-600" />
                  </Link>
                );
              })}
            </div>
          )}
          {empty && <p className="px-3 py-6 text-center text-sm text-zinc-500">No matches for &ldquo;{term}&rdquo;.</p>}
        </div>
      )}
    </div>
  );
}
