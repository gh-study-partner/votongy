"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertCircle, Loader2, Lock, ShieldCheck, Smartphone, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldHint, Input, Label } from "@/components/ui/input";
import { Avatar } from "./Avatar";
import { siteConfig } from "@/config/site";
import { detectNetwork, normalizeGhanaPhone } from "@/lib/phone";
import { cn, formatGHS, formatNumber } from "@/lib/utils";
import type { PublicEvent, PublicNominee } from "@/types/database";

interface Props {
  open: boolean;
  onClose: () => void;
  event: PublicEvent;
  nominee: PublicNominee | null;
}

const PHONE_KEY = "votongy:voter-phone";

export function CheckoutDrawer({ open, onClose, event, nominee }: Props) {
  const [bundle, setBundle] = useState<number | "custom">(siteConfig.votes.defaultBundle);
  const [custom, setCustom] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Restore the voter's last phone number (convenience only)
  useEffect(() => {
    try {
      const saved = localStorage.getItem(PHONE_KEY);
      if (saved) setPhone(saved);
    } catch {
      /* storage unavailable */
    }
  }, []);

  useEffect(() => {
    if (open) {
      setError(null);
      setBusy(false);
    }
  }, [open, nominee?.id]);

  // Lock page scroll while open
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && !busy && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, busy, onClose]);

  const votes = useMemo(() => {
    if (bundle === "custom") {
      const n = Math.floor(Number(custom));
      return Number.isFinite(n) ? n : 0;
    }
    return bundle;
  }, [bundle, custom]);

  const total = Math.round(votes * Number(event.cost_per_vote) * 100) / 100;
  const network = detectNetwork(phone);
  const votesValid = votes >= siteConfig.votes.min && votes <= siteConfig.votes.max;

  async function pay() {
    setError(null);
    if (!nominee) return;
    if (!votesValid) {
      return setError(`Enter between ${siteConfig.votes.min} and ${formatNumber(siteConfig.votes.max)} votes.`);
    }
    if (!normalizeGhanaPhone(phone)) {
      return setError("Enter a valid Ghana mobile number, e.g. 024 123 4567.");
    }
    if (email && !/^\S+@\S+\.\S+$/.test(email)) return setError("That email address looks incorrect.");

    setBusy(true);
    try {
      const standalone = window.matchMedia("(display-mode: standalone)").matches;
      const res = await fetch("/api/vote/initiate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventId: event.id,
          nomineeId: nominee.id,
          votes,
          phone,
          email: email || undefined,
          channel: standalone ? "PWA" : "WEB",
        }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; authorizationUrl?: string };
      if (!res.ok || !json.authorizationUrl) {
        setError(json.error ?? "Could not start payment. Please try again.");
        setBusy(false);
        return;
      }
      try {
        localStorage.setItem(PHONE_KEY, phone);
      } catch {
        /* ignore */
      }
      window.location.assign(json.authorizationUrl);
    } catch {
      setError("Network problem. Check your connection and try again.");
      setBusy(false);
    }
  }

  return (
    <AnimatePresence>
      {open && nominee && (
        <motion.div
          className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => !busy && onClose()}
          role="dialog"
          aria-modal="true"
          aria-label={`Vote for ${nominee.name}`}
        >
          <motion.div
            className="safe-bottom max-h-[94dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-zinc-800 bg-zinc-900 shadow-2xl sm:rounded-3xl"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 32, stiffness: 340 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.4 }}
            onDragEnd={(_, info) => {
              if (!busy && (info.offset.y > 120 || info.velocity.y > 600)) onClose();
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mt-2.5 h-1.5 w-10 rounded-full bg-zinc-700 sm:hidden" />

            <div className="p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-zinc-800">
                  <Avatar src={nominee.photo_url} name={nominee.name} rounded="rounded-xl" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold uppercase tracking-wider text-primary">{nominee.code}</p>
                  <h2 className="truncate font-display text-lg font-bold">{nominee.name}</h2>
                  <p className="truncate text-sm text-zinc-400">{event.title}</p>
                </div>
                <button
                  onClick={onClose}
                  disabled={busy}
                  aria-label="Close"
                  className="rounded-full p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="mt-6">
                <p className="mb-2 text-sm font-medium text-zinc-300">
                  Choose votes <span className="text-zinc-500">({formatGHS(event.cost_per_vote)} each)</span>
                </p>
                <div className="grid grid-cols-4 gap-2">
                  {siteConfig.votes.bundles.map((b) => (
                    <button
                      key={b}
                      onClick={() => setBundle(b)}
                      className={cn(
                        "rounded-xl border px-2 py-3 text-center transition-colors",
                        bundle === b
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-zinc-700 bg-zinc-950 text-zinc-200 hover:border-zinc-500",
                      )}
                    >
                      <div className="font-display text-lg font-bold">{b}</div>
                      <div className="text-[11px] text-zinc-400">{formatGHS(b * Number(event.cost_per_vote))}</div>
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setBundle("custom")}
                  className={cn(
                    "mt-2 w-full rounded-xl border px-3 py-2.5 text-sm font-semibold transition-colors",
                    bundle === "custom"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-zinc-700 bg-zinc-950 text-zinc-300 hover:border-zinc-500",
                  )}
                >
                  Custom amount
                </button>
                {bundle === "custom" && (
                  <Input
                    autoFocus
                    inputMode="numeric"
                    pattern="[0-9]*"
                    placeholder="Number of votes"
                    value={custom}
                    onChange={(e) => setCustom(e.target.value.replace(/\D/g, "").slice(0, 5))}
                    className="mt-2"
                    aria-label="Custom number of votes"
                  />
                )}
              </div>

              <div className="mt-5 space-y-4">
                <div>
                  <Label htmlFor="voter-phone">Mobile Money number</Label>
                  <div className="relative">
                    <Smartphone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                    <Input
                      id="voter-phone"
                      type="tel"
                      inputMode="tel"
                      autoComplete="tel"
                      placeholder="024 123 4567"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="pl-9"
                    />
                    {network && (
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-emerald-500/10 px-2 py-0.5 text-xs font-semibold text-emerald-400">
                        {network}
                      </span>
                    )}
                  </div>
                  <FieldHint>You&apos;ll approve the payment on this number (MTN, Telecel or AirtelTigo). Cards also accepted.</FieldHint>
                </div>
                <div>
                  <Label htmlFor="voter-email">
                    Email <span className="text-zinc-500">(optional, for your receipt)</span>
                  </Label>
                  <Input
                    id="voter-email"
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              {error && (
                <p role="alert" className="mt-4 flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  {error}
                </p>
              )}

              <div className="mt-5 flex items-center justify-between rounded-xl bg-zinc-950 px-4 py-3">
                <span className="text-sm text-zinc-400">
                  {votesValid ? formatNumber(votes) : 0} vote{votes === 1 ? "" : "s"}
                </span>
                <span className="font-display text-xl font-bold text-white">{formatGHS(votesValid ? total : 0)}</span>
              </div>

              <Button size="lg" className="mt-4 w-full" onClick={pay} disabled={busy || !votesValid}>
                {busy ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Opening secure payment...
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4" /> Pay {formatGHS(votesValid ? total : 0)}
                  </>
                )}
              </Button>

              <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-zinc-500">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                Secured by Paystack. All votes are final and non-refundable.
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
