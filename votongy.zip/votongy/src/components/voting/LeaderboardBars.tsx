"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Crown, EyeOff, Radio } from "lucide-react";
import { Avatar } from "./Avatar";
import { createClient } from "@/lib/supabase/client";
import { cn, formatNumber } from "@/lib/utils";
import type { PublicCategory, PublicNominee } from "@/types/database";

interface Props {
  eventId: string;
  eventStatus: string;
  categories: PublicCategory[];
  nominees: PublicNominee[];
}

export function LeaderboardBars({ eventId, eventStatus, categories, nominees: initial }: Props) {
  const [nominees, setNominees] = useState(initial);
  const [active, setActive] = useState<string | "all">("all");
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);

  const hidden = initial.length > 0 && initial.every((n) => n.total_votes === null);
  const live = eventStatus !== "ENDED";

  useEffect(() => {
    if (hidden || !live) return;
    const supabase = createClient();
    let stopped = false;
    const tick = async () => {
      if (document.visibilityState !== "visible") return;
      const { data } = await supabase.from("public_nominees").select("id, total_votes").eq("event_id", eventId);
      if (stopped || !data) return;
      const map = new Map(data.map((r: { id: string; total_votes: number | null }) => [r.id, r.total_votes]));
      setNominees((prev) => prev.map((n) => ({ ...n, total_votes: map.get(n.id) ?? n.total_votes })));
      setUpdatedAt(new Date());
    };
    const id = window.setInterval(tick, 10000);
    return () => {
      stopped = true;
      window.clearInterval(id);
    };
  }, [eventId, hidden, live]);

  const sections = useMemo(() => {
    const cats = active === "all" ? categories : categories.filter((c) => c.id === active);
    return cats.map((c) => {
      const items = nominees
        .filter((n) => n.category_id === c.id)
        .sort((a, b) => (b.total_votes ?? 0) - (a.total_votes ?? 0));
      const total = items.reduce((sum, n) => sum + (n.total_votes ?? 0), 0);
      return { category: c, items, total };
    });
  }, [categories, nominees, active]);

  if (hidden) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-2xl border border-zinc-800 bg-zinc-900 px-6 py-14 text-center">
        <EyeOff className="h-8 w-8 text-zinc-500" />
        <h2 className="font-display text-lg font-semibold">Live results are hidden</h2>
        <p className="max-w-sm text-sm text-zinc-400">
          The organizer has chosen to keep vote counts private until voting ends. Final results will be published here.
        </p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="scrollbar-none -mx-4 flex gap-2 overflow-x-auto px-4">
          {[{ id: "all", name: "All categories" }, ...categories.map((c) => ({ id: c.id, name: c.name }))].map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={cn(
                "shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition-colors",
                active === c.id
                  ? "border-primary bg-primary text-zinc-950"
                  : "border-zinc-800 bg-zinc-900 text-zinc-300 hover:text-white",
              )}
            >
              {c.name}
            </button>
          ))}
        </div>
        {live && (
          <span className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-emerald-400" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
            </span>
            <Radio className="h-3.5 w-3.5" /> LIVE{updatedAt ? ` · updated ${updatedAt.toLocaleTimeString("en-GH", { timeStyle: "medium", timeZone: "Africa/Accra" })}` : ""}
          </span>
        )}
      </div>

      <div className="space-y-8">
        {sections.map(({ category, items, total }) => (
          <section key={category.id} className="rounded-2xl border border-zinc-800 bg-zinc-900 p-4 sm:p-6">
            <div className="mb-4 flex items-baseline justify-between gap-3">
              <h2 className="font-display text-lg font-bold">{category.name}</h2>
              <span className="text-xs text-zinc-500">{formatNumber(total)} total votes</span>
            </div>
            {items.length === 0 ? (
              <p className="text-sm text-zinc-500">No nominees yet.</p>
            ) : (
              <ol className="space-y-3">
                {items.map((n, i) => {
                  const pct = total > 0 ? ((n.total_votes ?? 0) / total) * 100 : 0;
                  return (
                    <motion.li layout key={n.id} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="flex items-center gap-3">
                      <span
                        className={cn(
                          "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                          i === 0 && total > 0 ? "bg-primary text-zinc-950" : "bg-zinc-800 text-zinc-400",
                        )}
                      >
                        {i === 0 && total > 0 ? <Crown className="h-3.5 w-3.5" /> : i + 1}
                      </span>
                      <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-zinc-800">
                        <Avatar src={n.photo_url} name={n.name} rounded="rounded-full" className="text-sm" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline justify-between gap-2">
                          <p className="truncate text-sm font-semibold">
                            {n.name} <span className="text-xs font-normal text-zinc-500">{n.code}</span>
                          </p>
                          <p className="shrink-0 text-sm tabular-nums">
                            <span className="font-bold">{formatNumber(n.total_votes)}</span>{" "}
                            <span className="text-xs text-zinc-500">{pct.toFixed(1)}%</span>
                          </p>
                        </div>
                        <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-zinc-800">
                          <motion.div
                            className={cn(
                              "h-full rounded-full",
                              i === 0 && total > 0
                                ? "bg-gradient-to-r from-amber-400 to-amber-600"
                                : "bg-gradient-to-r from-zinc-500 to-zinc-600",
                            )}
                            initial={{ width: 0 }}
                            animate={{ width: `${pct}%` }}
                            transition={{ duration: 0.9, ease: "easeOut" }}
                          />
                        </div>
                      </div>
                    </motion.li>
                  );
                })}
              </ol>
            )}
          </section>
        ))}
      </div>
    </div>
  );
}
