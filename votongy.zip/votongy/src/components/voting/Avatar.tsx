import { cn, initials } from "@/lib/utils";

/** Nominee photo with a graceful initials fallback (plain <img> avoids remote-domain config). */
export function Avatar({
  src,
  name,
  className,
  rounded = "rounded-2xl",
}: {
  src?: string | null;
  name: string;
  className?: string;
  rounded?: string;
}) {
  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt={name}
        loading="lazy"
        decoding="async"
        className={cn("h-full w-full object-cover", rounded, className)}
      />
    );
  }
  return (
    <div
      className={cn(
        "flex h-full w-full items-center justify-center bg-gradient-to-br from-zinc-800 to-zinc-900 font-display text-2xl font-bold text-primary",
        rounded,
        className,
      )}
      aria-label={name}
    >
      {initials(name)}
    </div>
  );
}
