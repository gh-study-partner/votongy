"use client";

import { useEffect, useState } from "react";

function parts(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return {
    d: Math.floor(total / 86400),
    h: Math.floor((total % 86400) / 3600),
    m: Math.floor((total % 3600) / 60),
    s: total % 60,
  };
}

export function Countdown({
  target,
  label,
  compact = false,
}: {
  target: string;
  label: string;
  compact?: boolean;
}) {
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const remaining = now === null ? null : new Date(target).getTime() - now;
  const p = remaining === null ? null : parts(remaining);
  const cells: [string, number | null][] = [
    ["Days", p?.d ?? null],
    ["Hrs", p?.h ?? null],
    ["Min", p?.m ?? null],
    ["Sec", p?.s ?? null],
  ];

  if (compact) {
    return (
      <span className="tabular-nums text-xs text-zinc-400">
        {label}{" "}
        {p ? (p.d > 0 ? `${p.d}d ${p.h}h ${p.m}m` : `${p.h}h ${p.m}m ${p.s}s`) : "--"}
      </span>
    );
  }

  return (
    <div>
      <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-zinc-400">{label}</p>
      <div className="flex gap-2">
        {cells.map(([name, value]) => (
          <div
            key={name}
            className="min-w-[58px] rounded-xl border border-zinc-800 bg-zinc-900 px-2 py-2 text-center"
          >
            <div className="font-display text-xl font-bold tabular-nums text-white">
              {value === null ? "--" : String(value).padStart(2, "0")}
            </div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500">{name}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
