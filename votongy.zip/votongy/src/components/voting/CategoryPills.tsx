"use client";

import { cn } from "@/lib/utils";
import type { PublicCategory } from "@/types/database";

export function CategoryPills({
  categories,
  active,
  onChange,
}: {
  categories: PublicCategory[];
  active: string | "all";
  onChange: (id: string | "all") => void;
}) {
  const items: { id: string | "all"; name: string }[] = [
    { id: "all", name: "All" },
    ...categories.map((c) => ({ id: c.id, name: c.name })),
  ];
  return (
    <div
      className="scrollbar-none -mx-4 flex gap-2 overflow-x-auto px-4 pb-1"
      role="tablist"
      aria-label="Categories"
    >
      {items.map((item) => (
        <button
          key={item.id}
          role="tab"
          aria-selected={active === item.id}
          onClick={() => onChange(item.id)}
          className={cn(
            "shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition-colors",
            active === item.id
              ? "border-primary bg-primary text-zinc-950"
              : "border-zinc-800 bg-zinc-900 text-zinc-300 hover:border-zinc-600 hover:text-white",
          )}
        >
          {item.name}
        </button>
      ))}
    </div>
  );
}
