import Link from "next/link";
import { ArrowUpRight, CalendarClock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { VoTongyMark } from "@/components/brand/VoTongyLogo";
import { cn, computeVotingState, formatDate, formatGHS } from "@/lib/utils";
import type { PublicEvent } from "@/types/database";

const STATE_BADGE = {
  open: { label: "Voting live", variant: "success" as const },
  upcoming: { label: "Starts soon", variant: "warning" as const },
  paused: { label: "Paused", variant: "warning" as const },
  ended: { label: "Ended", variant: "muted" as const },
};

/** Bento tile for an event. `featured` spans two columns on larger screens. */
export function EventCard({ event, featured = false }: { event: PublicEvent; featured?: boolean }) {
  const state = computeVotingState(event);
  const badge = STATE_BADGE[state];

  return (
    <Link
      href={`/e/${event.slug}`}
      className={cn(
        "group relative flex min-h-[220px] flex-col justify-end overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-900 transition-all hover:border-zinc-600",
        featured && "sm:col-span-2 sm:min-h-[300px]",
      )}
    >
      {event.banner_url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={event.banner_url}
          alt=""
          loading="lazy"
          decoding="async"
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
      ) : (
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-800 via-zinc-900 to-zinc-950">
          <VoTongyMark size={96} className="absolute right-5 top-5 opacity-[0.08]" />
        </div>
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/60 to-transparent" />

      <div className="relative z-10 space-y-2 p-5">
        <div className="flex items-center gap-2">
          <Badge variant={badge.variant}>
            {state === "open" && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />}
            {badge.label}
          </Badge>
          <span className="text-xs font-semibold text-primary">{formatGHS(event.cost_per_vote)} / vote</span>
        </div>
        <h3 className={cn("font-display font-bold leading-tight text-white", featured ? "text-2xl sm:text-3xl" : "text-xl")}>
          {event.title}
        </h3>
        <div className="flex items-center justify-between text-xs text-zinc-400">
          <span className="flex items-center gap-1.5">
            <CalendarClock className="h-3.5 w-3.5" />
            {state === "ended" ? `Ended ${formatDate(event.end_at)}` : `Ends ${formatDate(event.end_at)}`}
          </span>
          <span className="flex items-center gap-1 font-semibold text-white opacity-0 transition-opacity group-hover:opacity-100">
            {state === "open" ? "Vote now" : "View"} <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
      </div>
    </Link>
  );
}
