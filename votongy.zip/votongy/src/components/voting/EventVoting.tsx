"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { CategoryPills } from "./CategoryPills";
import { NomineeCard } from "./NomineeCard";
import { CheckoutDrawer } from "./CheckoutDrawer";
import { createClient } from "@/lib/supabase/client";
import { eventVoteUrl, whatsappShareUrl, type VotingState } from "@/lib/utils";
import type { PublicCategory, PublicEvent, PublicNominee } from "@/types/database";

interface Props {
  event: PublicEvent;
  categories: PublicCategory[];
  nominees: PublicNominee[];
  votingState: VotingState;
}

export function EventVoting({ event, categories, nominees: initial, votingState }: Props) {
  const params = useSearchParams();
  const deepCode = params.get("nominee")?.trim().toUpperCase() ?? null;

  const [nominees, setNominees] = useState(initial);
  const [category, setCategory] = useState<string | "all">("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<PublicNominee | null>(null);
  const [open, setOpen] = useState(false);

  const canVote = votingState === "open";

  // Deep link: /e/slug?nominee=N042 opens that nominee's checkout drawer immediately.
  useEffect(() => {
    if (!deepCode) return;
    const match = initial.find((n) => n.code === deepCode);
    if (match) {
      setCategory(match.category_id);
      setSelected(match);
      if (canVote) setOpen(true);
    }
  }, [deepCode, initial, canVote]);

  // Live totals: refresh counts every 20s while the tab is visible.
  useEffect(() => {
    if (!event.show_live_votes && event.status !== "ENDED") return;
    if (event.status === "ENDED") return;
    const supabase = createClient();
    let stopped = false;
    const tick = async () => {
      if (document.visibilityState !== "visible") return;
      const { data } = await supabase
        .from("public_nominees")
        .select("id, total_votes")
        .eq("event_id", event.id);
      if (stopped || !data) return;
      const map = new Map(data.map((r: { id: string; total_votes: number | null }) => [r.id, r.total_votes]));
      setNominees((prev) => prev.map((n) => (map.has(n.id) ? { ...n, total_votes: map.get(n.id) ?? null } : n)));
    };
    const id = window.setInterval(tick, 20000);
    return () => {
      stopped = true;
      window.clearInterval(id);
    };
  }, [event.id, event.show_live_votes, event.status]);

  const categoryTotals = useMemo(() => {
    const totals = new Map<string, number>();
    nominees.forEach((n) => totals.set(n.category_id, (totals.get(n.category_id) ?? 0) + (n.total_votes ?? 0)));
    return totals;
  }, [nominees]);

  const rankInCategory = useMemo(() => {
    const ranks = new Map<string, number>();
    const byCat = new Map<string, PublicNominee[]>();
    nominees.forEach((n) => byCat.set(n.category_id, [...(byCat.get(n.category_id) ?? []), n]));
    byCat.forEach((list) => {
      [...list]
        .sort((a, b) => (b.total_votes ?? 0) - (a.total_votes ?? 0))
        .forEach((n, i) => ranks.set(n.id, i + 1));
    });
    return ranks;
  }, [nominees]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return nominees.filter((n) => {
      if (category !== "all" && n.category_id !== category) return false;
      if (!q) return true;
      return n.name.toLowerCase().includes(q) || (n.code ?? "").toLowerCase().includes(q);
    });
  }, [nominees, category, query]);

  const grouped = useMemo(() => {
    const cats = category === "all" ? categories : categories.filter((c) => c.id === category);
    return cats
      .map((c) => ({ category: c, items: visible.filter((n) => n.category_id === c.id) }))
      .filter((g) => g.items.length > 0);
  }, [categories, category, visible]);

  const vote = useCallback((n: PublicNominee) => {
    setSelected(n);
    setOpen(true);
  }, []);

  const share = useCallback(
    async (n: PublicNominee) => {
      const url = eventVoteUrl(event.slug, n.code);
      const text = `Vote for ${n.name} (${n.code}) in ${event.title} on VoTongy: ${url}`;
      if (navigator.share) {
        try {
          await navigator.share({ title: event.title, text, url });
          return;
        } catch {
          /* user cancelled: fall through */
        }
      }
      window.open(whatsappShareUrl(text), "_blank", "noopener,noreferrer");
    },
    [event.slug, event.title],
  );

  return (
    <>
      <div className="sticky top-14 z-30 -mx-4 space-y-3 border-b border-zinc-800/70 bg-zinc-950/90 px-4 py-3 backdrop-blur-xl">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search nominee name or code (e.g. N042)"
            className="pl-9"
            aria-label="Search nominees"
          />
        </div>
        {categories.length > 0 && (
          <CategoryPills categories={categories} active={category} onChange={setCategory} />
        )}
      </div>

      {nominees.length === 0 ? (
        <p className="py-16 text-center text-zinc-400">Nominees will appear here soon.</p>
      ) : grouped.length === 0 ? (
        <p className="py-16 text-center text-zinc-400">No nominees match your search.</p>
      ) : (
        <div className="space-y-10 py-6">
          {grouped.map(({ category: c, items }) => (
            <section key={c.id} aria-labelledby={`cat-${c.id}`}>
              <h2 id={`cat-${c.id}`} className="mb-4 font-display text-xl font-bold tracking-tight">
                {c.name}
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {items.map((n) => {
                  const total = categoryTotals.get(n.category_id) ?? 0;
                  return (
                    <NomineeCard
                      key={n.id}
                      nominee={n}
                      rank={rankInCategory.get(n.id)}
                      share={n.total_votes === null ? undefined : total > 0 ? ((n.total_votes ?? 0) / total) * 100 : 0}
                      canVote={canVote}
                      onVote={vote}
                      onShare={share}
                      highlighted={deepCode === n.code}
                    />
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}

      <CheckoutDrawer open={open} onClose={() => setOpen(false)} event={event} nominee={selected} />
    </>
  );
}
