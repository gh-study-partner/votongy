"use client";

import { motion } from "framer-motion";
import { Check, Crown, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "./Avatar";
import { formatNumber } from "@/lib/utils";
import type { PublicNominee } from "@/types/database";

interface Props {
  nominee: PublicNominee;
  /** 0-100, share of the category's votes. undefined hides the bar (live votes disabled). */
  share?: number;
  rank?: number;
  canVote: boolean;
  onVote: (nominee: PublicNominee) => void;
  onShare: (nominee: PublicNominee) => void;
  highlighted?: boolean;
}

export function NomineeCard({ nominee, share, rank, canVote, onVote, onShare, highlighted }: Props) {
  const showVotes = nominee.total_votes !== null;
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className={`group relative overflow-hidden rounded-2xl border bg-zinc-900 transition-colors ${
        highlighted ? "border-primary shadow-lg shadow-primary/10" : "border-zinc-800 hover:border-zinc-700"
      }`}
    >
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-zinc-950">
        <Avatar src={nominee.photo_url} name={nominee.name} rounded="rounded-none" className="transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-zinc-950/90 to-transparent" />
        <span className="absolute left-2.5 top-2.5 rounded-full bg-zinc-950/80 px-2.5 py-1 text-xs font-bold tracking-wider text-primary backdrop-blur">
          {nominee.code}
        </span>
        {rank === 1 && showVotes && (nominee.total_votes ?? 0) > 0 && (
          <span className="absolute right-2.5 top-2.5 flex items-center gap-1 rounded-full bg-primary px-2.5 py-1 text-xs font-bold text-zinc-950">
            <Crown className="h-3 w-3" /> Leading
          </span>
        )}
        <button
          onClick={() => onShare(nominee)}
          aria-label={`Share ${nominee.name}`}
          className="absolute bottom-2.5 right-2.5 rounded-full bg-zinc-950/70 p-2 text-zinc-200 backdrop-blur transition-colors hover:bg-zinc-800"
        >
          <Share2 className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-3 p-3.5">
        <div>
          <h3 className="truncate font-display text-base font-semibold" title={nominee.name}>
            {nominee.name}
          </h3>
          {showVotes && (
            <p className="mt-0.5 flex items-center gap-1 text-xs text-zinc-400">
              <Check className="h-3 w-3 text-emerald-400" />
              <span className="tabular-nums font-semibold text-zinc-200">{formatNumber(nominee.total_votes)}</span> votes
            </p>
          )}
        </div>

        {showVotes && share !== undefined && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-800" aria-hidden>
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-600"
              initial={{ width: 0 }}
              animate={{ width: `${Math.max(share, share > 0 ? 3 : 0)}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          </div>
        )}

        <Button className="w-full" disabled={!canVote} onClick={() => onVote(nominee)}>
          {canVote ? "Vote" : "Voting closed"}
        </Button>
      </div>
    </motion.article>
  );
}
