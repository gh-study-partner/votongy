"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Printer, RefreshCw, Repeat, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { eventVoteUrl, whatsappShareUrl } from "@/lib/utils";

/**
 * While a payment is PENDING we poll the server. /api/receipt/sync asks Paystack directly
 * (server-to-server) as a backup for slow webhooks, then we refresh the server-rendered page.
 */
export function PendingPoller({ reference }: { reference: string }) {
  const router = useRouter();
  const tries = useRef(0);

  useEffect(() => {
    let stopped = false;
    const run = async () => {
      if (stopped) return;
      tries.current += 1;
      try {
        const res = await fetch("/api/receipt/sync", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ reference }),
        });
        const json = (await res.json().catch(() => ({}))) as { status?: string };
        if (json.status && json.status !== "PENDING") {
          router.refresh();
          return;
        }
      } catch {
        /* retry */
      }
      if (tries.current < 40) timer = window.setTimeout(run, tries.current < 6 ? 3000 : 8000);
    };
    let timer = window.setTimeout(run, 1500);
    return () => {
      stopped = true;
      window.clearTimeout(timer);
    };
  }, [reference, router]);

  return (
    <Button variant="secondary" className="w-full" onClick={() => router.refresh()}>
      <RefreshCw className="h-4 w-4" /> Check status now
    </Button>
  );
}

export function ReceiptActions({
  eventSlug,
  nomineeCode,
  nomineeName,
  eventTitle,
  votes,
  reference,
}: {
  eventSlug: string;
  nomineeCode: string;
  nomineeName: string;
  eventTitle: string;
  votes: number;
  reference: string;
}) {
  const voteUrl = eventVoteUrl(eventSlug, nomineeCode);
  const text = `I just cast ${votes} vote${votes === 1 ? "" : "s"} for ${nomineeName} (${nomineeCode}) in ${eventTitle} on VoTongy! Vote here: ${voteUrl}`;

  return (
    <div className="no-print grid gap-2 sm:grid-cols-2">
      <Button asChild size="lg">
        <Link href={`/e/${eventSlug}?nominee=${encodeURIComponent(nomineeCode)}`}>
          <Repeat className="h-4 w-4" /> Vote again
        </Link>
      </Button>
      <Button asChild size="lg" variant="success">
        <a href={whatsappShareUrl(text)} target="_blank" rel="noopener noreferrer">
          <Share2 className="h-4 w-4" /> Share on WhatsApp
        </a>
      </Button>
      <Button size="lg" variant="outline" className="sm:col-span-2" onClick={() => window.print()} aria-label={`Print receipt ${reference}`}>
        <Printer className="h-4 w-4" /> Print / save as PDF
      </Button>
    </div>
  );
}
