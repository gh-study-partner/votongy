"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ReceiptText } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ReceiptLookup() {
  const router = useRouter();
  const [ref, setRef] = useState("");
  const [error, setError] = useState<string | null>(null);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const clean = ref.trim().toUpperCase();
    if (!/^VTG-[A-Z0-9]+-[A-Z0-9]+$/.test(clean)) {
      setError("Enter a reference like VTG-XXXXXXXX-XXXXXXXXXX.");
      return;
    }
    setError(null);
    router.push(`/receipt/${encodeURIComponent(clean)}`);
  }

  return (
    <form onSubmit={submit} className="w-full" noValidate>
      <div className="flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <ReceiptText className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            value={ref}
            onChange={(e) => setRef(e.target.value)}
            placeholder="Paste your receipt reference (VTG-...)"
            aria-label="Receipt reference"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            className="h-12 w-full rounded-xl border border-zinc-700 bg-zinc-950 pl-9 pr-3 text-base text-white placeholder:text-zinc-500 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <Button type="submit" size="lg" variant="secondary">
          Verify vote
        </Button>
      </div>
      {error && (
        <p role="alert" className="mt-2 text-sm text-red-400">
          {error}
        </p>
      )}
    </form>
  );
}
