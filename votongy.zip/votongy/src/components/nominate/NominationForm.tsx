"use client";

import { useState } from "react";
import Link from "next/link";
import { AlertCircle, CheckCircle2, ImagePlus, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldHint, Input, Label, Select, Textarea } from "@/components/ui/input";
import { resizeImage, validateImage } from "@/lib/upload";
import type { PublicCategory } from "@/types/database";

export function NominationForm({
  eventId,
  eventSlug,
  categories,
}: {
  eventId: string;
  eventSlug: string;
  categories: PublicCategory[];
}) {
  const [categoryId, setCategoryId] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [bio, setBio] = useState("");
  const [website, setWebsite] = useState(""); // honeypot
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function onPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const problem = validateImage(file);
    if (problem) {
      setError(problem);
      e.target.value = "";
      return;
    }
    setError(null);
    const resized = await resizeImage(file);
    setPhoto(resized);
    setPreview(URL.createObjectURL(resized));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!categoryId) return setError("Choose a category.");
    if (name.trim().length < 2) return setError("Enter the nominee's full name.");

    const body = new FormData();
    body.set("eventId", eventId);
    body.set("categoryId", categoryId);
    body.set("name", name);
    body.set("email", email);
    body.set("phone", phone);
    body.set("bio", bio);
    body.set("website", website);
    if (photo) body.set("photo", photo);

    setBusy(true);
    try {
      const res = await fetch("/api/nominate", { method: "POST", body });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? "Something went wrong. Please try again.");
        return;
      }
      setDone(true);
    } catch {
      setError("Network problem. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 px-6 py-12 text-center">
        <CheckCircle2 className="h-10 w-10 text-emerald-400" />
        <h2 className="font-display text-xl font-bold">Nomination received</h2>
        <p className="max-w-sm text-sm text-zinc-300">
          The organizer will review it. If approved, the nominee will appear on the voting page with their own code.
        </p>
        <div className="mt-2 flex gap-2">
          <Button onClick={() => window.location.reload()} variant="secondary">
            Nominate another
          </Button>
          <Button asChild>
            <Link href={`/e/${eventSlug}`}>Back to event</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      <div>
        <Label htmlFor="nom-category">Category</Label>
        <Select id="nom-category" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
          <option value="">Select a category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </Select>
      </div>

      <div>
        <Label htmlFor="nom-name">Nominee&apos;s full name</Label>
        <Input id="nom-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Kwame Asante" maxLength={80} />
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <Label htmlFor="nom-email">
            Contact email <span className="text-zinc-500">(optional)</span>
          </Label>
          <Input id="nom-email" type="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="nom-phone">
            Contact phone <span className="text-zinc-500">(optional)</span>
          </Label>
          <Input id="nom-phone" type="tel" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="024 123 4567" />
        </div>
      </div>

      <div>
        <Label htmlFor="nom-bio">
          Short bio <span className="text-zinc-500">(why they deserve it)</span>
        </Label>
        <Textarea id="nom-bio" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={600} />
        <FieldHint>{bio.length}/600</FieldHint>
      </div>

      <div>
        <Label>Photo</Label>
        {preview ? (
          <div className="relative inline-block">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={preview} alt="Nominee preview" className="h-32 w-32 rounded-2xl object-cover" />
            <button
              type="button"
              onClick={() => {
                setPhoto(null);
                setPreview(null);
              }}
              aria-label="Remove photo"
              className="absolute -right-2 -top-2 rounded-full bg-zinc-800 p-1.5 text-zinc-200 shadow hover:bg-zinc-700"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <label className="flex h-32 w-full cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-zinc-700 bg-zinc-950 text-sm text-zinc-400 transition-colors hover:border-primary hover:text-primary">
            <ImagePlus className="h-6 w-6" />
            Tap to add a clear face photo (JPG, PNG, WebP)
            <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={onPhoto} />
          </label>
        )}
      </div>

      {/* Honeypot: hidden from humans, bots fill it */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden>
        <label>
          Website
          <input tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} />
        </label>
      </div>

      {error && (
        <p role="alert" className="flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          {error}
        </p>
      )}

      <Button type="submit" size="lg" className="w-full" disabled={busy}>
        {busy ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" /> Submitting...
          </>
        ) : (
          "Submit nomination"
        )}
      </Button>
      <p className="text-center text-xs text-zinc-500">
        Nominations are reviewed by the event organizer. Submitting does not guarantee a place on the ballot.
      </p>
    </form>
  );
}
