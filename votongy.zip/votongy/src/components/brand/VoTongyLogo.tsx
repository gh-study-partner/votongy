import { cn } from "@/lib/utils";
import {
  LOGO_BG_RADIUS,
  LOGO_CHECK_PATH,
  LOGO_CROWN_PATH,
  LOGO_GRADIENT,
  LOGO_INK,
} from "./logo-paths";

interface MarkProps {
  size?: number;
  className?: string;
}

/** The VoTongy mark: a crown (winner) resting on a ballot checkmark, on an amber tile. */
export function VoTongyMark({ size = 36, className }: MarkProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label="VoTongy"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="vtg-mark-gradient" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={LOGO_GRADIENT[0]} />
          <stop offset="1" stopColor={LOGO_GRADIENT[1]} />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx={LOGO_BG_RADIUS} fill="url(#vtg-mark-gradient)" />
      <path d={LOGO_CROWN_PATH} fill={LOGO_INK} strokeLinejoin="round" stroke={LOGO_INK} strokeWidth="2" />
      <path
        d={LOGO_CHECK_PATH}
        fill="none"
        stroke={LOGO_INK}
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

interface LogoProps {
  size?: number;
  showWordmark?: boolean;
  className?: string;
  wordmarkClassName?: string;
}

/** Mark + bold wordmark: "Vo" in white, "Tongy" in gold. */
export function VoTongyLogo({
  size = 34,
  showWordmark = true,
  className,
  wordmarkClassName,
}: LogoProps) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <VoTongyMark size={size} />
      {showWordmark && (
        <span
          className={cn(
            "font-display font-extrabold leading-none tracking-tight text-white",
            wordmarkClassName,
          )}
          style={{ fontSize: Math.round(size * 0.62) }}
        >
          Vo<span className="text-primary">Tongy</span>
        </span>
      )}
    </span>
  );
}
