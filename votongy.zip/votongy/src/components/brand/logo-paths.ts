// Shared geometry for the VoTongy mark (viewBox 0 0 64 64).
// Used by the <VoTongyLogo /> SVG component, the favicon/app-icon SVGs and the flyer canvas.
export const LOGO_VIEWBOX = 64;
export const LOGO_BG_RADIUS = 16;
export const LOGO_CROWN_PATH = "M14 36 L10 17 L22 26 L32 11 L42 26 L54 17 L50 36 Z";
export const LOGO_CHECK_PATH = "M20 47 L28 55 L44 41";
export const LOGO_GRADIENT = ["#FBBF24", "#D97706"] as const;
export const LOGO_INK = "#09090B";
