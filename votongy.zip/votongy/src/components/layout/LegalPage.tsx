import { PublicShell } from "./PublicShell";
import { siteConfig } from "@/config/site";

export function LegalPage({
  title,
  intro,
  children,
}: {
  title: string;
  intro?: string;
  children: React.ReactNode;
}) {
  return (
    <PublicShell>
      <div className="container max-w-3xl py-10 sm:py-14">
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">Legal</p>
        <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">{title}</h1>
        <p className="mt-2 text-sm text-zinc-500">Last updated: {siteConfig.legalUpdated}</p>
        {intro && <p className="mt-5 text-zinc-300">{intro}</p>}
        <div className="mt-8 space-y-8">{children}</div>
        <p className="mt-12 rounded-xl border border-zinc-800 bg-zinc-900 p-4 text-sm text-zinc-400">
          Questions? Contact us at{" "}
          <a className="font-semibold text-primary hover:underline" href={`mailto:${siteConfig.supportEmail}`}>
            {siteConfig.supportEmail}
          </a>
          .
        </p>
      </div>
    </PublicShell>
  );
}

export function LegalSection({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="mb-3 font-display text-xl font-bold">
        {n}. {title}
      </h2>
      <div className="space-y-3 text-[15px] leading-relaxed text-zinc-300 [&_li]:ml-5 [&_li]:list-disc [&_strong]:text-white [&_ul]:space-y-1.5">
        {children}
      </div>
    </section>
  );
}
