import Link from "next/link";
import { ShieldCheck } from "lucide-react";
import { VoTongyLogo } from "@/components/brand/VoTongyLogo";
import { siteConfig } from "@/config/site";

export function SiteFooter() {
  return (
    <footer className="border-t border-zinc-800 bg-zinc-950">
      <div className="container grid gap-8 py-10 md:grid-cols-[1.4fr_1fr_1fr]">
        <div className="space-y-3">
          <VoTongyLogo size={30} />
          <p className="max-w-xs text-sm text-zinc-400">{siteConfig.description}</p>
          <p className="flex items-center gap-1.5 text-xs text-emerald-400">
            <ShieldCheck className="h-4 w-4" /> Payments secured by Paystack
          </p>
        </div>

        <div>
          <h4 className="mb-3 text-sm font-semibold text-zinc-200">Platform</h4>
          <ul className="space-y-2 text-sm text-zinc-400">
            <li>
              <Link href="/#events" className="hover:text-white">
                Browse events
              </Link>
            </li>
            <li>
              <Link href="/#verify" className="hover:text-white">
                Verify a receipt
              </Link>
            </li>
            <li>
              <Link href="/faq" className="hover:text-white">
                FAQ &amp; app install
              </Link>
            </li>
            <li>
              <Link href="/login" className="hover:text-white">
                Organizer &amp; nominee login
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="mb-3 text-sm font-semibold text-zinc-200">Legal &amp; support</h4>
          <ul className="space-y-2 text-sm text-zinc-400">
            <li>
              <Link href="/terms" className="hover:text-white">
                Terms &amp; Conditions
              </Link>
            </li>
            <li>
              <Link href="/privacy" className="hover:text-white">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link href="/refund-policy" className="hover:text-white">
                Refund Policy
              </Link>
            </li>
            <li>
              <a href={`mailto:${siteConfig.supportEmail}`} className="hover:text-white">
                {siteConfig.supportEmail}
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-zinc-900">
        <div className="container flex flex-col items-center justify-between gap-2 py-4 text-xs text-zinc-500 sm:flex-row">
          <p>
            &copy; {new Date().getFullYear()} {siteConfig.legalName}. All rights reserved.
          </p>
          <p>Made in Ghana {"\u{1F1EC}\u{1F1ED}"}</p>
        </div>
      </div>
    </footer>
  );
}
