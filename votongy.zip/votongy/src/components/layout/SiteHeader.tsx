import Link from "next/link";
import { LogIn } from "lucide-react";
import { VoTongyLogo } from "@/components/brand/VoTongyLogo";
import { InstallAppPrompt } from "@/components/pwa/InstallAppPrompt";
import { Button } from "@/components/ui/button";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur-xl">
      <div className="container flex h-14 items-center justify-between gap-3">
        <Link href="/" aria-label="VoTongy home" className="shrink-0">
          <VoTongyLogo size={30} />
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-zinc-400 md:flex" aria-label="Main">
          <Link href="/#events" className="transition-colors hover:text-white">
            Events
          </Link>
          <Link href="/#verify" className="transition-colors hover:text-white">
            Verify receipt
          </Link>
          <Link href="/faq" className="transition-colors hover:text-white">
            FAQ
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <InstallAppPrompt variant="button" size="sm" />
          <Button asChild variant="outline" size="sm">
            <Link href="/login">
              <LogIn className="h-3.5 w-3.5" />
              Log in
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
