"use client";

import { useState } from "react";
import { AlertCircle, CheckCircle2, KeyRound, Mail, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { createClient } from "@/lib/supabase/client";
import { loginSchema, registerSchema, firstError } from "@/lib/validation";
import { cn } from "@/lib/utils";

type Mode = "password" | "magic" | "register";

const MODES: { id: Mode; label: string; icon: React.ReactNode }[] = [
  { id: "password", label: "Password", icon: <KeyRound className="h-4 w-4" /> },
  { id: "magic", label: "Magic link", icon: <Mail className="h-4 w-4" /> },
  { id: "register", label: "Organizer sign-up", icon: <UserPlus className="h-4 w-4" /> },
];

export function LoginForm({ next, initialError }: { next?: string; initialError?: string }) {
  const [mode, setMode] = useState<Mode>("password");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(initialError ?? null);
  const [success, setSuccess] = useState<string | null>(null);

  const callbackUrl = () =>
    `${window.location.origin}/auth/callback${next ? `?next=${encodeURIComponent(next)}` : ""}`;

  const switchMode = (m: Mode) => {
    setMode(m);
    setError(null);
    setSuccess(null);
  };

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    const supabase = createClient();

    try {
      setBusy(true);

      if (mode === "password") {
        const parsed = loginSchema.safeParse({ email, password });
        if (!parsed.success) return setError(firstError(parsed.error));
        const { error: err } = await supabase.auth.signInWithPassword(parsed.data);
        if (err) return setError("Incorrect email or password.");
        // Middleware sends signed-in users from /login to their role dashboard.
        window.location.assign(`/login${next ? `?next=${encodeURIComponent(next)}` : ""}`);
        return;
      }

      if (mode === "magic") {
        const trimmed = email.trim();
        if (!/^\S+@\S+\.\S+$/.test(trimmed)) return setError("Enter a valid email address.");
        const { error: err } = await supabase.auth.signInWithOtp({
          email: trimmed,
          options: { shouldCreateUser: false, emailRedirectTo: callbackUrl() },
        });
        // Don't reveal whether the email exists.
        if (err && !/signups? not allowed|not found/i.test(err.message)) return setError(err.message);
        setSuccess("If that email is registered, we've sent you a sign-in link. Check your inbox (and spam).");
        return;
      }

      const parsed = registerSchema.safeParse({ email, password, fullName });
      if (!parsed.success) return setError(firstError(parsed.error));
      const { error: err } = await supabase.auth.signUp({
        email: parsed.data.email,
        password: parsed.data.password,
        options: { data: { full_name: parsed.data.fullName }, emailRedirectTo: callbackUrl() },
      });
      if (err) return setError(err.message);
      setSuccess(
        "Account created. Confirm your email, then log in. A VoTongy admin must approve your organizer account before you can publish events.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="w-full">
      <div className="mb-5 grid grid-cols-3 gap-1 rounded-xl bg-zinc-950 p-1" role="tablist">
        {MODES.map((m) => (
          <button
            key={m.id}
            role="tab"
            aria-selected={mode === m.id}
            onClick={() => switchMode(m.id)}
            type="button"
            className={cn(
              "flex items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-xs font-semibold transition-colors",
              mode === m.id ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300",
            )}
          >
            {m.icon}
            <span className="truncate">{m.label}</span>
          </button>
        ))}
      </div>

      <form onSubmit={onSubmit} className="space-y-4" noValidate>
        {mode === "register" && (
          <div>
            <Label htmlFor="fullName">Full name</Label>
            <Input
              id="fullName"
              autoComplete="name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Ama Mensah"
            />
          </div>
        )}

        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            inputMode="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
        </div>

        {mode !== "magic" && (
          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              autoComplete={mode === "register" ? "new-password" : "current-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={mode === "register" ? "At least 8 characters" : "Your password"}
            />
          </div>
        )}

        {error && (
          <p role="alert" className="flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </p>
        )}
        {success && (
          <p role="status" className="flex items-start gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-300">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            {success}
          </p>
        )}

        <Button type="submit" size="lg" className="w-full" disabled={busy}>
          {busy
            ? "Please wait..."
            : mode === "password"
              ? "Log in"
              : mode === "magic"
                ? "Email me a sign-in link"
                : "Create organizer account"}
        </Button>
      </form>

      <p className="mt-5 text-center text-xs text-zinc-500">
        {mode === "magic"
          ? "Nominees: use the email your organizer invited you with."
          : mode === "register"
            ? "Super Admin accounts are created by the platform owner and cannot be registered here."
            : "Nominee? Switch to Magic link and use the email you were invited with."}
      </p>
    </div>
  );
}
