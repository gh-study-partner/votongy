"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Ban, CheckCircle2, ImagePlus, Loader2, Mail, Trash2, UserPlus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldHint, Input, Label, Select, Textarea } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/badge";
import { Avatar } from "@/components/voting/Avatar";
import { CopyButton } from "@/components/dashboard/CopyButton";
import { uploadMedia } from "@/lib/upload";
import { eventVoteUrl, formatNumber } from "@/lib/utils";
import { addNominee, deleteNominee, resendInvite, setNomineeStatus } from "@/app/organizer/actions";

export interface ManagedNominee {
  id: string;
  name: string;
  code: string | null;
  email: string | null;
  photo_url: string | null;
  total_votes: number;
  status: string;
  category_id: string;
  linked: boolean;
}

export function NomineeManager({
  eventId,
  eventSlug,
  categories,
  nominees,
}: {
  eventId: string;
  eventSlug: string;
  categories: { id: string; name: string }[];
  nominees: ManagedNominee[];
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [categoryId, setCategoryId] = useState(categories[0]?.id ?? "");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [bio, setBio] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [rowBusy, setRowBusy] = useState<string | null>(null);

  const categoryName = new Map(categories.map((c) => [c.id, c.name]));

  async function onPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      setPhotoUrl(await uploadMedia(file, "nominees"));
    } catch (err) {
      setMsg({ ok: false, text: err instanceof Error ? err.message : "Upload failed." });
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (!categoryId) return setMsg({ ok: false, text: "Choose a category first." });
    setBusy(true);
    const res = await addNominee({ eventId, categoryId, name, email, bio, photoUrl });
    setBusy(false);
    if (!res.ok) return setMsg({ ok: false, text: res.error ?? "Failed." });
    setMsg({ ok: true, text: res.message ?? "Nominee added." });
    setName("");
    setEmail("");
    setBio("");
    setPhotoUrl("");
    router.refresh();
  }

  async function rowAction(id: string, fn: () => Promise<{ ok: boolean; error?: string; message?: string }>) {
    setRowBusy(id);
    setMsg(null);
    const res = await fn();
    setRowBusy(null);
    setMsg({ ok: res.ok, text: res.ok ? res.message ?? "Done." : res.error ?? "Failed." });
    if (res.ok) router.refresh();
  }

  return (
    <div className="space-y-5">
      {!open ? (
        <Button onClick={() => setOpen(true)} disabled={categories.length === 0}>
          <UserPlus className="h-4 w-4" /> Add nominee
        </Button>
      ) : (
        <form onSubmit={add} className="space-y-4 rounded-2xl border border-zinc-800 bg-zinc-950 p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-bold">New nominee</h3>
            <Button type="button" variant="ghost" size="icon" onClick={() => setOpen(false)} aria-label="Close form">
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="n-name">Full name</Label>
              <Input id="n-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} required />
            </div>
            <div>
              <Label htmlFor="n-cat">Category</Label>
              <Select id="n-cat" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="n-email">
              Email <span className="text-zinc-500">(optional: sends a dashboard invitation)</span>
            </Label>
            <Input id="n-email" type="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <FieldHint>The nominee gets a magic-link email to see their rank, share their link and download a promo flyer.</FieldHint>
          </div>
          <div>
            <Label htmlFor="n-bio">Bio</Label>
            <Textarea id="n-bio" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={600} className="min-h-[72px]" />
          </div>
          <div>
            <Label>Photo</Label>
            <div className="flex items-center gap-3">
              <div className="h-16 w-16 overflow-hidden rounded-xl bg-zinc-800">
                {photoUrl ? <Avatar src={photoUrl} name={name || "Nominee"} rounded="rounded-xl" /> : <div className="flex h-full items-center justify-center text-zinc-600"><ImagePlus className="h-5 w-5" /></div>}
              </div>
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-zinc-700 px-3 py-2 text-sm font-semibold hover:bg-zinc-800">
                {uploading && <Loader2 className="h-4 w-4 animate-spin" />}
                {photoUrl ? "Replace" : "Upload"} photo
                <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={onPhoto} disabled={uploading} />
              </label>
            </div>
          </div>
          <Button type="submit" disabled={busy || uploading}>
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Add nominee
          </Button>
        </form>
      )}

      {categories.length === 0 && <p className="text-sm text-amber-300">Add a category above before adding nominees.</p>}
      {msg && <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-emerald-400" : "text-red-400"}`}>{msg.text}</p>}

      {nominees.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-zinc-800 px-4 py-8 text-center text-sm text-zinc-500">No nominees yet.</p>
      ) : (
        <ul className="divide-y divide-zinc-800 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900">
          {nominees.map((n) => (
            <li key={n.id} className="flex flex-wrap items-center gap-3 p-3 sm:p-4">
              <div className="h-12 w-12 shrink-0 overflow-hidden rounded-xl bg-zinc-800">
                <Avatar src={n.photo_url} name={n.name} rounded="rounded-xl" className="text-base" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">
                  {n.name} <span className="text-xs font-normal text-primary">{n.code}</span>
                </p>
                <p className="truncate text-xs text-zinc-500">
                  {categoryName.get(n.category_id) ?? "-"} · {formatNumber(n.total_votes)} votes
                  {n.email ? ` · ${n.email}${n.linked ? " (login linked)" : ""}` : ""}
                </p>
              </div>
              <StatusBadge status={n.status} />
              <div className="flex items-center gap-1">
                {n.code && <CopyButton value={eventVoteUrl(eventSlug, n.code)} label="Link" size="sm" />}
                {n.email && (
                  <Button variant="ghost" size="icon" title="Send / resend login invitation" aria-label="Send invitation" disabled={rowBusy === n.id} onClick={() => rowAction(n.id, () => resendInvite(eventId, n.id))}>
                    <Mail className="h-4 w-4" />
                  </Button>
                )}
                {n.status === "APPROVED" ? (
                  <Button variant="ghost" size="icon" title="Hide from ballot" aria-label="Reject nominee" disabled={rowBusy === n.id} onClick={() => rowAction(n.id, () => setNomineeStatus(eventId, n.id, "REJECTED"))}>
                    <Ban className="h-4 w-4" />
                  </Button>
                ) : (
                  <Button variant="ghost" size="icon" title="Show on ballot" aria-label="Approve nominee" disabled={rowBusy === n.id} onClick={() => rowAction(n.id, () => setNomineeStatus(eventId, n.id, "APPROVED"))}>
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={`Delete ${n.name}`}
                  disabled={rowBusy === n.id}
                  onClick={() => {
                    if (window.confirm(`Delete ${n.name}? This can't be undone.`)) rowAction(n.id, () => deleteNominee(eventId, n.id));
                  }}
                >
                  <Trash2 className="h-4 w-4 text-zinc-500" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
