"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, ArrowLeft, ArrowRight, Check, ImagePlus, Loader2, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldHint, Input, Label, Textarea } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { uploadMedia } from "@/lib/upload";
import { cn, slugify } from "@/lib/utils";
import { siteConfig } from "@/config/site";
import { createEvent } from "@/app/organizer/actions";

const STEPS = ["Basics", "Pricing & rules", "Categories & launch"];

function toLocalInput(d: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function EventWizard({ canPublish }: { canPublish: boolean }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [slugTouched, setSlugTouched] = useState(false);
  const [description, setDescription] = useState("");
  const [bannerUrl, setBannerUrl] = useState("");

  const [costPerVote, setCostPerVote] = useState("1.00");
  const [startAt, setStartAt] = useState(() => toLocalInput(new Date(Date.now() + 3600_000)));
  const [endAt, setEndAt] = useState(() => toLocalInput(new Date(Date.now() + 30 * 86400_000)));
  const [showLiveVotes, setShowLiveVotes] = useState(true);
  const [allowNominations, setAllowNominations] = useState(false);

  const [categories, setCategories] = useState<string[]>([]);
  const [catInput, setCatInput] = useState("");

  function validateStep(s: number): string | null {
    if (s === 0) {
      if (title.trim().length < 3) return "Give your event a title (at least 3 characters).";
      if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug) || slug.length < 3) return "Use a URL with lowercase letters, numbers and dashes (min 3 characters).";
    }
    if (s === 1) {
      const cost = Number(costPerVote);
      if (!Number.isFinite(cost) || cost < 0.1) return "Cost per vote must be at least GHS 0.10.";
      if (!startAt || !endAt) return "Choose start and end dates.";
      if (new Date(endAt).getTime() <= new Date(startAt).getTime()) return "The end date must be after the start date.";
    }
    return null;
  }

  function next() {
    const problem = validateStep(step);
    if (problem) return setError(problem);
    setError(null);
    setStep((s) => Math.min(2, s + 1));
  }

  function addCategory() {
    const name = catInput.trim();
    if (name.length < 2) return;
    if (categories.some((c) => c.toLowerCase() === name.toLowerCase())) return setCatInput("");
    setCategories((c) => [...c, name]);
    setCatInput("");
  }

  async function onBanner(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      setBannerUrl(await uploadMedia(file, "banners"));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function submit(submitForApproval: boolean) {
    for (const s of [0, 1]) {
      const problem = validateStep(s);
      if (problem) {
        setStep(s);
        return setError(problem);
      }
    }
    setError(null);
    setBusy(true);
    const res = await createEvent({
      title,
      slug,
      description,
      bannerUrl,
      costPerVote: Number(costPerVote),
      startAt: new Date(startAt).toISOString(),
      endAt: new Date(endAt).toISOString(),
      showLiveVotes,
      allowPublicNominations: allowNominations,
      categories,
      submit: submitForApproval,
    });
    setBusy(false);
    if (!res.ok || !res.id) return setError(res.error ?? "Could not create the event.");
    router.push(`/organizer/events/${res.id}`);
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-2xl">
      {/* Stepper */}
      <ol className="mb-8 flex items-center gap-2" aria-label="Progress">
        {STEPS.map((label, i) => (
          <li key={label} className="flex flex-1 items-center gap-2">
            <span
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-bold",
                i < step ? "bg-emerald-500 text-white" : i === step ? "bg-primary text-zinc-950" : "bg-zinc-800 text-zinc-400",
              )}
            >
              {i < step ? <Check className="h-4 w-4" /> : i + 1}
            </span>
            <span className={cn("hidden text-sm font-medium sm:block", i === step ? "text-white" : "text-zinc-500")}>{label}</span>
            {i < STEPS.length - 1 && <span className="h-px flex-1 bg-zinc-800" />}
          </li>
        ))}
      </ol>

      <div className="rounded-3xl border border-zinc-800 bg-zinc-900 p-5 sm:p-7">
        {step === 0 && (
          <div className="space-y-5">
            <div>
              <Label htmlFor="w-title">Event title</Label>
              <Input
                id="w-title"
                value={title}
                maxLength={120}
                onChange={(e) => {
                  setTitle(e.target.value);
                  if (!slugTouched) setSlug(slugify(e.target.value));
                }}
                placeholder="Ghana Campus Awards 2026"
              />
            </div>
            <div>
              <Label htmlFor="w-slug">Voting page URL</Label>
              <div className="flex items-center rounded-lg border border-zinc-700 bg-zinc-900 focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/30">
                <span className="select-none pl-3 text-sm text-zinc-500">{siteConfig.url.replace(/^https?:\/\//, "")}/e/</span>
                <input
                  id="w-slug"
                  value={slug}
                  onChange={(e) => {
                    setSlugTouched(true);
                    setSlug(slugify(e.target.value));
                  }}
                  className="h-11 min-w-0 flex-1 bg-transparent px-1 text-base text-white outline-none"
                  aria-label="URL slug"
                />
              </div>
              <FieldHint>This is the link voters will share on WhatsApp.</FieldHint>
            </div>
            <div>
              <Label htmlFor="w-desc">Description</Label>
              <Textarea id="w-desc" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={2000} placeholder="What is this event about? Rules, prizes, how winners are chosen." />
            </div>
            <div>
              <Label>Banner image</Label>
              {bannerUrl ? (
                <div className="relative overflow-hidden rounded-2xl">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={bannerUrl} alt="Banner preview" className="aspect-[16/7] w-full object-cover" />
                  <button type="button" onClick={() => setBannerUrl("")} aria-label="Remove banner" className="absolute right-2 top-2 rounded-full bg-zinc-950/80 p-1.5 hover:bg-zinc-800">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <label className="flex h-32 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-zinc-700 bg-zinc-950 text-sm text-zinc-400 transition-colors hover:border-primary hover:text-primary">
                  {uploading ? <Loader2 className="h-6 w-6 animate-spin" /> : <ImagePlus className="h-6 w-6" />}
                  {uploading ? "Uploading..." : "Tap to upload a wide banner (optional)"}
                  <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={onBanner} disabled={uploading} />
                </label>
              )}
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-5">
            <div>
              <Label htmlFor="w-cost">Cost per vote (GHS)</Label>
              <Input id="w-cost" type="number" inputMode="decimal" min="0.1" step="0.1" value={costPerVote} onChange={(e) => setCostPerVote(e.target.value)} />
              <FieldHint>Voters can buy bundles of 5, 20, 50, 100 or any custom number at this price.</FieldHint>
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <Label htmlFor="w-start">Voting opens</Label>
                <Input id="w-start" type="datetime-local" value={startAt} onChange={(e) => setStartAt(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="w-end">Voting closes</Label>
                <Input id="w-end" type="datetime-local" value={endAt} onChange={(e) => setEndAt(e.target.value)} />
              </div>
            </div>
            <FieldHint>Times use your device&apos;s time zone.</FieldHint>

            <div className="divide-y divide-zinc-800 rounded-2xl border border-zinc-800 bg-zinc-950">
              <div className="flex items-start justify-between gap-4 p-4">
                <div>
                  <Label htmlFor="w-live" className="mb-0.5">Show live vote counts</Label>
                  <p className="text-sm text-zinc-500">Voters see progress bars and totals while voting runs. Turn off to reveal results only at the end.</p>
                </div>
                <Switch id="w-live" checked={showLiveVotes} onCheckedChange={setShowLiveVotes} />
              </div>
              <div className="flex items-start justify-between gap-4 p-4">
                <div>
                  <Label htmlFor="w-nom" className="mb-0.5">Allow public nominations</Label>
                  <p className="text-sm text-zinc-500">Anyone can submit a nominee through a public form. You approve each one before it goes live.</p>
                </div>
                <Switch id="w-nom" checked={allowNominations} onCheckedChange={setAllowNominations} />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <Label htmlFor="w-cat">Categories</Label>
              <div className="flex gap-2">
                <Input
                  id="w-cat"
                  value={catInput}
                  onChange={(e) => setCatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addCategory();
                    }
                  }}
                  placeholder="e.g. Artiste of the Year"
                  maxLength={80}
                />
                <Button type="button" variant="secondary" onClick={addCategory} aria-label="Add category">
                  <Plus className="h-4 w-4" /> Add
                </Button>
              </div>
              {categories.length > 0 ? (
                <ul className="mt-3 flex flex-wrap gap-2">
                  {categories.map((c) => (
                    <li key={c} className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-950 py-1 pl-3 pr-1.5 text-sm">
                      {c}
                      <button type="button" onClick={() => setCategories((list) => list.filter((x) => x !== c))} aria-label={`Remove ${c}`} className="rounded-full p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              ) : (
                <FieldHint>You can also add categories later from the event page.</FieldHint>
              )}
            </div>

            <dl className="space-y-2 rounded-2xl bg-zinc-950 p-4 text-sm">
              <div className="flex justify-between gap-4"><dt className="text-zinc-500">Title</dt><dd className="text-right font-semibold">{title}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-zinc-500">Link</dt><dd className="break-all text-right font-semibold">/e/{slug}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-zinc-500">Price</dt><dd className="font-semibold">GHS {Number(costPerVote).toFixed(2)} / vote</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-zinc-500">Live counts</dt><dd className="font-semibold">{showLiveVotes ? "Visible" : "Hidden until end"}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-zinc-500">Public nominations</dt><dd className="font-semibold">{allowNominations ? "On" : "Off"}</dd></div>
            </dl>

            {!canPublish && (
              <p className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-200">
                Your organizer account isn&apos;t approved yet, so events can&apos;t be created.
              </p>
            )}
          </div>
        )}

        {error && (
          <p role="alert" className="mt-5 flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </p>
        )}

        <div className="mt-7 flex flex-col-reverse gap-3 sm:flex-row sm:justify-between">
          <Button type="button" variant="ghost" disabled={step === 0 || busy} onClick={() => { setError(null); setStep((s) => Math.max(0, s - 1)); }}>
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          {step < 2 ? (
            <Button type="button" onClick={next} size="lg">
              Continue <ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button type="button" variant="outline" size="lg" disabled={busy || !canPublish} onClick={() => submit(false)}>
                Save as draft
              </Button>
              <Button type="button" size="lg" disabled={busy || !canPublish} onClick={() => submit(true)}>
                {busy && <Loader2 className="h-4 w-4 animate-spin" />} Submit for approval
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
