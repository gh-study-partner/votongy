"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Pause, Play, Send, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { changeEventStatus } from "@/app/organizer/actions";

export function StatusControls({ eventId, status }: { eventId: string; status: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function run(next: "PENDING_APPROVAL" | "ACTIVE" | "PAUSED" | "ENDED", confirmText?: string) {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusy(true);
    setMsg(null);
    const res = await changeEventStatus(eventId, next);
    setBusy(false);
    setMsg({ ok: res.ok, text: res.ok ? res.message ?? "Updated." : res.error ?? "Failed." });
    if (res.ok) router.refresh();
  }

  const canSubmit = status === "DRAFT" || status === "REJECTED";

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {canSubmit && (
          <Button onClick={() => run("PENDING_APPROVAL")} disabled={busy}>
            <Send className="h-4 w-4" /> {status === "REJECTED" ? "Resubmit for approval" : "Submit for approval"}
          </Button>
        )}
        {status === "ACTIVE" && (
          <Button variant="outline" onClick={() => run("PAUSED")} disabled={busy}>
            <Pause className="h-4 w-4" /> Pause voting
          </Button>
        )}
        {status === "PAUSED" && (
          <Button variant="success" onClick={() => run("ACTIVE")} disabled={busy}>
            <Play className="h-4 w-4" /> Resume voting
          </Button>
        )}
        {(status === "ACTIVE" || status === "PAUSED") && (
          <Button variant="destructive" onClick={() => run("ENDED", "End this event now? Voting closes immediately and cannot be reopened by you.")} disabled={busy}>
            <Square className="h-4 w-4" /> End event
          </Button>
        )}
        {status === "PENDING_APPROVAL" && <p className="text-sm text-amber-300">Waiting for VoTongy admin approval. You&apos;ll be able to edit nominees meanwhile.</p>}
        {status === "ENDED" && <p className="text-sm text-zinc-400">This event has ended. Download certified results below.</p>}
      </div>
      {msg && (
        <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-emerald-400" : "text-red-400"}`}>
          {msg.text}
        </p>
      )}
    </div>
  );
}
