"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addCategory, deleteCategory } from "@/app/organizer/actions";

export function CategoryManager({
  eventId,
  categories,
}: {
  eventId: string;
  categories: { id: string; name: string; nominees: number }[];
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (name.trim().length < 2) return;
    setBusy(true);
    setError(null);
    const res = await addCategory(eventId, name);
    setBusy(false);
    if (!res.ok) return setError(res.error ?? "Failed.");
    setName("");
    router.refresh();
  }

  async function remove(id: string, label: string) {
    if (!window.confirm(`Delete category "${label}" and all its nominees?`)) return;
    setError(null);
    const res = await deleteCategory(eventId, id);
    if (!res.ok) return setError(res.error ?? "Failed.");
    router.refresh();
  }

  return (
    <div className="space-y-4">
      <form onSubmit={add} className="flex gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="New category name" maxLength={80} aria-label="Category name" />
        <Button type="submit" variant="secondary" disabled={busy}>
          <Plus className="h-4 w-4" /> Add
        </Button>
      </form>
      {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
      {categories.length === 0 ? (
        <p className="text-sm text-zinc-500">No categories yet. Add at least one before adding nominees.</p>
      ) : (
        <ul className="divide-y divide-zinc-800 overflow-hidden rounded-2xl border border-zinc-800">
          {categories.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-3 bg-zinc-950 px-4 py-3">
              <div>
                <p className="text-sm font-semibold">{c.name}</p>
                <p className="text-xs text-zinc-500">{c.nominees} nominee{c.nominees === 1 ? "" : "s"}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => remove(c.id, c.name)} aria-label={`Delete ${c.name}`}>
                <Trash2 className="h-4 w-4 text-zinc-500" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
