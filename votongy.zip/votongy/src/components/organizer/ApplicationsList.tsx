"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/voting/Avatar";
import { formatDate } from "@/lib/utils";
import { reviewApplication } from "@/app/organizer/actions";

export interface PendingApplication {
  id: string;
  applicant_name: string;
  applicant_email: string | null;
  applicant_phone: string | null;
  bio: string | null;
  photo_url: string | null;
  category: string | null;
  created_at: string;
}

export function ApplicationsList({ eventId, applications }: { eventId: string; applications: PendingApplication[] }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function review(id: string, decision: "approve" | "reject") {
    setBusy(id);
    setMsg(null);
    const res = await reviewApplication(eventId, id, decision);
    setBusy(null);
    setMsg({ ok: res.ok, text: res.ok ? res.message ?? "Done." : res.error ?? "Failed." });
    if (res.ok) router.refresh();
  }

  if (applications.length === 0) {
    return <p className="rounded-2xl border border-dashed border-zinc-800 px-4 py-8 text-center text-sm text-zinc-500">No pending nominations.</p>;
  }

  return (
    <div className="space-y-3">
      {msg && <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-emerald-400" : "text-red-400"}`}>{msg.text}</p>}
      <ul className="space-y-3">
        {applications.map((a) => (
          <li key={a.id} className="flex flex-wrap gap-4 rounded-2xl border border-zinc-800 bg-zinc-900 p-4">
            <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-zinc-800">
              <Avatar src={a.photo_url} name={a.applicant_name} rounded="rounded-xl" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold">{a.applicant_name}</p>
              <p className="text-xs text-zinc-500">
                {a.category ?? "No category"} · {formatDate(a.created_at)}
              </p>
              {(a.applicant_email || a.applicant_phone) && (
                <p className="mt-1 text-xs text-zinc-400">{[a.applicant_email, a.applicant_phone].filter(Boolean).join(" · ")}</p>
              )}
              {a.bio && <p className="mt-2 line-clamp-3 text-sm text-zinc-300">{a.bio}</p>}
            </div>
            <div className="flex w-full gap-2 sm:w-auto sm:flex-col">
              <Button size="sm" variant="success" className="flex-1" disabled={busy === a.id} onClick={() => review(a.id, "approve")}>
                {busy === a.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />} Approve
              </Button>
              <Button size="sm" variant="outline" className="flex-1" disabled={busy === a.id} onClick={() => review(a.id, "reject")}>
                <X className="h-3.5 w-3.5" /> Reject
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
