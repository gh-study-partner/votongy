"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldHint, Input, Label, Textarea } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { uploadMedia } from "@/lib/upload";
import { updateEventSettings } from "@/app/organizer/actions";

function toLocalInput(iso: string) {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

interface Props {
  eventId: string;
  initial: {
    title: string;
    description: string | null;
    banner_url: string | null;
    cost_per_vote: number;
    start_at: string;
    end_at: string;
    show_live_votes: boolean;
    allow_public_nominations: boolean;
  };
}

export function EventSettingsForm({ eventId, initial }: Props) {
  const router = useRouter();
  const [title, setTitle] = useState(initial.title);
  const [description, setDescription] = useState(initial.description ?? "");
  const [bannerUrl, setBannerUrl] = useState(initial.banner_url ?? "");
  const [cost, setCost] = useState(String(initial.cost_per_vote));
  const [startAt, setStartAt] = useState(toLocalInput(initial.start_at));
  const [endAt, setEndAt] = useState(toLocalInput(initial.end_at));
  const [live, setLive] = useState(initial.show_live_votes);
  const [noms, setNoms] = useState(initial.allow_public_nominations);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function onBanner(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      setBannerUrl(await uploadMedia(file, "banners"));
    } catch (err) {
      setMsg({ ok: false, text: err instanceof Error ? err.message : "Upload failed." });
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const res = await updateEventSettings(eventId, {
      title,
      description,
      bannerUrl,
      costPerVote: Number(cost),
      startAt: new Date(startAt).toISOString(),
      endAt: new Date(endAt).toISOString(),
      showLiveVotes: live,
      allowPublicNominations: noms,
    });
    setBusy(false);
    setMsg({ ok: res.ok, text: res.ok ? res.message ?? "Saved." : res.error ?? "Failed." });
    if (res.ok) router.refresh();
  }

  return (
    <form onSubmit={save} className="space-y-5">
      <div>
        <Label htmlFor="s-title">Title</Label>
        <Input id="s-title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
      </div>
      <div>
        <Label htmlFor="s-desc">Description</Label>
        <Textarea id="s-desc" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={2000} />
      </div>
      <div className="grid gap-5 sm:grid-cols-3">
        <div>
          <Label htmlFor="s-cost">Cost per vote (GHS)</Label>
          <Input id="s-cost" type="number" step="0.1" min="0.1" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="s-start">Opens</Label>
          <Input id="s-start" type="datetime-local" value={startAt} onChange={(e) => setStartAt(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="s-end">Closes</Label>
          <Input id="s-end" type="datetime-local" value={endAt} onChange={(e) => setEndAt(e.target.value)} />
        </div>
      </div>
      <FieldHint>Changing the price only affects future payments. Times use your device&apos;s time zone.</FieldHint>

      <div>
        <Label htmlFor="s-banner">Banner image</Label>
        <div className="flex flex-wrap items-center gap-3">
          {bannerUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={bannerUrl} alt="Banner" className="h-16 w-32 rounded-lg object-cover" />
          )}
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-zinc-700 px-3 py-2 text-sm font-semibold hover:bg-zinc-800">
            {uploading && <Loader2 className="h-4 w-4 animate-spin" />}
            {bannerUrl ? "Replace" : "Upload"} banner
            <input id="s-banner" type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={onBanner} disabled={uploading} />
          </label>
          {bannerUrl && (
            <Button type="button" variant="ghost" size="sm" onClick={() => setBannerUrl("")}>
              Remove
            </Button>
          )}
        </div>
      </div>

      <div className="divide-y divide-zinc-800 rounded-2xl border border-zinc-800 bg-zinc-950">
        <div className="flex items-center justify-between gap-4 p-4">
          <div>
            <Label htmlFor="s-live" className="mb-0.5">Show live vote counts</Label>
            <p className="text-sm text-zinc-500">When off, totals are hidden from the public until the event ends.</p>
          </div>
          <Switch id="s-live" checked={live} onCheckedChange={setLive} />
        </div>
        <div className="flex items-center justify-between gap-4 p-4">
          <div>
            <Label htmlFor="s-noms" className="mb-0.5">Allow public nominations</Label>
            <p className="text-sm text-zinc-500">Shows a &ldquo;Nominate someone&rdquo; form to the public. You approve each one.</p>
          </div>
          <Switch id="s-noms" checked={noms} onCheckedChange={setNoms} />
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={busy}>
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} Save changes
        </Button>
        {msg && <p role={msg.ok ? "status" : "alert"} className={`text-sm ${msg.ok ? "text-emerald-400" : "text-red-400"}`}>{msg.text}</p>}
      </div>
    </form>
  );
}
