"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  CalendarPlus,
  CheckSquare,
  Gauge,
  Image as ImageIcon,
  LayoutDashboard,
  Receipt,
  Trophy,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

const ICONS: Record<string, LucideIcon> = {
  dashboard: LayoutDashboard,
  gauge: Gauge,
  approvals: CheckSquare,
  transactions: Receipt,
  new: CalendarPlus,
  trophy: Trophy,
  flyer: ImageIcon,
};

export interface NavItem {
  href: string;
  label: string;
  icon: keyof typeof ICONS;
  /** match only the exact path (used for overview tabs) */
  exact?: boolean;
  badge?: number;
}

export function DashboardNav({ items, orientation }: { items: NavItem[]; orientation: "vertical" | "horizontal" }) {
  const pathname = usePathname();
  return (
    <ul className={cn(orientation === "vertical" ? "space-y-1" : "flex items-stretch justify-around gap-1")}>
      {items.map((item) => {
        const Icon = ICONS[item.icon] ?? LayoutDashboard;
        const active = item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`);
        return (
          <li key={item.href} className={orientation === "horizontal" ? "flex-1" : undefined}>
            <Link
              href={item.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative flex items-center rounded-xl text-sm font-medium transition-colors",
                orientation === "vertical" ? "gap-3 px-3 py-2.5" : "flex-col gap-1 px-2 py-1.5 text-[11px]",
                active ? "bg-zinc-800 text-white" : "text-zinc-400 hover:bg-zinc-900 hover:text-white",
              )}
            >
              <Icon className={cn("h-[18px] w-[18px]", active && "text-primary")} />
              {item.label}
              {item.badge ? (
                <span className="ml-auto rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-bold leading-none text-zinc-950 max-lg:absolute max-lg:right-3 max-lg:top-0 max-lg:ml-0">
                  {item.badge}
                </span>
              ) : null}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
