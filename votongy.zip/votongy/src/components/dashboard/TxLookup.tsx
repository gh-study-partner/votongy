"use client";

import { useState } from "react";
import { Loader2, RefreshCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/badge";
import { formatDateTime, formatGHS, formatNumber } from "@/lib/utils";

interface TxResult {
  id: string;
  reference: string;
  voter_phone: string | null;
  voter_email: string | null;
  votes: number;
  amount: number;
  currency: string;
  status: string;
  channel: string;
  failure_reason: string | null;
  paid_at: string | null;
  created_at: string;
  events: { title: string; slug: string } | null;
  nominees: { name: string; code: string } | null;
}

export function TxLookup() {
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<TxResult[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [reconciling, setReconciling] = useState<string | null>(null);

  async function search(e?: React.FormEvent) {
    e?.preventDefault();
    setError(null);
    setNotice(null);
    if (q.trim().length < 3) return setError("Enter at least 3 characters.");
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/tx-lookup?q=${encodeURIComponent(q.trim())}`, { cache: "no-store" });
      const json = (await res.json()) as { results?: TxResult[]; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Search failed");
      setRows(json.results ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Search failed");
    } finally {
      setBusy(false);
    }
  }

  async function reconcile(reference: string) {
    setReconciling(reference);
    setError(null);
    setNotice(null);
    try {
      const res = await fetch("/api/admin/tx-lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reference }),
      });
      const json = (await res.json()) as { message?: string; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Reconcile failed");
      setNotice(json.message ?? "Done.");
      await search();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Reconcile failed");
    } finally {
      setReconciling(null);
    }
  }

  return (
    <div className="space-y-5">
      <form onSubmit={search} className="flex flex-col gap-2 sm:flex-row" noValidate>
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Paystack reference (VTG-...), voter phone (024...) or email"
            className="pl-9"
            aria-label="Search transactions"
          />
        </div>
        <Button type="submit" size="lg" disabled={busy}>
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />} Search
        </Button>
      </form>

      {error && <p role="alert" className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}
      {notice && <p role="status" className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-300">{notice}</p>}

      {rows && rows.length === 0 && (
        <p className="rounded-2xl border border-dashed border-zinc-800 px-4 py-10 text-center text-sm text-zinc-500">No transactions matched.</p>
      )}

      {rows && rows.length > 0 && (
        <ul className="space-y-3">
          {rows.map((t) => (
            <li key={t.id} className="rounded-2xl border border-zinc-800 bg-zinc-900 p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="break-all font-mono text-xs text-zinc-300">{t.reference}</p>
                  <p className="mt-1 text-sm font-semibold">
                    {t.nominees?.name ?? "?"} <span className="text-xs font-normal text-primary">{t.nominees?.code}</span>
                  </p>
                  <p className="text-xs text-zinc-500">{t.events?.title}</p>
                </div>
                <StatusBadge status={t.status} />
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm sm:grid-cols-4">
                <div><dt className="text-xs text-zinc-500">Amount</dt><dd className="font-semibold">{formatGHS(t.amount)}</dd></div>
                <div><dt className="text-xs text-zinc-500">Votes</dt><dd className="font-semibold">{formatNumber(t.votes)}</dd></div>
                <div><dt className="text-xs text-zinc-500">Phone</dt><dd>{t.voter_phone ?? "-"}</dd></div>
                <div><dt className="text-xs text-zinc-500">Channel</dt><dd>{t.channel}</dd></div>
                <div><dt className="text-xs text-zinc-500">Created</dt><dd>{formatDateTime(t.created_at)}</dd></div>
                <div><dt className="text-xs text-zinc-500">Paid</dt><dd>{formatDateTime(t.paid_at)}</dd></div>
                <div className="col-span-2"><dt className="text-xs text-zinc-500">Email</dt><dd className="truncate">{t.voter_email ?? "-"}</dd></div>
              </dl>
              {t.failure_reason && <p className="mt-3 rounded-lg bg-zinc-950 p-2.5 text-xs text-amber-300">{t.failure_reason}</p>}
              {t.status !== "SUCCESS" && (
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-zinc-800 pt-3">
                  <Button size="sm" variant="secondary" disabled={reconciling === t.reference} onClick={() => reconcile(t.reference)}>
                    {reconciling === t.reference ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCcw className="h-3.5 w-3.5" />}
                    Re-check with Paystack
                  </Button>
                  <span className="text-xs text-zinc-500">Credits votes only if Paystack confirms the payment. Cannot double-credit.</span>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
