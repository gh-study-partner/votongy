"use client";

import { useState } from "react";
import { OctagonAlert, Play } from "lucide-react";
import { Button } from "@/components/ui/button";

/** Global emergency kill-switch. Asks for confirmation before pausing all voting. */
export function PauseSwitch({ initialPaused }: { initialPaused: boolean }) {
  const [paused, setPaused] = useState(initialPaused);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function toggle() {
    const next = !paused;
    if (next && !window.confirm("Pause ALL voting on VoTongy right now? Voters will not be able to pay until you resume.")) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/pause", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paused: next }),
      });
      const json = (await res.json().catch(() => ({}))) as { paused?: boolean; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Request failed");
      setPaused(Boolean(json.paused));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className={`rounded-2xl border p-5 ${
        paused ? "border-red-500/40 bg-red-500/10" : "border-zinc-800 bg-zinc-900"
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className={`mt-0.5 flex h-10 w-10 items-center justify-center rounded-xl ${paused ? "bg-red-500/20 text-red-400" : "bg-emerald-500/10 text-emerald-400"}`}>
            <OctagonAlert className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-display text-base font-bold">Emergency pause voting</h2>
            <p className="mt-0.5 max-w-md text-sm text-zinc-400">
              {paused
                ? "ALL voting is currently paused. Voters see a pause message and cannot start payments."
                : "Voting is running normally. Use this kill-switch to instantly stop new payments platform-wide if you detect fraud or an outage."}
            </p>
          </div>
        </div>
        <Button onClick={toggle} disabled={busy} variant={paused ? "success" : "destructive"} size="lg">
          {paused ? (
            <>
              <Play className="h-4 w-4" /> Resume voting
            </>
          ) : (
            <>
              <OctagonAlert className="h-4 w-4" /> Pause all voting
            </>
          )}
        </Button>
      </div>
      {error && <p role="alert" className="mt-3 text-sm text-red-400">{error}</p>}
    </div>
  );
}
