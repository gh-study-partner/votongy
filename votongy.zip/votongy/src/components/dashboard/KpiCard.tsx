import { cn } from "@/lib/utils";

export function KpiCard({
  label,
  value,
  hint,
  icon,
  tone = "default",
}: {
  label: string;
  value: string;
  hint?: string;
  icon?: React.ReactNode;
  tone?: "default" | "gold" | "green";
}) {
  return (
    <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-zinc-400">{label}</p>
        {icon && (
          <span
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-lg",
              tone === "gold" && "bg-primary/10 text-primary",
              tone === "green" && "bg-emerald-500/10 text-emerald-400",
              tone === "default" && "bg-zinc-800 text-zinc-300",
            )}
          >
            {icon}
          </span>
        )}
      </div>
      <p className="mt-3 truncate font-display text-2xl font-extrabold tracking-tight tabular-nums sm:text-3xl">{value}</p>
      {hint && <p className="mt-1 text-xs text-zinc-500">{hint}</p>}
    </div>
  );
}
