import Link from "next/link";
import { LogOut } from "lucide-react";
import { VoTongyLogo } from "@/components/brand/VoTongyLogo";
import { DashboardNav, type NavItem } from "./DashboardNav";
import { Button } from "@/components/ui/button";

export function DashboardShell({
  roleLabel,
  userName,
  email,
  items,
  children,
}: {
  roleLabel: string;
  userName: string;
  email: string;
  items: NavItem[];
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-dvh bg-zinc-950 lg:grid lg:grid-cols-[250px_1fr]">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-dvh flex-col border-r border-zinc-800 bg-zinc-950 p-4 lg:flex">
        <Link href="/" className="mb-8 px-2 pt-2" aria-label="VoTongy home">
          <VoTongyLogo size={32} />
        </Link>
        <p className="mb-2 px-3 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">{roleLabel}</p>
        <DashboardNav items={items} orientation="vertical" />
        <div className="mt-auto space-y-3 rounded-2xl border border-zinc-800 bg-zinc-900 p-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{userName}</p>
            <p className="truncate text-xs text-zinc-500">{email}</p>
          </div>
          <form action="/auth/signout" method="post">
            <Button type="submit" variant="outline" size="sm" className="w-full">
              <LogOut className="h-3.5 w-3.5" /> Sign out
            </Button>
          </form>
        </div>
      </aside>

      <div className="min-w-0 pb-24 lg:pb-0">
        {/* Mobile top bar */}
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-zinc-800 bg-zinc-950/90 px-4 backdrop-blur-xl lg:hidden">
          <Link href="/" aria-label="VoTongy home">
            <VoTongyLogo size={28} />
          </Link>
          <form action="/auth/signout" method="post">
            <Button type="submit" variant="ghost" size="sm" aria-label="Sign out">
              <LogOut className="h-4 w-4" />
            </Button>
          </form>
        </header>

        <main className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:py-10">{children}</main>

        {/* Mobile bottom tabs */}
        <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-zinc-800 bg-zinc-950/95 px-2 pt-2 backdrop-blur-xl lg:hidden" aria-label="Dashboard">
          <DashboardNav items={items} orientation="horizontal" />
        </nav>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-extrabold tracking-tight sm:text-3xl">{title}</h1>
        {description && <p className="mt-1 text-sm text-zinc-400">{description}</p>}
      </div>
      {action}
    </div>
  );
}
