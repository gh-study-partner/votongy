"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Download, Loader2, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/input";
import {
  LOGO_BG_RADIUS,
  LOGO_CHECK_PATH,
  LOGO_CROWN_PATH,
  LOGO_GRADIENT,
  LOGO_INK,
} from "@/components/brand/logo-paths";
import { initials } from "@/lib/utils";

export interface FlyerEntry {
  id: string;
  name: string;
  code: string;
  category: string;
  eventTitle: string;
  photoUrl: string | null;
  /** short, human-readable link printed on the flyer, e.g. votongy.com/e/awards?nominee=N042 */
  displayUrl: string;
  voteUrl: string;
}

const W = 1080;
const H = 1350;
const FONT = '"Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function fitText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number, startSize: number, weight = 800) {
  let size = startSize;
  while (size > 28) {
    ctx.font = `${weight} ${size}px ${FONT}`;
    if (ctx.measureText(text).width <= maxWidth) break;
    size -= 2;
  }
  return size;
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number, maxLines: number) {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = w;
    } else line = test;
  }
  if (line) lines.push(line);
  if (lines.length > maxLines) {
    const kept = lines.slice(0, maxLines);
    kept[maxLines - 1] = kept[maxLines - 1]!.replace(/\s*\S*$/, "") + "…";
    return kept;
  }
  return lines;
}

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function drawLogoMark(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
  const s = size / 64;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  const g = ctx.createLinearGradient(0, 0, 64, 64);
  g.addColorStop(0, LOGO_GRADIENT[0]);
  g.addColorStop(1, LOGO_GRADIENT[1]);
  ctx.fillStyle = g;
  roundRect(ctx, 0, 0, 64, 64, LOGO_BG_RADIUS);
  ctx.fill();
  ctx.fillStyle = LOGO_INK;
  ctx.strokeStyle = LOGO_INK;
  ctx.lineJoin = "round";
  ctx.lineWidth = 2;
  const crown = new Path2D(LOGO_CROWN_PATH);
  ctx.fill(crown);
  ctx.stroke(crown);
  ctx.lineWidth = 5;
  ctx.lineCap = "round";
  ctx.stroke(new Path2D(LOGO_CHECK_PATH));
  ctx.restore();
}

async function render(canvas: HTMLCanvasElement, entry: FlyerEntry) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  canvas.width = W;
  canvas.height = H;
  try {
    await document.fonts?.ready;
  } catch {
    /* ignore */
  }

  // Background
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, "#18181B");
  bg.addColorStop(1, "#09090B");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const glow = ctx.createRadialGradient(W / 2, 520, 40, W / 2, 520, 620);
  glow.addColorStop(0, "rgba(245,158,11,0.30)");
  glow.addColorStop(1, "rgba(245,158,11,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // Subtle grid
  ctx.strokeStyle = "rgba(63,63,70,0.28)";
  ctx.lineWidth = 1;
  for (let x = 0; x <= W; x += 54) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }
  for (let y = 0; y <= H; y += 54) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }

  // Header: logo + wordmark
  drawLogoMark(ctx, 64, 56, 72);
  ctx.textBaseline = "alphabetic";
  ctx.font = `800 46px ${FONT}`;
  ctx.fillStyle = "#FFFFFF";
  ctx.fillText("Vo", 152, 108);
  const voW = ctx.measureText("Vo").width;
  ctx.fillStyle = "#F59E0B";
  ctx.fillText("Tongy", 152 + voW, 108);

  // Event title (top right)
  ctx.textAlign = "right";
  ctx.fillStyle = "#A1A1AA";
  ctx.font = `600 26px ${FONT}`;
  const evLines = wrapLines(ctx, entry.eventTitle.toUpperCase(), 520, 2);
  evLines.forEach((l, i) => ctx.fillText(l, W - 64, 82 + i * 34));
  ctx.textAlign = "left";

  // Photo
  const photoSize = 560;
  const px = (W - photoSize) / 2;
  const py = 190;
  ctx.save();
  ctx.shadowColor = "rgba(245,158,11,0.35)";
  ctx.shadowBlur = 60;
  roundRect(ctx, px - 10, py - 10, photoSize + 20, photoSize + 20, 64);
  const ring = ctx.createLinearGradient(px, py, px + photoSize, py + photoSize);
  ring.addColorStop(0, "#FBBF24");
  ring.addColorStop(1, "#D97706");
  ctx.fillStyle = ring;
  ctx.fill();
  ctx.restore();

  ctx.save();
  roundRect(ctx, px, py, photoSize, photoSize, 54);
  ctx.clip();
  const img = entry.photoUrl ? await loadImage(entry.photoUrl) : null;
  if (img) {
    const scale = Math.max(photoSize / img.width, photoSize / img.height);
    const dw = img.width * scale;
    const dh = img.height * scale;
    ctx.drawImage(img, px + (photoSize - dw) / 2, py + (photoSize - dh) / 2 - dh * 0.04, dw, dh);
  } else {
    const ph = ctx.createLinearGradient(px, py, px + photoSize, py + photoSize);
    ph.addColorStop(0, "#27272A");
    ph.addColorStop(1, "#18181B");
    ctx.fillStyle = ph;
    ctx.fillRect(px, py, photoSize, photoSize);
    ctx.fillStyle = "#F59E0B";
    ctx.font = `800 220px ${FONT}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(initials(entry.name), W / 2, py + photoSize / 2);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
  }
  ctx.restore();

  // Code badge on photo corner
  ctx.font = `800 40px ${FONT}`;
  const codeW = ctx.measureText(entry.code).width + 56;
  const bx = px + photoSize - codeW - 24;
  const by = py + photoSize - 84;
  roundRect(ctx, bx, by, codeW, 64, 32);
  ctx.fillStyle = "#09090B";
  ctx.fill();
  ctx.fillStyle = "#F59E0B";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(entry.code, bx + codeW / 2, by + 34);
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";

  // Name
  ctx.textAlign = "center";
  const nameSize = fitText(ctx, entry.name, W - 140, 84);
  ctx.font = `800 ${nameSize}px ${FONT}`;
  ctx.fillStyle = "#FFFFFF";
  ctx.fillText(entry.name, W / 2, 870);

  // Category pill
  ctx.font = `700 32px ${FONT}`;
  const catText = wrapLines(ctx, entry.category, W - 260, 1)[0] ?? entry.category;
  const catW = ctx.measureText(catText).width + 64;
  roundRect(ctx, (W - catW) / 2, 906, catW, 62, 31);
  ctx.fillStyle = "rgba(245,158,11,0.14)";
  ctx.fill();
  ctx.strokeStyle = "rgba(245,158,11,0.5)";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = "#FBBF24";
  ctx.fillText(catText, W / 2, 949);

  // Call to action
  ctx.fillStyle = "#E4E4E7";
  ctx.font = `600 36px ${FONT}`;
  ctx.fillText("Vote with MoMo or card. It takes a minute.", W / 2, 1050);

  const btnW = 640;
  const btnH = 104;
  const btnX = (W - btnW) / 2;
  roundRect(ctx, btnX, 1090, btnW, btnH, 52);
  const btn = ctx.createLinearGradient(btnX, 1090, btnX + btnW, 1090 + btnH);
  btn.addColorStop(0, "#FBBF24");
  btn.addColorStop(1, "#D97706");
  ctx.fillStyle = btn;
  ctx.fill();
  ctx.fillStyle = "#09090B";
  ctx.font = `800 48px ${FONT}`;
  ctx.fillText(`VOTE ${entry.code} NOW`, W / 2, 1160);

  // Link
  ctx.fillStyle = "#A1A1AA";
  const linkSize = fitText(ctx, entry.displayUrl, W - 120, 32, 600);
  ctx.font = `600 ${linkSize}px ${FONT}`;
  ctx.fillText(entry.displayUrl, W / 2, 1262);
  ctx.fillStyle = "#52525B";
  ctx.font = `500 24px ${FONT}`;
  ctx.fillText("Powered by VoTongy · Secured by Paystack", W / 2, 1306);
  ctx.textAlign = "left";
}

export function FlyerCanvas({ entries }: { entries: FlyerEntry[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [index, setIndex] = useState(0);
  const [rendering, setRendering] = useState(true);
  const [canShare, setCanShare] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const entry = entries[index] ?? entries[0]!;

  useEffect(() => {
    let cancelled = false;
    setRendering(true);
    setError(null);
    const canvas = canvasRef.current;
    if (!canvas) return;
    render(canvas, entry)
      .catch(() => !cancelled && setError("Couldn't draw the flyer. Try again."))
      .finally(() => !cancelled && setRendering(false));
    return () => {
      cancelled = true;
    };
  }, [entry]);

  useEffect(() => {
    setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
  }, []);

  const toBlob = useCallback(
    () =>
      new Promise<Blob | null>((resolve) => {
        try {
          canvasRef.current?.toBlob((b) => resolve(b), "image/png");
        } catch {
          resolve(null);
        }
      }),
    [],
  );

  const fileName = `votongy-${entry.code.toLowerCase()}-flyer.png`;

  async function download() {
    setError(null);
    const blob = await toBlob();
    if (!blob) return setError("Couldn't export the image. If your photo is hosted elsewhere, re-upload it and try again.");
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  async function share() {
    setError(null);
    const blob = await toBlob();
    if (!blob) return setError("Couldn't export the image.");
    const file = new File([blob], fileName, { type: "image/png" });
    try {
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], text: `Vote for ${entry.name} (${entry.code}): ${entry.voteUrl}` });
      } else {
        await navigator.share({ text: `Vote for ${entry.name} (${entry.code})`, url: entry.voteUrl });
      }
    } catch {
      /* cancelled */
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
      <div className="mx-auto w-full max-w-[420px] overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-2xl shadow-black/50">
        <div className="relative">
          <canvas ref={canvasRef} className="block h-auto w-full" role="img" aria-label={`Promo flyer for ${entry.name}`} />
          {rendering && (
            <div className="absolute inset-0 flex items-center justify-center bg-zinc-950/70">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          )}
        </div>
      </div>

      <div className="space-y-5">
        {entries.length > 1 && (
          <div>
            <label htmlFor="flyer-entry" className="mb-1.5 block text-sm font-medium text-zinc-300">Which nomination?</label>
            <Select id="flyer-entry" value={index} onChange={(e) => setIndex(Number(e.target.value))}>
              {entries.map((e, i) => (
                <option key={e.id} value={i}>
                  {e.name} · {e.category} · {e.eventTitle}
                </option>
              ))}
            </Select>
          </div>
        )}
        <div>
          <h2 className="font-display text-lg font-bold">Your promo flyer</h2>
          <p className="mt-1 text-sm text-zinc-400">
            A 1080 × 1350 graphic sized for WhatsApp status, Instagram posts and Facebook. It carries your photo, code and direct voting link.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="lg" onClick={download} disabled={rendering}>
            <Download className="h-4 w-4" /> Download PNG
          </Button>
          {canShare && (
            <Button size="lg" variant="success" onClick={share} disabled={rendering}>
              <Share2 className="h-4 w-4" /> Share
            </Button>
          )}
        </div>
        {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-zinc-400">
          <li>Post it with a caption like &ldquo;Vote {entry.code} for {entry.name}!&rdquo; and paste your link.</li>
          <li>No photo showing? Ask your organizer to upload one. A clear, well-lit face photo works best.</li>
        </ul>
      </div>
    </div>
  );
}
