"use client";

import { useCallback, useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Download, MoreVertical, PlusSquare, Share, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { VoTongyMark } from "@/components/brand/VoTongyLogo";
import { cn } from "@/lib/utils";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const DISMISS_KEY = "votongy:install-dismissed-at";
const DISMISS_DAYS = 7;

// Shared across every <InstallAppPrompt /> instance on the page.
let deferredPrompt: BeforeInstallPromptEvent | null = null;
let installed = false;
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((fn) => fn());

if (typeof window !== "undefined") {
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e as BeforeInstallPromptEvent;
    notify();
  });
  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    installed = true;
    notify();
  });
}

function detectStandalone(): boolean {
  if (typeof window === "undefined") return false;
  const nav = window.navigator as Navigator & { standalone?: boolean };
  return window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
}

function detectIOS(): boolean {
  if (typeof window === "undefined") return false;
  const ua = window.navigator.userAgent;
  const iPadOS = window.navigator.platform === "MacIntel" && window.navigator.maxTouchPoints > 1;
  return /iPhone|iPad|iPod/i.test(ua) || iPadOS;
}

function useInstall() {
  const [canPrompt, setCanPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(true); // hidden until we know

  useEffect(() => {
    setIsIOS(detectIOS());
    setIsStandalone(detectStandalone() || installed);
    setCanPrompt(Boolean(deferredPrompt));
    const sync = () => {
      setCanPrompt(Boolean(deferredPrompt));
      setIsStandalone(detectStandalone() || installed);
    };
    listeners.add(sync);
    return () => {
      listeners.delete(sync);
    };
  }, []);

  const available = !isStandalone && (canPrompt || isIOS);

  const install = useCallback(async (): Promise<"prompted" | "ios-guide" | "none"> => {
    if (deferredPrompt) {
      const evt = deferredPrompt;
      await evt.prompt();
      await evt.userChoice.catch(() => null);
      deferredPrompt = null;
      notify();
      return "prompted";
    }
    if (detectIOS()) return "ios-guide";
    return "none";
  }, []);

  return { available, isIOS, install };
}

function IosGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label="Install VoTongy on iPhone"
        >
          <motion.div
            className="safe-bottom w-full max-w-md rounded-t-3xl border border-zinc-800 bg-zinc-900 p-6 sm:rounded-3xl"
            initial={{ y: 60, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 60, opacity: 0 }}
            transition={{ type: "spring", damping: 28, stiffness: 320 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <VoTongyMark size={44} />
                <div>
                  <h2 className="font-display text-lg font-bold">Install VoTongy</h2>
                  <p className="text-sm text-zinc-400">Add it to your iPhone home screen</p>
                </div>
              </div>
              <button
                onClick={onClose}
                aria-label="Close"
                className="rounded-full p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <ol className="space-y-4">
              {[
                {
                  icon: <Share className="h-5 w-5 text-sky-400" />,
                  title: "Tap the Share button",
                  body: "It's the square with an arrow, at the bottom of Safari (or top right on iPad).",
                },
                {
                  icon: <PlusSquare className="h-5 w-5 text-primary" />,
                  title: "Choose “Add to Home Screen”",
                  body: "Scroll down the share sheet until you see it.",
                },
                {
                  icon: <Download className="h-5 w-5 text-emerald-400" />,
                  title: "Tap “Add”",
                  body: "VoTongy now opens like a normal app, full screen.",
                },
              ].map((step, i) => (
                <li key={step.title} className="flex gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-zinc-800">
                    {step.icon}
                  </span>
                  <div>
                    <p className="text-sm font-semibold">
                      {i + 1}. {step.title}
                    </p>
                    <p className="text-sm text-zinc-400">{step.body}</p>
                  </div>
                </li>
              ))}
            </ol>

            <p className="mt-5 rounded-lg bg-zinc-800/60 p-3 text-xs text-zinc-400">
              Not seeing the option? Open this page in <strong className="text-zinc-200">Safari</strong>{" "}
              first. Other iPhone browsers sometimes hide it.
            </p>
            <Button className="mt-4 w-full" onClick={onClose}>
              Got it
            </Button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface InstallAppPromptProps {
  /** "button": inline button (navbar / hero). "banner": dismissible bottom prompt for phones. */
  variant?: "button" | "banner";
  size?: "default" | "sm" | "lg";
  className?: string;
  label?: string;
}

export function InstallAppPrompt({
  variant = "button",
  size = "sm",
  className,
  label = "Install App",
}: InstallAppPromptProps) {
  const { available, install } = useInstall();
  const pathname = usePathname();
  const [guideOpen, setGuideOpen] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(false);

  // Banner timing: appear after a short delay, respect a 7-day dismissal.
  useEffect(() => {
    if (variant !== "banner" || !available) return;
    let dismissedAt = 0;
    try {
      dismissedAt = Number(localStorage.getItem(DISMISS_KEY) ?? 0);
    } catch {
      /* private mode */
    }
    if (dismissedAt && Date.now() - dismissedAt < DISMISS_DAYS * 86400000) return;
    const timer = window.setTimeout(() => setBannerVisible(true), 4000);
    return () => window.clearTimeout(timer);
  }, [variant, available]);

  const dismissBanner = () => {
    setBannerVisible(false);
    try {
      localStorage.setItem(DISMISS_KEY, String(Date.now()));
    } catch {
      /* ignore */
    }
  };

  const onInstall = async () => {
    const result = await install();
    if (result === "ios-guide") setGuideOpen(true);
    if (result === "prompted") setBannerVisible(false);
  };

  const hideOnDashboards = /^\/(admin|organizer|nominee)(\/|$)/.test(pathname ?? "");

  if (variant === "button") {
    if (!available) return <IosGuide open={guideOpen} onClose={() => setGuideOpen(false)} />;
    return (
      <>
        <Button size={size} onClick={onInstall} className={cn("gap-1.5", className)}>
          <Download className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} />
          {label}
        </Button>
        <IosGuide open={guideOpen} onClose={() => setGuideOpen(false)} />
      </>
    );
  }

  // banner
  if (!available || hideOnDashboards) return <IosGuide open={guideOpen} onClose={() => setGuideOpen(false)} />;
  return (
    <>
      <AnimatePresence>
        {bannerVisible && (
          <motion.div
            className="safe-bottom fixed inset-x-0 bottom-0 z-50 px-3 md:hidden"
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: "spring", damping: 26, stiffness: 300 }}
          >
            <div className="flex items-center gap-3 rounded-2xl border border-zinc-700 bg-zinc-900/95 p-3 shadow-2xl shadow-black/60 backdrop-blur">
              <VoTongyMark size={40} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">Get the VoTongy app</p>
                <p className="truncate text-xs text-zinc-400">Vote faster. Works like a native app.</p>
              </div>
              <Button size="sm" onClick={onInstall}>
                Install
              </Button>
              <button
                onClick={dismissBanner}
                aria-label="Dismiss"
                className="rounded-full p-1.5 text-zinc-500 hover:bg-zinc-800 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <IosGuide open={guideOpen} onClose={() => setGuideOpen(false)} />
    </>
  );
}

/** Small inline help used in the FAQ for Android users who miss the automatic prompt. */
export function AndroidInstallHint() {
  return (
    <p className="flex items-center gap-1.5 text-sm text-zinc-400">
      <MoreVertical className="h-4 w-4" /> Chrome menu, then &ldquo;Install app&rdquo; or &ldquo;Add to Home screen&rdquo;.
    </p>
  );
}
