import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
  {
    variants: {
      variant: {
        default: "border-primary/30 bg-primary/10 text-primary",
        success: "border-emerald-500/30 bg-emerald-500/10 text-emerald-400",
        warning: "border-amber-500/30 bg-amber-500/10 text-amber-400",
        danger: "border-red-500/30 bg-red-500/10 text-red-400",
        muted: "border-zinc-700 bg-zinc-800/60 text-zinc-300",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}

type StatusVariant = NonNullable<VariantProps<typeof badgeVariants>["variant"]>;

const STATUS_MAP: Record<string, StatusVariant> = {
  ACTIVE: "success",
  SUCCESS: "success",
  APPROVED: "success",
  PENDING: "warning",
  PENDING_APPROVAL: "warning",
  DRAFT: "muted",
  PAUSED: "warning",
  ENDED: "muted",
  REJECTED: "danger",
  FAILED: "danger",
  FLAGGED: "danger",
  ABANDONED: "muted",
};

export function StatusBadge({ status }: { status: string }) {
  return <Badge variant={STATUS_MAP[status] ?? "muted"}>{status.replace(/_/g, " ")}</Badge>;
}
