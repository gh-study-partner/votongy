// Hand-written row types matching supabase/schema.sql.
// You can replace this file with generated types later:
//   npx supabase gen types typescript --project-id <ref> > src/types/database.ts

export type UserRole = "SUPER_ADMIN" | "ORGANIZER" | "NOMINEE";
export type EventStatus =
  | "DRAFT"
  | "PENDING_APPROVAL"
  | "ACTIVE"
  | "PAUSED"
  | "ENDED"
  | "REJECTED";
export type NomineeStatus = "PENDING" | "APPROVED" | "REJECTED";
export type TxStatus = "PENDING" | "SUCCESS" | "FAILED" | "ABANDONED" | "FLAGGED";
export type TxChannel = "WEB" | "PWA" | "USSD";

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  phone: string | null;
  role: UserRole;
  is_approved: boolean;
  created_at: string;
}

export interface EventRow {
  id: string;
  organizer_id: string;
  slug: string;
  title: string;
  description: string | null;
  banner_url: string | null;
  cost_per_vote: number;
  currency: string;
  commission_pct: number;
  start_at: string;
  end_at: string;
  status: EventStatus;
  show_live_votes: boolean;
  allow_public_nominations: boolean;
  nominee_counter: number;
  created_at: string;
}

export interface PublicEvent {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  banner_url: string | null;
  cost_per_vote: number;
  currency: string;
  start_at: string;
  end_at: string;
  status: EventStatus;
  show_live_votes: boolean;
  allow_public_nominations: boolean;
  is_voting_open: boolean;
}

export interface CategoryRow {
  id: string;
  event_id: string;
  name: string;
  sort_order: number;
  created_at: string;
}

export interface PublicCategory {
  id: string;
  event_id: string;
  name: string;
  sort_order: number;
}

export interface NomineeRow {
  id: string;
  event_id: string;
  category_id: string;
  user_id: string | null;
  email: string | null;
  name: string;
  code: string | null;
  photo_url: string | null;
  bio: string | null;
  total_votes: number;
  status: NomineeStatus;
  created_at: string;
}

export interface PublicNominee {
  id: string;
  event_id: string;
  category_id: string;
  name: string;
  code: string;
  photo_url: string | null;
  bio: string | null;
  /** null when the organizer hides live counts and the event has not ended */
  total_votes: number | null;
}

export interface NominationApplication {
  id: string;
  event_id: string;
  category_id: string | null;
  applicant_name: string;
  applicant_email: string | null;
  applicant_phone: string | null;
  photo_url: string | null;
  bio: string | null;
  status: NomineeStatus;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface TransactionRow {
  id: string;
  reference: string;
  event_id: string;
  nominee_id: string;
  voter_phone: string | null;
  voter_email: string | null;
  votes: number;
  amount: number;
  currency: string;
  status: TxStatus;
  channel: TxChannel;
  paystack_payload: unknown;
  failure_reason: string | null;
  paid_at: string | null;
  created_at: string;
}

export interface Receipt {
  reference: string;
  status: TxStatus;
  votes: number;
  amount: number;
  currency: string;
  paid_at: string | null;
  created_at: string;
  event_title: string;
  event_slug: string;
  nominee_name: string;
  nominee_code: string;
  voter_phone_masked: string | null;
}

export interface AdminKpis {
  gross_volume: number;
  platform_commission: number;
  total_votes: number;
  successful_tx: number;
  active_events: number;
  pending_events: number;
  pending_organizers: number;
}

export interface RevenueDay {
  day: string;
  revenue: number;
  votes: number;
}

export interface RecentVote {
  votes: number;
  paid_at: string;
  voter_masked: string;
}
