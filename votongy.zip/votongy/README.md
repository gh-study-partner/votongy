# VoTongy

Event e-voting, nomination and installable PWA platform for Ghana. Mobile Money and card payments through Paystack.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind CSS · Framer Motion · Supabase (Postgres, Auth, Storage) · Upstash Redis · Vercel.

## Quick start

```bash
npm install
cp .env.example .env.local   # fill in the values
npm run dev
```

Full instructions (Supabase, Paystack, Super Admin, Vercel): see **[SETUP_GUIDE.md](./SETUP_GUIDE.md)**. Database: **[supabase/schema.sql](./supabase/schema.sql)**.

## How money and votes flow

1. `POST /api/vote/initiate` validates input, rate-limits, computes the price **on the server**, stores a `PENDING` transaction and starts a Paystack GHS checkout.
2. Paystack calls `POST /api/webhooks/paystack`. The `x-paystack-signature` header is verified (HMAC SHA512 over the raw body) before anything else.
3. The webhook calls the Postgres function `process_successful_vote`, which locks the transaction row (`FOR UPDATE`), is idempotent, checks amount and currency, and increments `nominees.total_votes` in the same transaction.
4. The receipt page polls `/api/receipt/sync` while a payment is pending. That endpoint asks Paystack directly (server to server) and uses the same RPC, as a safety net for slow webhooks.

The browser is never trusted to say a payment succeeded.

## Layout

```
src/app/                 routes (public pages, /admin, /organizer, /nominee, /api)
src/components/          UI, voting, receipt, dashboard, PWA, brand
src/lib/                 supabase clients, paystack, ratelimit, validation, phone, pdf
src/middleware.ts        role-based route protection + session refresh
public/sw.js             service worker (static asset caching + offline page)
supabase/schema.sql      tables, RLS, triggers, RPCs, views, storage
```

## Roles

| Role | Created by | Area |
|---|---|---|
| `SUPER_ADMIN` | Manually in Supabase (see guide) | `/admin` |
| `ORGANIZER` | Self sign-up, approved by Super Admin | `/organizer` |
| `NOMINEE` | Invited by organizer (magic link) | `/nominee` |
| Voters | Guest checkout | `/`, `/e/[slug]` |

## Scripts

`npm run dev` · `npm run build` · `npm start` · `npm run typecheck`
