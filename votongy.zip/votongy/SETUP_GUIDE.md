# VoTongy: Setup & Dashboard Access Guide

Do these in order. About 45 minutes (Paystack business verification can take longer; test mode works immediately).

---

## Step 0: Run it locally

Requires Node.js 20 or newer.

```bash
unzip votongy.zip && cd votongy
npm install
cp .env.example .env.local      # then fill in the values from Steps 1, 5 and 6
npm run dev                     # http://localhost:3000
```

Optional sanity checks: `npm run typecheck` and `npm run build`.

---

## Step 1: Create the Supabase project
1. https://supabase.com, **New project**. Name it `votongy`, set a strong database password and save it.
2. Region: closest to Ghana (e.g. **eu-west / London** or **eu-central / Frankfurt**).
3. When ready, open **Project Settings, API** and copy:
   - `Project URL` to `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key to `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key to `SUPABASE_SERVICE_ROLE_KEY` (**secret, server only**)

## Step 2: Run the database schema (pick ONE option)

**Option A: SQL Editor (simplest).** Supabase Dashboard, **SQL Editor, New query**, paste the whole of `supabase/schema.sql`, **Run**.

**Option B: Supabase CLI.**
```bash
npx supabase login
npx supabase link --project-ref YOUR-PROJECT-REF      # ref is in your dashboard URL
# Run the file with psql, using the connection string from Project Settings > Database:
psql "postgresql://postgres:YOUR-DB-PASSWORD@db.YOUR-PROJECT-REF.supabase.co:5432/postgres" -f supabase/schema.sql
```
The CLI is only needed for `link` and type generation; if you don't have `psql`, use Option A.

Verify in **Table Editor**: `profiles`, `platform_settings`, `events`, `categories`, `nominees`, `nomination_applications`, `transactions`, `audit_logs`. In **Storage**: bucket `votongy-media`.

The schema is safe to run again (it uses `if not exists` / `or replace`). The default platform commission is **10%** (`platform_settings.default_commission_pct`; it is forced onto every new event and only a Super Admin can change it per event).

Optional: generate exact TypeScript types for your database:
```bash
npx supabase gen types typescript --project-id YOUR-PROJECT-REF > src/types/database.ts
```
(The project ships with hand-written types that already match the schema, so this is optional.)

## Step 3: Configure Supabase Auth
1. **Authentication, Providers, Email**: enabled. Keep "Confirm email" ON for production.
2. **Authentication, URL Configuration**
   - Site URL: `https://your-domain.com` (`http://localhost:3000` while developing)
   - Redirect URLs (add all):
     - `http://localhost:3000/auth/callback`
     - `https://your-domain.com/auth/callback`
     - `https://*-your-team.vercel.app/auth/callback` (Vercel previews, optional)
3. **Authentication, Email Templates**: brand the "Magic Link" and "Invite user" emails. The default templates work as they are.
4. For real email delivery set a custom SMTP (**Project Settings, Authentication, SMTP**): Resend, Brevo, Zoho, etc. Supabase's built-in email is heavily rate-limited, and nominee invitations and magic links depend on it.

## Step 4: Create YOUR Super Admin account
No public signup exists for this role.
1. **Authentication, Users, Add user, Create new user.** Enter your email and a strong password, and tick **Auto Confirm User**.
2. **SQL Editor**, run (replace the email):

```sql
update auth.users
   set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"SUPER_ADMIN"}'::jsonb
 where email = 'you@example.com';

update public.profiles
   set role = 'SUPER_ADMIN', is_approved = true, full_name = 'Platform Owner'
 where email = 'you@example.com';
```
3. Repeat for any client executives who should also be Super Admins.
4. Sign in at `/login`; you land on `/admin`.

## Step 5: Paystack (Ghana MoMo & Cards)
1. Create an account at https://paystack.com and select **Ghana**.
2. Complete business verification (needed for live mode and Mobile Money).
3. **Settings, API Keys & Webhooks**:
   - Public key to `NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY`
   - Secret key to `PAYSTACK_SECRET_KEY` (use `sk_test_` until launch)
4. **Webhook URL**: `https://your-domain.com/api/webhooks/paystack`. Paystack signs webhooks with your **secret key** (HMAC SHA512), so there is no separate webhook secret.
5. Confirm **Mobile Money** (MTN, Telecel, AirtelTigo) and **Card** are enabled on your account.
6. Local testing: Paystack can't reach `localhost`. Run `ngrok http 3000` (or `cloudflared tunnel`) and use that HTTPS URL as the test webhook URL. Even without the webhook, the receipt page re-checks pending payments with Paystack's API every few seconds, so local testing still works.

## Step 6: Upstash Redis (rate limiting)
1. https://upstash.com, **Create Database** (Redis), region near your Vercel region.
2. Copy `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` from the REST API section.
3. Optional in development: when blank, the app uses a per-instance in-memory limiter. **Required in production** (serverless instances don't share memory).

## Step 7: PWA app icons
Already generated for you in `public/icons/`: `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`. Source SVGs sit next to them (`logo-icons.svg`, `icon-maskable.svg`, `apple-icon.svg`). To change the logo, edit the SVGs and `src/components/brand/logo-paths.ts`, then re-export the PNGs (https://maskable.app/editor or `npx pwa-asset-generator`).

The service worker only registers in production builds. Test the install flow with `npm run build && npm start`, or on your deployed site.

## Step 8: Environment variables
`.env.example` lists every variable:

```bash
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SUPPORT_EMAIL=support@votongy.com
NEXT_PUBLIC_SUPPORT_WHATSAPP=            # optional, e.g. 233240000000

NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=               # server only

NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY=
PAYSTACK_SECRET_KEY=                     # server only

UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=
```

## Step 9: Deploy to Vercel
1. Push the repo to GitHub (`.env.local` is already git-ignored).
2. https://vercel.com, **Add New, Project**, import the repo (framework: Next.js, no extra settings).
3. **Settings, Environment Variables**: add every variable above for **Production** (and Preview if you use it).
   - `NEXT_PUBLIC_SITE_URL` must be your real domain.
   - Use **live** Paystack keys only when ready for real money.
4. Deploy, then **Settings, Domains** to attach your domain.
5. Update Supabase Site URL / Redirect URLs (Step 3) and the Paystack webhook URL (Step 5) to the production domain.
6. Run a GHS 1 test vote end to end before announcing.

## Step 10: Who logs in where

| Role | How they get an account | Login | Lands on |
|---|---|---|---|
| Super Admin | You create them in Supabase (Step 4) | `/login` | `/admin` |
| Organizer | Signs up on `/login` (Organizer sign-up tab); you approve in **/admin/approvals** | `/login` | `/organizer` |
| Nominee | Organizer adds them with an email; they receive a magic-link invitation | `/login` (Magic link tab) | `/nominee` |
| Voters | No account, guest checkout | n/a | `/` and `/e/[slug]` |

## Typical first run
1. Sign in as Super Admin. Sign up a second account as an Organizer (use another browser or a private window) and approve it under **Approvals**.
2. As the Organizer: **New event** wizard, add categories and nominees, **Submit for approval**.
3. As Super Admin: approve the event (you can adjust its commission here; the default is 10%).
4. Open `/e/your-slug`, vote with a test GHS 1 payment, confirm the receipt shows `SUCCESS` and the nominee's total went up.

## Pre-launch checklist
- [ ] Schema ran with no errors
- [ ] Super Admin can log in
- [ ] Custom SMTP configured
- [ ] Paystack webhook URL points to production
- [ ] Live Paystack keys set only in Vercel Production
- [ ] Upstash keys set in production
- [ ] App installed on a real Android phone and an iPhone
- [ ] A lawyer reviewed `/terms`, `/privacy`, `/refund-policy`
- [ ] Test vote succeeded and the receipt shows `SUCCESS`
- [ ] Emergency pause tested from `/admin`
